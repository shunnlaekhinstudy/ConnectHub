<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String userName = (String) session.getAttribute("userName");
    Integer userId = (Integer) session.getAttribute("user_id");
    if(userName == null || userId == null) {
        response.sendRedirect("index.jsp");
        return;
    }String savedBg = (String) session.getAttribute("appBgColor");
    if(savedBg == null) savedBg = "#ffffff";
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post - Connect Hub</title>
    <!-- Cropper.js CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
   
    :root {
        /* Session ထဲမှ User ၏ သီးသန့်နောက်ခံအရောင်ကို ဆွဲယူသုံးသည် (မရှိလျှင် အဖြူရောင်) */
        --app-bg: <%= session.getAttribute("appBgColor") != null ? session.getAttribute("appBgColor") : "#ffffff" %>;
    }

    /* App ၏ အဓိက Container တွင် background ကို ချိတ်ဆက်ပေးခြင်း */
    .app-wrapper {
        background: var(--app-bg) !important;
        background-attachment: fixed;
    }
       
    body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; align-items: center; min-height: 100vh; }

        .phone-container {
            width: 100%;
            max-width: 480px;
            background: var(--app-bg) !important;
            min-height: 100vh;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            position: relative;
            display: flex;
            flex-direction: column;
            padding-bottom: 30px;
            box-sizing: border-box;
        }

        .phone-top-header {
            display: flex; justify-content: space-between; align-items: center; padding: 12px 15px; background: var(--app-bg) !important; border-bottom: 1px solid #e4e6eb; position: sticky; top: 0; z-index: 100; 
        }
        .back-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: #2e7d32; padding: 0; }
        .header-title {color: #2e7d32; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; cursor: pointer;  }

        .phone-screen-content {
            flex: 1;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
        }

        .user-info-section {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }
        .user-avatar {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid #ddd;
        }
        .user-name-wrapper {
            display: flex;
            flex-direction: column;
        }
        .user-name {
            font-size: 15px;
            font-weight: bold;
            color: #050505;
        }
        .post-privacy {
            font-size: 12px;
            color: #65676b;
            background: #e4e6eb;
            padding: 2px 6px;
            border-radius: 4px;
            width: fit-content;
            margin-top: 3px;
        }

        /* 🌟 စာနဲ့ပုံကို ကတ်တစ်ခုတည်းထဲမှာ Background တစ်သားတည်း ဖြစ်စေရန် */
        .post-inputs-wrapper {
            background-color: #ffffff;
            border-radius: 12px;
            padding: 15px;
            box-sizing: border-box;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            border: 1px solid #f0f2f5;
            transition: background 0.3s ease, background-image 0.3s ease;
        }

        .post-title-input, 
        .post-title-input:focus, 
        .post-title-input:active {
            width: 100%;
            border: none !important;
            background: transparent !important;
            -webkit-appearance: none;
            outline: none;
            font-size: 16px;
            font-weight: bold;
            color: #050505;
            border-bottom: 1px solid rgba(0,0,0,0.15) !important;
            padding-bottom: 8px;
            margin-bottom: 10px;
        }
        
        .post-title-input::placeholder, .post-text-input::placeholder {
            color: #8b8d91;
        }

        .post-text-input, 
        .post-text-input:focus, 
        .post-text-input:active {
            width: 100%;
            border: none !important;
            background: transparent !important;
            -webkit-appearance: none;
            outline: none;
            font-family: inherit;
            font-size: 14px;
            color: #050505;
            line-height: 1.5;
            resize: none;
            overflow: hidden;
            min-height: 60px;
            box-sizing: border-box;
        }

        .more-text-btn {
            background: none;
            border: none;
            color: #1877f2;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
            padding: 0;
            margin-top: 4px;
            display: none;
        }

        /* 🌟 ကတ်အတွင်းမှာ ပုံပြမည့်နေရာ (Slider Area) */
        .post-media-area {
            position: relative;
            width: 100%;
            height: 260px;
            border-radius: 8px;
            overflow: hidden;
            display: none;
            align-items: center;
            justify-content: center;
            margin-top: 15px;
            background: rgba(0,0,0,0.05);
        }
        .slide-item-container {
            width: 100%;
            height: 100%;
            position: relative;
            display: none;
            align-items: center;
            justify-content: center;
        }
        .slide-item-container.active {
            display: flex;
        }
        .slide-item-container img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            cursor: pointer;
        }

        .crop-hint-badge {
            position: absolute;
            bottom: 10px;
            background: rgba(0,0,0,0.7);
            color: #fff;
            padding: 4px 10px;
            font-size: 11px;
            border-radius: 4px;
            pointer-events: none;
        }

        .remove-img-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: rgba(0, 0, 0, 0.7);
            color: #fff;
            border: none;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            z-index: 20;
        }
        .remove-img-btn:hover { background: #fa383e; }

        .slider-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0,0,0,0.5);
            color: #fff;
            border: none;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            z-index: 10;
        }
        .slider-arrow:hover { background: rgba(0,0,0,0.8); }
        .arrow-left { left: 10px; }
        .arrow-right { right: 10px; }
        
        .image-counter {
            font-size: 12px;
            color: #65676b;
            margin-top: 6px;
            text-align: right;
            display: none;
        }

        .bottom-action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 18px;
            border-top: 1px solid #f0f2f5;
            padding-top: 12px;
            position: relative;
        }
        .tools-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .color-picker-wrapper {
            position: relative;
        }
        .color-logo-btn, .image-logo-btn {
            background: #f0f2f5;
            border: 1px solid #ccd0d5;
            padding: 7px 12px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
            font-weight: 500;
        }
        .color-logo-btn { gap: 5px; }

        .color-palette-grid {
            display: none;
            position: absolute;
            bottom: 45px;
            left: 0;
            background: #fff;
            border: 1px solid #ccd0d5;
            padding: 12px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
            z-index: 150;
            width: 240px;
            box-sizing: border-box;
        }
        .color-box {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            cursor: pointer;
            border: 1px solid #ddd;
            justify-self: center;
        }

        .btn-small-post {
            background: rgb(0, 128, 0);
            color: white;
            border: none;
            padding: 8px 18px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
        }
        .btn-small-post:hover { background: rgb(0, 128, 0); }

        /* Cropper Modal */
        #cropModal {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.85);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
            box-sizing: border-box;
        }
        .modal-content {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            width: 100%;
            max-width: 380px;
            box-sizing: border-box;
        }
        .modal-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 12px;
            color: #050505;
        }
        .img-container {
            width: 100%;
            max-height: 250px;
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #000;
            border-radius: 8px;
        }
        #imageToCrop {
            max-width: 100%;
            display: block;
        }
        .modal-actions {
            display: flex;
            gap: 8px;
            justify-content: space-between;
        }
        .modal-btn {
            flex: 1;
            padding: 8px 14px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
            border: none;
        }
        
        .btn-rotate { background: #65676b; color: white; }
        .btn-cancel { background: #e4e6eb; color: #050505; }
        .btn-done { background: rgb(0, 128, 0); color: white; }
    </style>
</head>
<body>

    <div class="phone-container">
        <div class="phone-top-header">
            <button class="back-btn" onclick="window.location.href='HomeServlet'"><i class="fa-solid fa-arrow-left"></i></button>
            <div class="header-title">Create Post</div>
            <div style="width: 20px;"></div>
        </div>

        <form action="PostServlet" method="POST" enctype="multipart/form-data" class="phone-screen-content">
            
            <div class="user-info-section">
                <img src="ImageServlet?user_id=<%= userId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="user-avatar" alt="User"onclick="window.location.href='ViewProfileServlet'">
                <div class="user-name-wrapper">
                    <div class="user-name"><%= userName %></div>
                    <span class="post-privacy">🌐 Public</span>
                </div>
            </div>

            <!-- 🌟 Card Wrapper (Background အရောင်ပြောင်းမည့်နေရာ) -->
            <div class="post-inputs-wrapper" id="postCardBg">
                <input type="text" name="postTitle" class="post-title-input" placeholder="Title" required>
                
                <textarea name="postContent" class="post-text-input" id="postContentInput" placeholder="What are you thinking...." oninput="autoResizeTextarea(this)" required></textarea>
                
                <button type="button" class="more-text-btn" id="moreBtn" onclick="toggleTextExpansion()">... more</button>

                <!-- ပုံပြမည့် Slider Area -->
                <div class="post-media-area" id="mediaArea">
                    <div id="imageSliderContainer" style="width:100%; height:100%; position:relative;"></div>
                    <button type="button" class="slider-arrow arrow-left" id="prevBtn" onclick="moveSlide(-1)"><i class="fa-solid fa-chevron-left"></i></button>
                    <button type="button" class="slider-arrow arrow-right" id="nextBtn" onclick="moveSlide(1)"><i class="fa-solid fa-chevron-right"></i></button>
                </div>
            </div>
            <div class="image-counter" id="imageCounterText">ပုံ: 0 / 10</div>

            <input type="file" id="hiddenImageInput" name="images" accept="image/*" multiple style="display:none;" onchange="handleImageSelection(event)">
            
            <!-- 🌟 Database သို့ bg_style ပို့ပေးမည့် Hidden Input -->
            <input type="hidden" name="bgStyle" id="bgStyleInput" value="#ffffff">

            <div class="bottom-action-bar">
                <div class="tools-group">
                    <div class="color-picker-wrapper">
                        <button type="button" class="color-logo-btn" onclick="toggleColorPalette()">🎨</button>
                        
                        <div class="color-palette-grid" id="colorPaletteGrid">
                            <div class="color-box" style="background:#ffffff;" onclick="setBg('#ffffff')"></div>
                            <div class="color-box" style="background:#fdf2e9;" onclick="setBg('#fdf2e9')"></div>
                            <div class="color-box" style="background:#fadbd8;" onclick="setBg('#fadbd8')"></div>
                            <div class="color-box" style="background:#d4efdf;" onclick="setBg('#d4efdf')"></div>
                            <div class="color-box" style="background:#d1f2eb;" onclick="setBg('#d1f2eb')"></div>
                            <div class="color-box" style="background:#ebdef0;" onclick="setBg('#ebdef0')"></div>
                            <div class="color-box" style="background:#fcf3cf;" onclick="setBg('#fcf3cf')"></div>
                            <div class="color-box" style="background:#e8f8f5;" onclick="setBg('#e8f8f5')"></div>
                            <div class="color-box" style="background:#f9ebea;" onclick="setBg('#f9ebea')"></div>
                            <div class="color-box" style="background:#eaeded;" onclick="setBg('#eaeded')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #f6d365, #fda085);" onclick="setBg('linear-gradient(135deg, #f6d365, #fda085)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #84fab0, #8fd3f4);" onclick="setBg('linear-gradient(135deg, #84fab0, #8fd3f4)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #a1c4fd, #c2e9fb);" onclick="setBg('linear-gradient(135deg, #a1c4fd, #c2e9fb)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #ff9a9e, #fecfef);" onclick="setBg('linear-gradient(135deg, #ff9a9e, #fecfef)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #ffecd2, #fcb69f);" onclick="setBg('linear-gradient(135deg, #ffecd2, #fcb69f)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #ff758c, #ff7eb3);" onclick="setBg('linear-gradient(135deg, #ff758c, #ff7eb3)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #65dfc9, #6cdbeb);" onclick="setBg('linear-gradient(135deg, #65dfc9, #6cdbeb)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #fbc531, #e84118);" onclick="setBg('linear-gradient(135deg, #fbc531, #e84118)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #4cd137, #009432);" onclick="setBg('linear-gradient(135deg, #4cd137, #009432)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #192a56, #273c75);" onclick="setBg('linear-gradient(135deg, #192a56, #273c75)')"></div>
                        </div>
                    </div>

                    <button type="button" class="image-logo-btn" onclick="document.getElementById('hiddenImageInput').click()" title="Image">🖼️</button>
                </div>

                <button type="submit" class="btn-small-post">Post</button>
            </div>

        </form>

        <!-- Cropper Modal -->
        <div id="cropModal">
            <div class="modal-content">
                <div class="modal-title" id="modalTitle">Crop Image</div>
                <div class="img-container">
                    <img id="imageToCrop" src="" alt="Source">
                </div>
                <div class="modal-actions" style="margin: 12px 0;">
                    <button type="button" class="modal-btn btn-rotate" onclick="cropper.rotate(90)"><i class="fa-solid fa-rotate-right"></i> Rotate</button>
                </div>
                <div class="modal-actions">
                    <button type="button" class="modal-btn btn-cancel" onclick="closeCropModal()">Cancel</button>
                    <button type="button" class="modal-btn btn-done" onclick="getCroppedImage()">Done</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Cropper.js JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>
    <script>
        let selectedFiles = [];
        let currentSlideIndex = 0;
        let cropper;
        let isTextExpanded = false;
        const imageToCrop = document.getElementById('imageToCrop');

        function autoResizeTextarea(textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';

            const moreBtn = document.getElementById('moreBtn');
            if (textarea.value.length > 130) {
                moreBtn.style.display = 'block';
                if (!isTextExpanded) {
                    textarea.style.maxHeight = '70px';
                    textarea.style.overflow = 'hidden';
                    moreBtn.innerText = "... more";
                }
            } else {
                moreBtn.style.display = 'none';
                textarea.style.maxHeight = 'none';
                textarea.style.overflow = 'hidden';
            }
        }

        function toggleTextExpansion() {
            const textarea = document.getElementById('postContentInput');
            const moreBtn = document.getElementById('moreBtn');
            isTextExpanded = !isTextExpanded;

            if (isTextExpanded) {
                textarea.style.maxHeight = 'none';
                textarea.style.overflow = 'auto';
                moreBtn.innerText = "less";
            } else {
                textarea.style.maxHeight = '70px';
                textarea.style.overflow = 'hidden';
                moreBtn.innerText = "... more";
            }
        }

        function toggleColorPalette() {
            const grid = document.getElementById('colorPaletteGrid');
            grid.style.display = grid.style.display === 'grid' ? 'none' : 'grid';
        }

        /* 🌟 အရောင် သို့မဟုတ် Gradient ရွေးချယ်သောအခါ Card ရဲ့ Background ကိုပြောင်းပေးခြင်း */
        function setBg(colorValue) {
            const postCard = document.getElementById('postCardBg');
            
            if (colorValue.startsWith('linear-gradient')) {
                postCard.style.background = colorValue;
                postCard.style.backgroundImage = colorValue;
            } else {
                postCard.style.background = colorValue;
                postCard.style.backgroundImage = 'none';
            }

            // Hidden input ထဲသို့ အရောင်တန်ဖိုး ထည့်သွင်းခြင်း
            document.getElementById('bgStyleInput').value = colorValue;
            document.getElementById('colorPaletteGrid').style.display = 'none';
        }

        function handleImageSelection(event) {
            const files = event.target.files;
            if (files && files.length > 0) {
                const newFiles = Array.from(files);
                if (selectedFiles.length + newFiles.length > 10) {
                    alert("Can add 10 photos");
                    return;
                }
                selectedFiles = selectedFiles.concat(newFiles);
                currentSlideIndex = selectedFiles.length - newFiles.length;
                updateImageInputFiles();
                renderSliderImages();
            }
        }

        function removeImage(index, event) {
            event.stopPropagation();
            selectedFiles.splice(index, 1);
            if (currentSlideIndex >= selectedFiles.length) {
                currentSlideIndex = Math.max(0, selectedFiles.length - 1);
            }
            updateImageInputFiles();
            renderSliderImages();
        }

        function updateImageInputFiles() {
            const dataTransfer = new DataTransfer();
            selectedFiles.forEach(f => dataTransfer.items.add(f));
            document.getElementById('hiddenImageInput').files = dataTransfer.files;
        }

        function renderSliderImages() {
            const sliderContainer = document.getElementById('imageSliderContainer');
            const mediaArea = document.getElementById('mediaArea');
            const counterText = document.getElementById('imageCounterText');

            sliderContainer.innerHTML = "";

            if (selectedFiles.length > 0) {
                mediaArea.style.display = 'block';
                counterText.style.display = 'block';

                selectedFiles.forEach((file, index) => {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const itemDiv = document.createElement('div');
                        itemDiv.className = 'slide-item-container ' + (index === currentSlideIndex ? 'active' : '');
                        
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.title = "Crop";
                        img.onclick = function() { openCropper(index, e.target.result); };

                        const badge = document.createElement('div');
                        badge.className = 'crop-hint-badge';
                        badge.innerText = "Crop";

                        const removeBtn = document.createElement('button');
                        removeBtn.type = 'button';
                        removeBtn.className = 'remove-img-btn';
                        removeBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';
                        removeBtn.onclick = function(ev) { removeImage(index, ev); };

                        itemDiv.appendChild(img);
                        itemDiv.appendChild(badge);
                        itemDiv.appendChild(removeBtn);
                        sliderContainer.appendChild(itemDiv);
                    }
                    reader.readAsDataURL(file);
                });

                counterText.innerText = "image:" + (currentSlideIndex + 1) + " / " + selectedFiles.length;
                updateSliderArrows();
            } else {
                mediaArea.style.display = 'none';
                counterText.style.display = 'none';
            }
        }

        function moveSlide(direction) {
            const sliderContainer = document.getElementById('imageSliderContainer');
            const containers = sliderContainer.getElementsByClassName('slide-item-container');
            
            if (containers.length === 0) return;

            containers[currentSlideIndex].classList.remove('active');
            currentSlideIndex += direction;
            
            if (currentSlideIndex < 0) currentSlideIndex = containers.length - 1;
            else if (currentSlideIndex >= containers.length) currentSlideIndex = 0;
            
            containers[currentSlideIndex].classList.add('active');
            document.getElementById('imageCounterText').innerText = "image" + (currentSlideIndex + 1) + " / " + selectedFiles.length;
            updateSliderArrows();
        }

        function updateSliderArrows() {
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            if (selectedFiles.length <= 1) {
                prevBtn.style.display = 'none';
                nextBtn.style.display = 'none';
            } else {
                prevBtn.style.display = 'flex';
                nextBtn.style.display = 'flex';
            }
        }

        let editingIndex = -1;

        function openCropper(index, imgSrc) {
            editingIndex = index;
            imageToCrop.src = imgSrc;
            document.getElementById('modalTitle').innerText = "Crop Image (image " + (index + 1) + ")";
            document.getElementById('cropModal').style.display = 'flex';
            
            if (cropper) { cropper.destroy(); }
            
            cropper = new Cropper(imageToCrop, {
                aspectRatio: NaN,
                viewMode: 1,
                dragMode: 'move',
                autoCropArea: 1,
                restore: false,
                guides: true,
                center: true,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
            });
        }

        function closeCropModal() {
            document.getElementById('cropModal').style.display = 'none';
            if (cropper) { cropper.destroy(); }
        }

        function getCroppedImage() {
            const canvas = cropper.getCroppedCanvas();
            
            if (canvas && editingIndex !== -1) {
                canvas.toBlob(function(blob) {
                    const file = new File([blob], "edited_" + editingIndex + ".jpg", { type: "image/jpeg" });
                    selectedFiles[editingIndex] = file;
                    updateImageInputFiles();
                    renderSliderImages();
                }, 'image/jpeg');
            }
            document.getElementById('cropModal').style.display = 'none';
            if (cropper) { cropper.destroy(); }
        }
    </script>
</body>
</html>