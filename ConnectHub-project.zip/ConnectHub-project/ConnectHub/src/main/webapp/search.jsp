<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<%
Integer userId = (Integer) session.getAttribute("user_id");
String userName = (String) session.getAttribute("userName");
if (userName == null) userName = (String) session.getAttribute("user");
if (userName == null) userName = "User";

if (userId == null) {
    response.sendRedirect("index.jsp");
    return;
}
String savedBg = (String) session.getAttribute("appBgColor");
if(savedBg == null || savedBg.trim().isEmpty()) savedBg = "#ffffff";

List<Map<String, Object>> usersList = (List<Map<String, Object>>) request.getAttribute("usersList");
List<Map<String, Object>> postsList = (List<Map<String, Object>>) request.getAttribute("postsList");
String searchQuery = (String) request.getAttribute("searchQuery");
if(searchQuery == null) searchQuery = "";
boolean hasSearched = (searchQuery != null && !searchQuery.trim().isEmpty());

String activeTab = "usersTab";
if (hasSearched && (usersList == null || usersList.isEmpty()) && (postsList != null && !postsList.isEmpty())) {
    activeTab = "postsTab";
}
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connect Hub - Search</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        
        :root { --app-bg: <%= savedBg %>; }

        .phone-container { 
            width: 100%; max-width: 480px; background: var(--app-bg) !important; background-attachment: fixed;
            min-height: 100vh; box-shadow: 0 0 15px rgba(0,0,0,0.1); position: relative; display: flex; flex-direction: column; padding-bottom: 30px;
        }
        
        .header { display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; background: var(--app-bg) !important; position: sticky; top: 0; z-index: 100; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .menu-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: #2e7d32; }
        .logo { color: #2e7d32; font-size: 20px; font-weight: 700; }
        .header-icons { display: flex; gap: 8px; }
        .icon-btn { background-color: #e8f5e9; border: none; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 16px; color: #2e7d32; cursor: pointer; }

        .search-box-container { padding: 12px 15px; background: var(--app-bg); }
        .search-form { display: flex; gap: 8px; }
        .search-input { flex: 1; padding: 10px 15px; border: 1px solid #ccd0d5; border-radius: 20px; outline: none; font-size: 14px; background: #fff; }
        .search-btn { background: #2e7d32; color: #fff; border: none; padding: 0 15px; border-radius: 20px; font-weight: 600; cursor: pointer; }

        .results-nav-tabs { display: flex; border-bottom: 1px solid #e4e6eb; background: #fff; z-index: 99; position: relative; }
        .result-tab { flex: 1; text-align: center; padding: 12px; font-weight: 600; font-size: 14px; color: #65676b; cursor: pointer; border-bottom: 3px solid transparent; user-select: none; }
        .result-tab.active { color: #2e7d32; border-bottom-color: #2e7d32; }

        .tab-content { display: none; padding: 15px; }
        .tab-content.active { display: flex; flex-direction: column; gap: 12px; }

        /* User Item Style */
        .user-item { display: flex; align-items: center; justify-content: space-between; background: #fff; padding: 10px 12px; border-radius: 8px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
        .user-info-left { display: flex; align-items: center; gap: 10px; }
        .user-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; cursor: pointer; }
        .user-name { font-weight: 700; font-size: 14px; color: #050505; text-decoration: none; }
        .user-email { font-size: 12px; color: #65676b; }
        
        .friend-action-btn { padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; border: none; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; }
        .btn-friend { background: #e4e6eb; color: #050505; }
        .btn-message { background: #e8f5e9; color: #2e7d32; text-decoration: none; }
        .btn-add { background: #e8f5e9; color: #2e7d32; text-decoration: none; }
        .btn-accept { background: #2e7d32; color: #fff; text-decoration: none; }
        .btn-requested { background: #f0f2f5; color: #65676b; }

        /* Post Card Styles */
        .feed-container { display: flex; flex-direction: column; gap: 15px; }
        .post-card { padding: 15px; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #e4e6eb; background-color: #ffffff; position: relative; text-align: left; }
        .post-header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        .post-user-info { display: flex; align-items: center; gap: 8px; }
        .post-user-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; cursor: pointer; }
        .post-username-time { display: flex; flex-direction: column; }
        .post-author-name { font-size: 13px; font-weight: 700; color: #050505; text-decoration: none; }
        .post-time { color: #65676b; font-size: 11px; }

        .post-title { font-size: 16px; font-weight: 700; color: #050505; margin-bottom: 4px; }
        .post-text { font-size: 14px; color: #050505; word-break: break-word; margin-bottom: 10px; line-height: 1.4; }
        .post-images-grid { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
        .post-images-grid img { width: 100%; max-height: 280px; object-fit: cover; border-radius: 6px; } 

        .post-stats-bar { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #e4e6eb; font-size: 13px; color: #65676b; margin-top: 10px; }
        .stat-item { cursor: pointer; display: flex; align-items: center; gap: 5px; }

        .post-actions-row { display: flex; justify-content: space-around; padding-top: 6px; margin-top: 4px; }
        .action-action-btn { background: none; border: none; font-size: 13px; font-weight: 600; color: #65676b; cursor: pointer; display: flex; align-items: center; gap: 6px; padding: 6px 15px; border-radius: 4px; }
        .action-action-btn.liked .heart-icon { color: #fa383e; }
        
        .comment-section { display: none; flex-direction: column; gap: 10px; margin-top: 10px; padding-top: 10px; border-top: 1px solid #e4e6eb; }
        .comment-list { font-size: 12px; display: flex; flex-direction: column; gap: 6px; max-height: 250px; overflow-y: auto; width: 100%; }
        .comment-item { background: #f0f2f5; padding: 8px 12px; border-radius: 12px; display: flex; flex-direction: column; gap: 4px; position: relative; width: 100%; }
        .comment-item.is-reply { margin-left: 20px; width: calc(100% - 20px); background: #e4e6eb; }
        .comment-top-row { display: flex; align-items: flex-start; justify-content: space-between; width: 100%; gap: 8px; }
        .comment-text-content { flex: 1; word-break: break-word; font-size: 13px; color: #050505; }
        .comment-footer-row { display: flex; align-items: center; gap: 12px; font-size: 11px; color: #65676b; }
        .comment-reply-btn { background: none; border: none; font-size: 11px; font-weight: 600; color: #65676b; cursor: pointer; padding: 0; }
        .comment-input-box { display: flex; gap: 8px; width: 100%; align-items: center; margin-top: 6px; }
        .comment-input { flex: 1; padding: 8px 12px; border: 1px solid #e4e6eb; border-radius: 20px; font-size: 13px; outline: none; background: #ffffff; }
        .comment-send-btn { background: #2e7d32; color: #fff; border: none; padding: 8px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer; }
        .reply-input-box { display: flex; gap: 6px; margin-top: 6px; margin-left: 15px; align-items: center; }
        .reply-input { flex: 1; padding: 5px 10px; border: 1px solid #ccd0d5; border-radius: 15px; font-size: 12px; outline: none; background: #ffffff; }
        .reply-send-btn { background: #2e7d32; color: #fff; border: none; padding: 5px 10px; border-radius: 15px; font-size: 11px; font-weight: 600; cursor: pointer; }
        
        #toast { visibility: hidden; min-width: 220px; background-color: #333; color: #fff; text-align: center; border-radius: 4px; padding: 10px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; }
        #toast.show { visibility: visible; animation: fadein 0.5s, fadeout 0.5s 1.5s; }
        @keyframes fadein { from { bottom: 0; opacity: 0; } to { bottom: 30px; opacity: 1; } }
        @keyframes fadeout { from { bottom: 30px; opacity: 1; } to { bottom: 0; opacity: 0; } }
    </style>
</head>
<body>

    <div class="phone-container">
        <!-- Header -->
        <div class="header">
            <div class="logo-area">
                <button class="menu-btn" onclick="window.location.href='HomeServlet'"><i class="fa-solid fa-arrow-left"></i></button>
                <div class="logo">Search</div>
            </div>
            <div class="header-icons">
                <button class="icon-btn" onclick="window.location.href='PostServlet'"><i class="fa-solid fa-plus"></i></button>
            </div>
        </div>

        <!-- Search Bar Input -->
        <div class="search-box-container">
            <form action="SearchServlet" method="GET" class="search-form">
                <input type="text" name="query" class="search-input" placeholder="Find user and posts" value="<%= searchQuery %>" required>
                <button type="submit" class="search-btn"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
        </div>

        <% if (!hasSearched) { %>
            <div style="text-align: center; color: #65676b; font-size: 14px; padding: 60px 20px;">
                <i class="fa-solid fa-magnifying-glass" style="font-size: 40px; color: #b0bec5; margin-bottom: 15px;"></i>
                <div>Search something</div>
            </div>
        <% } else { %>
            <!-- Tabs for Users and Posts -->
            <div class="results-nav-tabs">
                <div class="result-tab <%= "usersTab".equals(activeTab) ? "active" : "" %>" onclick="switchTab('usersTab', this)">Users (<%= usersList != null ? usersList.size() : 0 %>)</div>
                <div class="result-tab <%= "postsTab".equals(activeTab) ? "active" : "" %>" onclick="switchTab('postsTab', this)">Posts (<%= postsList != null ? postsList.size() : 0 %>)</div>
            </div>

            <!-- USERS TAB CONTENT -->
            <div id="usersTab" class="tab-content <%= "usersTab".equals(activeTab) ? "active" : "" %>">
                <%
                    if(usersList != null && !usersList.isEmpty()) {
                        for(Map<String, Object> uMap : usersList) {
                            int targetUserId = (Integer) uMap.get("userId");
                            String uName = (String) uMap.get("name");
                            String uEmail = (String) uMap.get("email");
                            String fStatus = (String) uMap.get("friendStatus");
                %>
                <div class="user-item">
                    <div class="user-info-left">
                        <img src="ImageServlet?user_id=<%= targetUserId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="user-avatar" alt="Avatar" onclick="window.location.href='ProfileServlet?user_id=<%= targetUserId %>'">
                        <div>
                            <a href="ProfileServlet?user_id=<%= targetUserId %>" class="user-name"><%= uName %></a>
                            <div class="user-email"><%= uEmail %></div>
                        </div>
                    </div>
                    
                    </div>
                </div>
                <%
                        }
                    } else {
                %>
                    <div style="text-align: center; color: #8a8d91; font-style: italic; font-size: 13px; padding: 30px 0;">No Users Found</div>
                <% } %>
            </div>

            <!-- POSTS TAB CONTENT -->
            <div id="postsTab" class="tab-content <%= "postsTab".equals(activeTab) ? "active" : "" %>">
                <div class="feed-container">
                <%
                    if(postsList != null && !postsList.isEmpty()) {
                        for(Map<String, Object> post : postsList) {
                            int postId = (Integer) post.get("postId");
                            int postUserId = (Integer) post.get("userId");
                            String authorName = (String) post.get("username");
                            String postTitle = (String) post.get("postTitle");
                            String postText = (String) post.get("text");
                            String bgStyle = (String) post.get("bgStyle");
                            String createdAt = (String) post.get("createdAt");
                            int likeCount = (Integer) post.get("likeCount");
                            int commentCount = (Integer) post.get("commentCount");
                            boolean isLikedByMe = post.containsKey("isLikedByMe") && (Boolean) post.get("isLikedByMe");
                            List<String> images = (List<String>) post.get("images");
                            List<Map<String, Object>> commList = (List<Map<String, Object>>) post.get("commentsList");

                            String cardBg = (bgStyle != null && !bgStyle.trim().isEmpty()) ? bgStyle : "#ffffff";
                            String bgStyleAttr = cardBg.startsWith("linear-gradient") ? "background-image: " + cardBg + ";" : "background: " + cardBg + ";";
                %>
                            <div class="post-card" style="<%= bgStyleAttr %>" id="post-<%= postId %>">
                                <div class="post-header-top">
                                    <div class="post-user-info">
                                        <img src="ImageServlet?user_id=<%= postUserId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="post-user-avatar" alt="Avatar" onclick="window.location.href='ProfileServlet?user_id=<%= postUserId %>'">
                                        <div class="post-username-time">
                                            <a href="ProfileServlet?user_id=<%= postUserId %>" class="post-author-name"><%= authorName %></a>
                                            <span class="post-time"><%= createdAt != null ? createdAt : "" %></span>
                                        </div>
                                    </div>
                                </div>

                                <% if(postTitle != null && !postTitle.trim().isEmpty()) { %>
                                    <div class="post-title"><%= postTitle %></div>
                                <% } %>

                                <% if(postText != null && !postText.trim().isEmpty()) { %>
                                    <div class="post-text"><%= postText %></div>
                                <% } %>

                                <% if(images != null && !images.isEmpty()) { %>
                                    <div class="post-images-grid">
                                        <% for(String imgName : images) { %>
                                            <img src="uploads/<%= imgName %>" alt="Post Image" onerror="this.style.display='none';">
                                        <% } %>
                                    </div>
                                <% } %>

                                <div class="post-stats-bar">
                                    <div class="stat-item">
                                        <i class="fa-solid fa-heart" style="color: #fa383e;"></i> <span class="like-count-text"><%= likeCount %></span> likes
                                    </div>
                                    <div class="stat-item" onclick="toggleComments(this)">
                                        <span class="comment-count-text"><%= commentCount %></span> comments
                                    </div>
                                </div>

                                <div class="post-actions-row">
                                    <button type="button" class="action-action-btn like-btn <%= isLikedByMe ? "liked" : "" %>" onclick="handleLike(<%= postId %>, this)">
                                        <i class="<%= isLikedByMe ? "fa-solid" : "fa-regular" %> fa-heart heart-icon" style="<%= isLikedByMe ? "color: #fa383e;" : "" %>"></i> Like
                                    </button>
                                    <button type="button" class="action-action-btn" onclick="toggleComments(this)">
                                        <i class="fa-regular fa-comment"></i> Comment
                                    </button>
                                </div>

                                <div class="comment-section" style="display: none;">
                                    <div class="comment-list">
                                        <%
                                            if(commList != null && !commList.isEmpty()) {
                                                for(Map<String, Object> comm : commList) {
                                                    Integer parentIdObj = (Integer) comm.get("parentId");
                                                    if(parentIdObj == null || parentIdObj == 0) {
                                                        int cId = (Integer) comm.get("commentId");
                                                        int cUserId = (Integer) comm.get("userId");
                                                        String cUser = (String) comm.get("username");
                                                        String cText = (String) comm.get("commentText");
                                                        String displayName = (cUserId == userId) ? "You" : cUser;
                                                        String cTime = (String) comm.get("createdAt");
                                                        if(cTime == null || cTime.trim().isEmpty()) cTime = "Just now";
                                        %>
                                        <div class="comment-item" id="commentItem_<%= cId %>">
                                            <div class="comment-top-row">
                                                <div class="comment-text-content">
                                                    <span class="comment-user"><span><%= displayName %></span>:</span> 
                                                    <span><%= cText %></span>
                                                </div>
                                            </div>
                                            <div class="comment-footer-row">
                                                <span class="comment-time"><%= cTime %></span>
                                                <button type="button" class="comment-reply-btn" onclick="openReplyBox(<%= postId %>, <%= cId %>, '<%= cUser.replace("'", "\\'") %>')">Reply</button>
                                            </div>
                                        </div>

                                        <%
                                                        for(Map<String, Object> reply : commList) {
                                                            Integer rParentId = (Integer) reply.get("parentId");
                                                            if(rParentId != null && rParentId == cId) {
                                                                int rId = (Integer) reply.get("commentId");
                                                                int rUserId = (Integer) reply.get("userId");
                                                                String rUser = (String) reply.get("username");
                                                                String rText = (String) reply.get("commentText");
                                                                String rDisplayName = (rUserId == userId) ? "You" : rUser;
                                                                String ccTime = (String) reply.get("createdAt");
                                                                if(ccTime == null || ccTime.trim().isEmpty()) ccTime = "Just now";
                                        %>
                                        <div class="comment-item is-reply" id="commentItem_<%= rId %>">
                                            <div class="comment-top-row">
                                                <div class="comment-text-content">
                                                    <span class="comment-user"><span><%= rDisplayName %></span>:</span> 
                                                    <span><%= rText %></span>
                                                </div>
                                            </div>
                                            <div class="comment-footer-row">
                                                 <span class="comment-time"><%= ccTime %></span>
                                            </div>
                                        </div>
                                        <%
                                                            }
                                                        }
                                                    }
                                                }
                                            } else {
                                        %>
                                            <div style="color: #8a8d91; text-align: center; font-size: 11px; font-style: italic;">No comments yet.</div>
                                        <% } %>
                                    </div>

                                    <form onsubmit="submitComment(event, <%= postId %>)" class="comment-input-box">
                                        <input type="hidden" name="postId" value="<%= postId %>">
                                        <input type="text" name="commentText" class="comment-input" placeholder="Write Comment" required>
                                        <button type="submit" class="comment-send-btn">Send</button>
                                    </form>
                                </div>
                            </div>
                <%
                        }
                    } else {
                %>
                    <div style="text-align: center; color: #8a8d91; font-style: italic; font-size: 13px; padding: 40px 0;">No posts found</div>
                <% } %>
                </div>
            </div>
        <% } %>
 
    </div>

    <div id="toast"></div>

    <script>
        function switchTab(tabId, tabElement) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.result-tab').forEach(el => el.classList.remove('active'));
            
            const targetContent = document.getElementById(tabId);
            if (targetContent) {
                targetContent.classList.add('active');
            }
            if (tabElement) {
                tabElement.classList.add('active');
            }
        }

        function toggleComments(element) {
            const postCard = element.closest('.post-card');
            const commentSection = postCard.querySelector('.comment-section');
            commentSection.style.display = commentSection.style.display === 'flex' ? 'none' : 'flex';
            if (commentSection.style.display === 'flex') {
                commentSection.querySelector('.comment-input').focus();
            }
        }

        function handleLike(postId, btn) {
            fetch('InteractServlet?action=like&postId=' + postId)
            .then(response => {
                if (response.ok) {
                    const icon = btn.querySelector('.heart-icon');
                    const postCard = document.getElementById('post-' + postId);
                    const countSpan = postCard.querySelector('.like-count-text');
                    let currentCount = parseInt(countSpan.textContent) || 0;

                    if (icon.classList.contains('fa-regular')) {
                        icon.classList.remove('fa-regular');
                        icon.classList.add('fa-solid');
                        icon.style.color = '#fa383e';
                        btn.classList.add('liked');
                        countSpan.textContent = currentCount + 1;
                    } else {
                        icon.classList.remove('fa-solid');
                        icon.classList.add('fa-regular');
                        icon.style.color = '';
                        btn.classList.remove('liked');
                        countSpan.textContent = Math.max(0, currentCount - 1);
                    }
                }
            })
            .catch(err => console.error("Error liking post:", err));
        }

        function submitComment(event, postId) {
            event.preventDefault();
            const form = event.target;
            
            const cTextInput = form.querySelector('input[name="commentText"]');
            const cText = cTextInput ? cTextInput.value : "";
            if (!cText.trim()) return;

            const formData = new FormData(form);
            formData.append('action', 'comment');

            fetch('InteractServlet', {
                method: 'POST',
                body: new URLSearchParams(formData)
            })
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                if (data.status === "success" || data.commentId) {
                    window.location.href = window.location.pathname + window.location.search + '#post-' + postId;
                    location.reload();
                }
            })
            .catch(err => {
                console.error("Error submitting comment:", err);
                window.location.href = window.location.pathname + window.location.search + '#post-' + postId;
                location.reload();
            });
        }

        window.addEventListener('DOMContentLoaded', () => {
            if (window.location.hash) {
                const postsTabBtn = document.querySelectorAll('.result-tab')[1];
                if (postsTabBtn) {
                    switchTab('postsTab', postsTabBtn);
                }

                setTimeout(() => {
                    const targetPostCard = document.querySelector(window.location.hash);
                    if (targetPostCard) {
                        const commentSection = targetPostCard.querySelector('.comment-section');
                        if (commentSection) {
                            commentSection.style.display = 'flex';
                        }
                        targetPostCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                }, 150);
            }
        });

        function openReplyBox(postId, commentId, userName) {
            const existingReplyBox = document.getElementById('activeReplyBox_' + commentId);
            if (existingReplyBox) {
                existingReplyBox.remove();
                return;
            }
            const commentItem = document.getElementById('commentItem_' + commentId);
            const replyBoxHtml = document.createElement('form');
            replyBoxHtml.id = 'activeReplyBox_' + commentId;
            replyBoxHtml.className = 'reply-input-box';
            replyBoxHtml.onsubmit = function(event) {
                submitReply(event, postId, commentId);
            };
            replyBoxHtml.innerHTML = 
                '<input type="text" name="commentText" class="reply-input" placeholder="Reply to ' + userName + ' " required autofocus>' +
                '<button type="submit" class="reply-send-btn">Send</button>';
            commentItem.appendChild(replyBoxHtml);
        }

        function submitReply(event, postId, parentCommentId) {
            event.preventDefault();
            const form = event.target;
            const commentInput = form.querySelector('input[name="commentText"]');
            const commentText = commentInput ? commentInput.value : "";
            if (!commentText.trim()) return;

            const params = new URLSearchParams();
            params.append('action', 'comment');
            params.append('postId', postId);
            params.append('commentText', commentText);
            params.append('parentId', parentCommentId);

            fetch('InteractServlet', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: params.toString()
            })
            .then(response => response.json())
            .then(data => {
                form.remove();
                showToast('Reply sent!');
                window.location.href = window.location.pathname + window.location.search + '#post-' + postId;
                location.reload();
            })
            .catch(err => console.error("Error submitting reply:", err));
        }

        function showToast(message) {
            const toast = document.getElementById('toast');
            toast.innerText = message;
            toast.classList.add('show');
            setTimeout(() => { toast.classList.remove('show'); }, 2000);
        }
    </script>
</body>
</html>