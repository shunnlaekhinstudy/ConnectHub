<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
Integer userId = (Integer) session.getAttribute("user_id");
String userName = (String) session.getAttribute("userName");

if (userId == null) {
    response.sendRedirect("index.jsp");
    return;
}
String savedBg = (String) session.getAttribute("appBgColor");
if(savedBg == null) savedBg = "#ffffff";
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Connect Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        
        body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; overflow: hidden; }
        
        :root {
            --app-bg: <%= session.getAttribute("appBgColor") != null ? session.getAttribute("appBgColor") : "#ffffff" %>;
        }

        .phone-container { 
            width: 100%; 
            max-width: 480px; 
            background: var(--app-bg) !important; 
            background-attachment: fixed;
            height: 100vh; 
            max-height: 100vh;
            box-shadow: 0 0 15px rgba(0,0,0,0.1); 
            position: relative; 
            display: flex; 
            flex-direction: column; 
        }
        .notif-header-top { display: flex; align-items: center; gap: 12px; padding: 15px 20px; background: var(--app-bg) !important;  border-bottom: 1px solid #e4e6eb; flex-shrink: 0; }
        .back-arrow-btn { font-size: 20px; color: #2e7d32; cursor: pointer; padding: 4px 8px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: background 0.2s; text-decoration: none; }
        .back-arrow-btn:hover { background-color: #f2f2f2; }
        
        .notif-title { font-size: 24px; font-weight: 800; color: #2e7d32; cursor: pointer; }
        
        .notif-list-container { 
            flex: 1; 
            overflow-y: auto; 
            padding-bottom: 30px; 
            scrollbar-width: none; 
        }
        .notif-list-container::-webkit-scrollbar { 
            display: none; 
        }

        .notif-item { display: flex; align-items: center; justify-content: space-between; padding: 12px 20px; cursor: pointer; 
        transition: background 0.2s; text-decoration: none; color: inherit; background: var(--app-bg) !important;  position: relative; border-bottom: 1px solid #f8f9fa; }
        .notif-item:hover { background-color: #f2f2f2; }
        .notif-item.unread { background-color: #e8f5e9; }

        .notif-left { display: flex; align-items: center; gap: 12px; flex: 1; text-decoration: none; color: inherit; }
        .notif-avatar-wrapper { position: relative; width: 56px; height: 56px; flex-shrink: 0; }
        .notif-avatar { width: 56px; height: 56px; border-radius: 50%; object-fit: cover; }
        
        .badge-icon {
            position: absolute; bottom: 0; right: 0; width: 22px; height: 22px;
            background-color: #2e7d32; color: #ffffff; border-radius: 50%;
            display: flex; align-items: center; justify-content: center; font-size: 11px; border: 2px solid #ffffff;
        }

        .notif-info { display: flex; flex-direction: column; gap: 2px; flex: 1; }
        .notif-text { font-size: 14.5px; color: #050505; line-height: 1.35; }
        .notif-text b { font-weight: 600; color: #050505; }
        .notif-time { font-size: 11.5px; color: #65676b; margin-top: 2px; }
        .unread.notif-item .notif-time { color: #2e7d32; font-weight: 600; }

        .notif-options-wrapper { position: relative; }
        .dots-btn { background: none; border: none; font-size: 18px; color: #65676b; cursor: pointer; padding: 8px 10px; border-radius: 50%; }
        .dots-btn:hover { background-color: rgba(0,0,0,0.05); color: #050505; }

        .options-dropdown {
            display: none; position: absolute; right: 0; top: 35px;
            background: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            border-radius: 8px; z-index: 10; width: 160px; overflow: hidden;
        }
        .options-dropdown.show { display: block; }
        .delete-option {
            padding: 10px 15px; font-size: 14px; color: #d93838;
            cursor: pointer; display: flex; align-items: center; gap: 8px; text-decoration: none;
        }
        .delete-option:hover { background-color: #f8f9fa; }
    </style>
</head>
<body>
<div class="phone-container">
    <div class="notif-header-top">
        <a href="HomeServlet" class="back-arrow-btn" title="ပင်မသို့">
            <i class="fa-solid fa-arrow-left"></i>
        </a>
        <div class="notif-title" onclick="window.location.href='HomeServlet'">Notifications</div>
    </div>

    <div class="notif-list-container">
        <c:choose>
            <c:when test="${not empty notifications}">
                <c:forEach var="notif" items="${notifications}">
                    <%-- 🌟 ပြင်ဆင်ချက်: is_read (သို့မဟုတ် isRead အနေဖြင့် Map ထဲတွင်ပါလာသည်ကို စစ်ဆေးရန်) --%>
                    <div class="notif-item ${notif.is_read == 0 || notif.isRead == 0 ? 'unread' : ''}" id="notif-row-${notif.id}">
                        <div class="notif-left" onclick="markAsReadAndRedirect(${notif.id}, '${notif.targetUrl}')">
                            <div class="notif-avatar-wrapper">
                                <img src="${notif.actorAvatar}" class="notif-avatar" alt="">
                                <div class="badge-icon"><i class="${notif.iconClass}"></i></div>
                            </div>
                            <div class="notif-info">
                                <div class="notif-text">${notif.notifText}</div>
                                <div class="notif-time">${notif.formattedTime}</div>
                            </div>
                        </div>
                        <div class="notif-options-wrapper">
                            <button class="dots-btn" onclick="toggleDropdown(event, ${notif.id})"><i class="fa-solid fa-ellipsis"></i></button>
                            <div class="options-dropdown" id="dropdown-${notif.id}">
                                <a href="javascript:void(0);" onclick="deleteNotification(${notif.id})" class="delete-option">
                                    <i class="fa-solid fa-trash"></i> Delete notification
                                </a>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </c:when>
            <c:otherwise>
                <div style="text-align: center; color: #65676b; padding: 40px;">No notifications found.</div>
            </c:otherwise>
        </c:choose>
    </div>
</div>

<script>
    function markAsReadAndRedirect(notifId, targetUrl) {
        fetch("NotificationServlet?action=markRead&notif_id=" + notifId, {
            method: "POST"
        }).finally(() => {
            if (targetUrl && targetUrl !== "null" && targetUrl !== "") {
                window.location.href = targetUrl;
            } else {
                window.location.href = "HomeServlet";
            }
        });
    }

    function toggleDropdown(event, id) {
        event.stopPropagation();
        document.querySelectorAll('.options-dropdown').forEach(el => {
            if(el.id !== 'dropdown-' + id) el.classList.remove('show');
        });
        let dropdown = document.getElementById('dropdown-' + id);
        dropdown.classList.toggle('show');
    }

    window.onclick = function(event) {
        if (!event.target.matches('.dots-btn') && !event.target.closest('.dots-btn')) {
            document.querySelectorAll('.options-dropdown').forEach(el => {
                el.classList.remove('show');
            });
        }
    }

    function deleteNotification(notifId) {
        if (confirm("Are you sure you want to delete this notification?")) {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "NotificationServlet?action=delete&notif_id=" + notifId, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    let row = document.getElementById('notif-row-' + notifId);
                    if (row) {
                        row.style.transition = "opacity 0.3s";
                        row.style.opacity = "0";
                        setTimeout(() => row.remove(), 300);
                    }
                }
            };
            xhr.send();
        }
    }
</script>
</body>
</html>