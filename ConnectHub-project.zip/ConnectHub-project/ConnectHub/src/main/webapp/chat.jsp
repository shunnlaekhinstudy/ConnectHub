<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<%@ page import="java.time.*" %>
<%@ page import="java.time.format.*" %>
<!DOCTYPE html>
<html lang="my">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chat</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
body { 
    background-color: #f0f2f5; 
    color: #050505; 
    display: flex; 
    justify-content: center; 
    align-items: center; 
    min-height: 100vh; /* height: 100vh အစား min-height ကိုပြောင်းပါ */
    margin: 0; 
    overflow-y: auto; 
}

.phone-container { 
    width: 100%; 
    max-width: 480px; 
    background-color: #ffffff; 
    height: 90vh; 
    max-height: 100vh; /* ဖုန်းလိုမျိုး အနေအထားအတည်ဖြစ်စေရန် */
    box-shadow: 0 0 15px rgba(0,0,0,0.1); 
    position: relative; 
    display: flex; 
    flex-direction: column; 
    overflow: hidden; 
}

.chat-body {
    flex: 1 1 auto; /* Flex က ဘောက်စ်အလိုက် နေရာညှိပေးရန် */
    overflow-y: auto;
    padding: 35px 20px 20px 20px;
    display: flex;
    flex-direction: column;
    gap: 15px;
    background-color: #ffffff;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.chat-header { display: flex; align-items: center; justify-content: space-between; padding: 10px 15px; background-color: #fff; border-bottom: 1px solid #e4e6eb; z-index: 100; flex-shrink: 0; }
.chat-header-left { display: flex; align-items: center; gap: 12px; }
.back-btn { font-size: 18px; color: #2e7d32; cursor: pointer; text-decoration: none; display: flex; align-items: center; justify-content: center; width: 35px; height: 35px; border-radius: 50%; }
.back-btn:hover { background-color: #f0f2f5; }

.profile-link { display: flex; align-items: center; gap: 10px; text-decoration: none; color: inherit; cursor: pointer; }
.chat-header-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; }
.chat-header-name { font-size: 16px; font-weight: 600; }

.bg-picker-container { position: relative; z-index: 150; }
.bg-picker-btn { background: none; border: none; font-size: 22px; color: #2e7d32; cursor: pointer; padding: 5px; display: flex; align-items: center; justify-content: center; }
.color-palette { display: none; position: absolute; right: 0; top: 45px; background: #fff; border: 1px solid #ddd; border-radius: 10px; padding: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); z-index: 200; width: 220px; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.color-palette.show { display: grid; }
.palette-item { width: 42px; height: 42px; border-radius: 8px; cursor: pointer; border: 1px solid #ccc; background-size: cover !important; background-position: center !important; background-repeat: no-repeat !important; }

 
.chat-body::-webkit-scrollbar { display: none; }

.message-wrapper { display: flex; flex-direction: column; position: relative; max-width: 80%; margin-bottom: 8px; }
.message-wrapper.incoming { align-items: flex-start; align-self: flex-start; }
.message-wrapper.outgoing { align-items: flex-end; align-self: flex-end; }

.message-content-row { display: flex; align-items: flex-end; gap: 8px; position: relative; margin-bottom: 12px; }
.message-wrapper.outgoing .message-content-row { flex-direction: row-reverse; }

.message { padding: 10px 14px; border-radius: 18px; font-size: 14px; line-height: 1.4; word-break: break-word; }
.message.incoming { background-color: #f0f2f5; color: #050505; }
.message.outgoing { background-color: #2e7d32; color: white; }

.replied-box { font-size: 12px; padding: 4px 8px; margin-bottom: 6px; border-radius: 6px; border-left: 3px solid rgba(255,255,255,0.8); background: rgba(0,0,0,0.08); opacity: 0.9; }
.message.incoming .replied-box { border-left-color: #2e7d32; background: rgba(0,0,0,0.04); color: #444; }

.msg-time { font-size: 11px; color: #65676b; white-space: nowrap; margin-bottom: 2px; }

.msg-reaction { position: absolute; bottom: -16px; background: #fff; border: 1px solid #ddd; border-radius: 12px; padding: 2px 6px; font-size: 13px; box-shadow: 0 2px 5px rgba(0,0,0,0.15); z-index: 5; cursor: pointer; }
.message-wrapper.outgoing .msg-reaction { right: 12px; left: auto; }
.message-wrapper.incoming .msg-reaction { left: 12px; right: auto; }

.popup-menu-container { display: none; position: absolute; background: #fff; border-radius: 14px; box-shadow: 0 5px 25px rgba(0,0,0,0.25); z-index: 300; width: 220px; padding: 8px 0; }
.popup-menu-container.show { display: block; }
.reaction-bar { display: flex; justify-content: space-around; padding: 5px 10px; border-bottom: 1px solid #eee; font-size: 18px; margin-bottom: 5px; }
.reaction-bar span { cursor: pointer; transition: transform 0.2s; }
.reaction-bar span:hover { transform: scale(1.3); }

.menu-options { display: flex; flex-direction: column; }
.menu-item { padding: 10px 18px; font-size: 14px; color: #333; display: flex; align-items: center; gap: 12px; cursor: pointer; text-decoration: none; }
.menu-item:hover { background-color: #f2f2f2; }
.menu-item i { width: 16px; color: #555; }
.menu-item.delete { color: #d32f2f; }
.menu-item.delete i { color: #d32f2f; }

.reply-preview { display: none; background: #f0f2f5; padding: 8px 12px; font-size: 13px; border-left: 3px solid #2e7d32; justify-content: space-between; align-items: center; flex-shrink: 0; }
.reply-preview.show { display: flex; }

.chat-footer { padding: 10px 15px; background-color: #fff; border-top: 1px solid #e4e6eb; display: flex; flex-direction: column; gap: 5px; flex-shrink: 0; z-index: 100; }
.chat-input-row { display: flex; align-items: center; gap: 10px; width: 100%; }
.chat-input { flex: 1; background-color: #f0f2f5; border: none; border-radius: 20px; padding: 10px 15px; outline: none; font-size: 14px; }
.send-btn { background: #2e7d32; color: white; border: none; width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 15px; }
</style>
</head>
<body>
<div class="phone-container">
    <div class="chat-header">
        <div class="chat-header-left">
            <a href="MessageServlet" class="back-btn"><i class="fa-solid fa-arrow-left"></i></a>
            <a href="<%= request.getAttribute("profileLink") %>" class="profile-link">
                <img src="<%= request.getAttribute("receiverAvatar") %>" 
                     onerror="this.src='images/default-avatar.png'" 
                     class="chat-header-avatar" alt="Avatar" >
                <div class="chat-header-name"><%= request.getAttribute("receiverName") != null ? request.getAttribute("receiverName") : "User" %></div>
            </a>
        </div>
        <div class="bg-picker-container">
            <button class="bg-picker-btn" onclick="toggleColorPalette(event)"><i class="fa-solid fa-palette"></i></button>
            <div id="colorPalette" class="color-palette">
    <!-- ၁။ Minimalist & Clean Styles -->
    <div class="palette-item" style="background-color: #ffffff;" onclick="changeBg('#ffffff', 'color')" title="White"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1507090803761-d4e5170d10d9?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1507090803761-d4e5170d10d9?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?w=600', 'image')"></div>

    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1519681393784-d120267933ba?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1519681393784-d120267933ba?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1538388063390-1e2f3d91c6bf?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1538388063390-1e2f3d91c6bf?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=600', 'image')"></div>

    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1426604966848-d7adac902bff?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1426604966848-d7adac902bff?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600', 'image')"></div>

    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1473448912268-2022ce9509d8?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1473448912268-2022ce9509d8?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600', 'image')"></div>
<div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=600', 'image')"></div>

    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1557683316-973673baf926?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1557683316-973673baf926?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1513151233558-d860c5398176?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1558470598-a5dda9640f68?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1558470598-a5dda9640f68?w=600', 'image')"></div>

    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1500462918059-b1a0cb512f1d?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1500462918059-b1a0cb512f1d?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1538370965046-79c0d6907d47?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1538370965046-79c0d6907d47?w=600', 'image')"></div>

    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1517976487504-5544773d32fa?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1517976487504-5544773d32fa?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1502134249126-9f3755a50d78?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600', 'image')"></div>
    <div class="palette-item" style="background-image: url('https://images.unsplash.com/photo-1531306728370-e2ebd9d7bb99?w=600');" onclick="changeBg('https://images.unsplash.com/photo-1531306728370-e2ebd9d7bb99?w=600', 'image')"></div>
</div>
        </div>
    </div>

    <!-- Chat Messages -->
    <div class="chat-body" id="chatBody">
    <%
    String savedBg = (String) session.getAttribute("appBgColor");
    if(savedBg == null) savedBg = "#ffffff"; 
    List<?> messageList = (List<?>) request.getAttribute("messageList");
    Object currentUserIdObj = session.getAttribute("user_id");

    if (messageList != null) {
        for (Object obj : messageList) {
            Map<?, ?> msg = (Map<?, ?>) obj;
            Object msgId = msg.get("id");
            Object senderId = msg.get("sender_id");
            String rawMsgText = (String) msg.get("message");
            String timeStr = (String) msg.get("time");
            
            if (timeStr == null || timeStr.trim().isEmpty()) {
                ZonedDateTime nowMyt = ZonedDateTime.now(ZoneId.of("Asia/Yangon"));
                timeStr = nowMyt.format(DateTimeFormatter.ofPattern("hh:mm a"));
            }

            String reaction = (String) msg.get("reaction");
            
            boolean isOutgoing = false;
            if (senderId != null && currentUserIdObj != null) {
                isOutgoing = String.valueOf(senderId).trim().equals(String.valueOf(currentUserIdObj).trim());
            }
            
            String displayMsg = rawMsgText;
            String repliedText = null;
            if (rawMsgText != null && rawMsgText.startsWith("[Repled]")) {
                String[] parts = rawMsgText.split("\n--- \n", 2);
                if (parts.length == 2) {
                    repliedText = parts[0].replace("[Repled] ", "").trim();
                    displayMsg = parts[1];
                }
            }
            
            String safeRawText = (rawMsgText != null) ? rawMsgText.replace("'", "\\'").replace("\"", "&quot;").replaceAll("[\\r\\n]+", " ") : "";
    %>
    <div class="message-wrapper <%= isOutgoing ? "outgoing" : "incoming" %>" 
         onmouseenter="openMenu(event, this, '<%= safeRawText %>', '<%= msgId %>', <%= isOutgoing %>)"
         onmouseleave="closeMenu()">
        <div class="message-content-row">
            <div class="message <%= isOutgoing ? "outgoing" : "incoming" %>">
                <% if(repliedText != null) { %>
                <div class="replied-box">
                    <i class="fa-solid fa-reply"></i> <%= repliedText %>
                </div>
                <% } %>
                <%= displayMsg %>
            </div>
            <div class="msg-time"><%= timeStr %></div>
            <% if(reaction != null && !reaction.trim().isEmpty()) { %>
            <div class="msg-reaction" onclick="removeReaction(event, '<%= msgId %>', '<%= reaction %>')"><%= reaction %></div>
            <% } %>
        </div>
    </div>
    <%
        }
    }
    %>
    </div>

    <!-- Popup Menu Box -->
    <div id="popupMenu" class="popup-menu-container" onmouseenter="keepMenu()" onmouseleave="closeMenu()">
        <div class="reaction-bar">
            <span onclick="submitReaction('❤️')">❤️</span>
            <span onclick="submitReaction('👍')">👍</span>
            <span onclick="submitReaction('🔥')">🔥</span>
            <span onclick="submitReaction('😂')">😂</span>
            <span onclick="submitReaction('😮')">😮</span>
            <span onclick="submitReaction('😢')">😢</span>
        </div>
        <div class="menu-options">
            <div class="menu-item" onclick="executeReply()"><i class="fa-solid fa-reply"></i> Reply</div>
            <div class="menu-item" onclick="executeCopy()"><i class="fa-solid fa-copy"></i> Copy</div>
            <div class="menu-item delete" onclick="executeDelete()"><i class="fa-solid fa-trash"></i> Delete</div>
        </div>
    </div>

    <!-- Reply Preview Bar -->
    <div id="replyPreview" class="reply-preview">
        <div id="replyTextContainer" style="font-size: 12px; color: #555; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 380px;"></div>
        <i class="fa-solid fa-xmark" style="cursor: pointer; color: #777;" onclick="cancelReply()"></i>
    </div>

    <form id="actionForm" action="MessageServlet" method="POST" style="display:none;">
        <input type="hidden" name="receiver_id" value="<%= request.getAttribute("receiverId") %>">
        <input type="hidden" name="action_type" id="formActionType">
        <input type="hidden" name="message_id" id="formMessageId">
        <input type="hidden" name="emoji" id="formEmoji">
    </form>

    <!-- Chat Input Form -->
    <form action="MessageServlet" method="POST" class="chat-footer" id="chatForm">
        <input type="hidden" name="receiver_id" value="<%= request.getAttribute("receiverId") %>">
        <input type="hidden" name="action_type" id="actionType" value="send">
        <input type="hidden" name="message_id" id="messageId" value="">
        <input type="hidden" name="reply_to" id="replyToInput" value="">
        <div class="chat-input-row">
            <input type="text" name="message" id="messageInput" class="chat-input" placeholder="Type message" required autocomplete="off">
            <button type="submit" class="send-btn"><i class="fa-solid fa-paper-plane" id="sendIcon"></i></button>
        </div>
    </form>
</div>

<script>
let activeMsgId = "";
let activeMsgText = "";
let closeTimer = null;

window.addEventListener('DOMContentLoaded', () => {
    const savedBg = localStorage.getItem('chat_bg');
    const savedType = localStorage.getItem('chat_bg_type');
    if (savedBg) {
        applyBackground(savedBg, savedType);
    }
});

function toggleColorPalette(event) {
    event.stopPropagation();
    document.getElementById('colorPalette').classList.toggle('show');
}

function changeBg(value, type) {
    applyBackground(value, type);
    localStorage.setItem('chat_bg', value);
    localStorage.setItem('chat_bg_type', type);
    const palette = document.getElementById('colorPalette');
    if(palette) palette.classList.remove('show');
}

function applyBackground(value, type) {
    const chatBody = document.getElementById('chatBody');
    if (!chatBody) return;
    if(type === 'color') {
        chatBody.style.background = value;
        chatBody.style.backgroundColor = value;
    } else {
        chatBody.style.background = 'url(' + value + ') center/cover no-repeat';
    }
}

function openMenu(event, element, text, id, isOutgoing) {
    if (closeTimer) clearTimeout(closeTimer);
    activeMsgId = id;
    activeMsgText = text;
    const menu = document.getElementById('popupMenu');
    menu.classList.add('show');

    const rect = element.getBoundingClientRect();
    const containerRect = document.querySelector('.phone-container').getBoundingClientRect();
    
    let topPos = rect.top - containerRect.top - 70;
    if (topPos < 10) topPos = rect.bottom - containerRect.top + 10;

    menu.style.top = topPos + 'px';
    menu.style.left = isOutgoing ? '160px' : '40px';
}

function closeMenu() {
    closeTimer = setTimeout(() => {
        const menu = document.getElementById('popupMenu');
        if (menu) menu.classList.remove('show');
    }, 200);
}

function keepMenu() {
    if (closeTimer) clearTimeout(closeTimer);
}

window.addEventListener('click', function(event) {
    const palette = document.getElementById('colorPalette');
    const pickerContainer = document.querySelector('.bg-picker-container');
    if (palette && pickerContainer && !pickerContainer.contains(event.target)) {
        palette.classList.remove('show');
    }
});

function submitReaction(emoji) {
    document.getElementById('formActionType').value = "reaction";
    document.getElementById('formMessageId').value = activeMsgId;
    document.getElementById('formEmoji').value = emoji;
    document.getElementById('actionForm').submit();
}

function removeReaction(event, id, emoji) {
    event.stopPropagation();
    document.getElementById('formActionType').value = "reaction";
    document.getElementById('formMessageId').value = id;
    document.getElementById('formEmoji').value = emoji;
    document.getElementById('actionForm').submit();
}

function executeReply() {
    document.getElementById('replyToInput').value = activeMsgText;
    document.getElementById('replyTextContainer').innerText = "Replying to: " + activeMsgText;
    document.getElementById('replyPreview').classList.add('show');
    document.getElementById('messageInput').focus();
}

function cancelReply() {
    document.getElementById('replyToInput').value = "";
    document.getElementById('replyPreview').classList.remove('show');
}

function executeCopy() {
    navigator.clipboard.writeText(activeMsgText);
    alert("Copied to clipboard!");
}

function executeDelete() {
    if(confirm("Are you sure you want to delete this message?")) {
        document.getElementById('formActionType').value = "delete";
        document.getElementById('formMessageId').value = activeMsgId;
        document.getElementById('actionForm').submit();
    }
}

const chatBodyEl = document.getElementById('chatBody');
if(chatBodyEl) {
    chatBodyEl.scrollTop = chatBodyEl.scrollHeight;
}
 

</script>
</body>
</html>