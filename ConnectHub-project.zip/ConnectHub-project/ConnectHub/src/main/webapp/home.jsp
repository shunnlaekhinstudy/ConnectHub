<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<%
// Session ထဲမှ user_id ကို ခေါ်ယူခြင်း
Integer userId = (Integer) session.getAttribute("user_id");
String userName = (String) session.getAttribute("userName");
if (userName == null) {
    userName = (String) session.getAttribute("user");
}
if (userName == null) {
    userName = "User";
}

// Login ဝင်ထားခြင်း မရှိလျှင် index.jsp သို့ ပြန်ပို့ရန်
if (userId == null) {
    response.sendRedirect("index.jsp");
    return;
}
String savedBg = (String) session.getAttribute("appBgColor");
if(savedBg == null) savedBg = "#ffffff";

// HomeServlet သို့မဟုတ် Feed Controller မှ ပေးပို့လာသော Posts များကို လက်ခံရန်
List<Map<String, Object>> feedPostsList = (List<Map<String, Object>>) request.getAttribute("feedPostsList");

// Servlet မှ ပို့လာသော အနီစက် တန်ဖိုးများကို တစ်ခါတည်းသာ သတ်မှတ်ရန်
Integer unreadCountObj = (Integer) request.getAttribute("unreadCount");
int unreadCount = (unreadCountObj != null) ? unreadCountObj : 0;

boolean hasUnreadNotifications = request.getAttribute("hasUnreadNotifications") != null && (Boolean) request.getAttribute("hasUnreadNotifications");
boolean hasPendingRequests = request.getAttribute("hasPendingRequests") != null && (Boolean) request.getAttribute("hasPendingRequests");
boolean hasUnreadMessages = request.getAttribute("hasUnreadMessages") != null && (Boolean) request.getAttribute("hasUnreadMessages");
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connect Hub - Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        
        :root {
            --app-bg: <%= savedBg %>;
        }

        .phone-container { 
            width: 100%; 
            max-width: 480px; 
            background: var(--app-bg) !important; 
            background-attachment: fixed;
            min-height: 100vh; 
            box-shadow: 0 0 15px rgba(0,0,0,0.1); 
            position: relative; 
            display: flex; 
            flex-direction: column; 
            padding-bottom: 30px;
        }
        
        .header { display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; background: var(--app-bg) !important;  position: sticky; top: 0; z-index: 100; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); }
        .logo-area { display: flex; align-items: center; gap: 10px; }
        .menu-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: #2e7d32; }
        .logo { color: #2e7d32; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; cursor: pointer; }
        .header-icons { display: flex; gap: 8px; }
        .icon-btn { background-color: #e8f5e9; border: none; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 16px; color: #2e7d32; cursor: pointer; }

        .nav-tabs { display: flex; justify-content: space-around; background: var(--app-bg) !important;  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); padding: 0 10px; position: sticky; top: 57px; z-index: 99; }
        .nav-tab { flex: 1; text-align: center; padding: 12px 0; font-size: 20px; color: #65676b; cursor: pointer; position: relative; }
        .nav-tab.active { color: #2e7d32; }
        .nav-tab.active::after { content: ''; position: absolute; bottom: 0; left: 0; width: 100%; height: 3px; background-color: #2e7d32; }

        .create-post-box { display: flex; align-items: center; gap: 10px; padding: 10px 15px; background-color: transparent !important; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); }
        .avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; cursor: pointer; }
        .post-input-fake { flex: 1; background-color: #f0f2f5; border: 1px solid #e4e6eb; padding: 10px 15px; border-radius: 20px; color: #65676b; font-size: 15px; cursor: pointer; }
        .post-input-fake:hover { background-color: #e4e6eb; }
        .post-img-icon { font-size: 22px; color: #2e7d32; cursor: pointer; padding: 5px; }

        .feed-container { display: flex; flex-direction: column; gap: 15px; padding: 15px; }
        
        .post-card { padding: 15px; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #e4e6eb; background-color: #ffffff; position: relative; text-align: left; }
        .post-header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        .post-user-info { display: flex; align-items: center; gap: 8px; }
        .post-user-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; }
        .post-username-time { display: flex; flex-direction: column; }
        .post-author-name { font-size: 13px; font-weight: 700; color: #050505; text-decoration: none; }
        .post-author-name:hover { text-decoration: underline; }
        .post-time { color: #65676b; font-size: 11px; }

        .post-options-btn { background: none; border: none; font-size: 16px; cursor: pointer; color: #65676b; padding: 4px 8px; }
        .post-dropdown-menu { display: none; position: absolute; right: 0; top: 40px; background: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.15); border-radius: 6px; overflow: hidden; z-index: 10; width: 110px; border: 1px solid #e4e6eb; }
        .post-dropdown-menu a { display: block; padding: 8px 12px; font-size: 12px; color: #050505; text-decoration: none; }
        .post-dropdown-menu a:hover { background-color: #f0f2f5; }
        .delete-option { color: #fa383e !important; }
        
        .post-title { font-size: 16px; font-weight: 700; color: #050505; margin-bottom: 4px; }
        .post-text { font-size: 14px; color: #050505; word-break: break-word; margin-bottom: 10px; line-height: 1.4; }
        .post-images-grid { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
        .post-images-grid img { width: 100%; max-height: 280px; object-fit: cover; border-radius: 6px; } 

        .post-stats-bar { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #e4e6eb; font-size: 13px; color: #65676b; margin-top: 10px; }
        .stat-item { cursor: pointer; display: flex; align-items: center; gap: 5px; }
        .stat-item:hover { color: #2e7d32; }

        .post-actions-row { display: flex; justify-content: space-around; padding-top: 6px; margin-top: 4px; }
        .action-action-btn { background: none; border: none; font-size: 13px; font-weight: 600; color: #65676b; cursor: pointer; display: flex; align-items: center; gap: 6px; padding: 6px 15px; border-radius: 4px; }
        .action-action-btn:hover { background-color: #f0f2f5; color: #2e7d32; }
        .action-action-btn.liked .heart-icon { color: #fa383e; }
        
        .reply-input-box {
            display: flex;
            gap: 6px;
            margin-top: 6px;
            margin-left: 15px;
            align-items: center;
        }
        .reply-input {
            flex: 1;
            padding: 5px 10px;
            border: 1px solid #ccd0d5;
            border-radius: 15px;
            font-size: 12px;
            outline: none;
            background: #ffffff;
        }
        .reply-send-btn {
            background: #2e7d32;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
        }
        .comment-item { 
            background: #f0f2f5; 
            padding: 8px 12px; 
            border-radius: 12px; 
            display: flex; 
            flex-direction: column; 
            gap: 4px; 
            position: relative;
            width: 100%;
            box-sizing: border-box;
        }
        /* Reply ဖြစ်ပါက ဘယ်ဘက်မှ အနည်းငယ်ဝင်ရန် */
        .comment-item.is-reply {
            margin-left: 20px;
            width: calc(100% - 20px);
            background: #e4e6eb;
        }

        .comment-top-row {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            width: 100%;
            gap: 8px;
        }
        .comment-text-content {
            flex: 1;
            word-break: break-word;
            overflow-wrap: break-word;
            font-size: 13px;
            color: #050505;
            min-width: 0;
        }
        .comment-footer-row {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 11px;
            color: #65676b;
            padding-left: 2px;
        }
        .comment-reply-btn {
            background: none;
            border: none;
            font-size: 11px;
            font-weight: 600;
            color: #65676b;
            cursor: pointer;
            padding: 0;
        }
        .comment-reply-btn:hover {
            text-decoration: underline;
            color: #2e7d32;
        }
        .comment-menu-wrapper {
            position: relative;
            flex-shrink: 0;
        }
        .comment-dots-btn {
            background: none;
            border: none;
            font-size: 14px;
            color: #65676b;
            cursor: pointer;
            padding: 2px 6px;
            border-radius: 50%;
        }
        .comment-dots-btn:hover {
            background-color: rgba(0,0,0,0.05);
        }
        .comment-dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 22px;
            background: #ffffff;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            border-radius: 6px;
            overflow: hidden;
            z-index: 10;
            width: 100px;
            border: 1px solid #e4e6eb;
        }
        .comment-dropdown-menu.show {
            display: block;
        }
        .comment-dropdown-menu button {
            display: block;
            width: 100%;
            text-align: left;
            padding: 6px 10px;
            font-size: 11px;
            color: #050505;
            background: none;
            border: none;
            cursor: pointer;
        }
        .comment-dropdown-menu button:hover {
            background-color: #f0f2f5;
        }
        
        .comment-section {
            display: none;
            flex-direction: column;
            gap: 10px;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid #e4e6eb;
        }
        .comment-list { 
            font-size: 12px; 
            display: flex; 
            flex-direction: column; 
            gap: 6px; 
            max-height: 250px; 
            overflow-y: auto; 
            width: 100%;
            scrollbar-width: none; /* Firefox အတွက် */
        }
        .comment-list::-webkit-scrollbar {
            display: none; /* Chrome, Safari, Edge အတွက် Scroll bar ဖျောက်ရန် */
        }
        .comment-input-box { 
            display: flex; 
            gap: 8px; 
            width: 100%; 
            align-items: center; 
        }
        .comment-input { 
            flex: 1; 
            padding: 8px 12px; 
            border: 1px solid #e4e6eb; 
            border-radius: 20px; 
            font-size: 13px; 
            outline: none; 
            background: #ffffff; 
        }
        /* Red Dot Badge Styling */
        .red-dot {
            position: absolute;
            top: 8px;
            right: 35%;
            width: 8px;
            height: 8px;
            background-color: #fa383e;
            border-radius: 50%;
            border: 1px solid #ffffff;
        }
        .comment-send-btn { 
            background: #2e7d32; 
            color: #fff; 
            border: none; 
            padding: 8px 14px; 
            border-radius: 20px; 
            font-size: 12px; 
            font-weight: 600; 
            cursor: pointer; 
            flex-shrink: 0;
        }
        #likesModal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center; }
        .modal-content { background: #fff; width: 85%; max-width: 320px; border-radius: 8px; padding: 15px; max-height: 350px; overflow-y: auto; text-align: left; }
        
        #toast { visibility: hidden; min-width: 220px; background-color: #333; color: #fff; text-align: center; border-radius: 4px; padding: 10px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; }
        #toast.show { visibility: visible; animation: fadein 0.5s, fadeout 0.5s 1.5s; }
        @keyframes fadein { from { bottom: 0; opacity: 0; } to { bottom: 30px; opacity: 1; } }
        @keyframes fadeout { from { bottom: 30px; opacity: 1; } to { bottom: 0; opacity: 0; } }
        
        .swal2-popup { font-size: 14px !important; }
    </style>
</head>
<body>

    <input type="hidden" id="loggedInUserName" value="<%= userName %>">
    <input type="hidden" id="loggedInUserId" value="<%= userId %>">

    <div class="phone-container">
        <div class="header">
            <div class="logo-area">
                <button class="menu-btn" onclick="window.location.href='SettingServlet'"><i class="fa-solid fa-bars"></i></button>
                <div class="logo" onclick="window.location.href='HomeServlet'">connect hub</div>
            </div>
            <div class="header-icons">
                <button class="icon-btn" onclick="window.location.href='PostServlet'"><i class="fa-solid fa-plus"></i></button>
                <button class="icon-btn" onclick="window.location.href='SearchServlet'"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
        </div>

        <div class="nav-tabs">
            <div class="nav-tab active" onclick="window.location.href='HomeServlet'"><i class="fa-solid fa-house"></i></div>
            <div class="nav-tab" onclick="window.location.href='ViewProfileServlet?user_id=<%= session.getAttribute("user_id") %>'"><i class="fa-solid fa-circle-user"></i></div>
            <!-- Friends Tab (Friend Request အတွက် အနီစက်) -->
            <div class="nav-tab" onclick="window.location.href='FriendServlet'" style="position: relative;">
                <i class="fa-solid fa-user-group"></i>
                <% 
                    Boolean hasPending = (Boolean) request.getAttribute("hasPendingRequests");
                    if(hasPending != null && hasPending) { 
                %>
                    <span class="red-dot"></span>
                <% } %>
            </div>

            
             <!-- Notification Tab (Bell Icon အတွက် အနီစက်) -->
            <div class="nav-tab" onclick="window.location.href='NotificationServlet'" style="position: relative;">
                <i class="fa-solid fa-bell"></i>
                <% 
                    // အပေါ်ဆုံးမှာ ကြေညာပြီးသား unreadCount ကိုသာ တိုက်ရိုက်စစ်ဆေးပါ
                    if(unreadCount > 0) { 
                %>
                    <span class="red-dot"></span>
                <% } %>
            </div>
            

            <!-- Messenger Tab (Message အတွက် အနီစက်) -->
            <div class="nav-tab" onclick="window.location.href='MessageServlet'" style="position: relative;">
                <i class="fa-solid fa-comment-dots"></i>
                <% 
                    Boolean hasMsgs = (Boolean) request.getAttribute("hasUnreadMessages");
                    if(hasMsgs != null && hasMsgs) { 
                %>
                    <span class="red-dot"></span>
                <% } %>
            </div>
        </div>

        <div class="create-post-box">
            <img src="ImageServlet?user_id=<%= userId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="avatar" alt="Profile" onclick="window.location.href='ViewProfileServlet'"> 
            <div class="post-input-fake" onclick="window.location.href='PostServlet'">create new feed <%= userName %>...</div>
            <i class="fa-solid fa-images post-img-icon" onclick="window.location.href='post.jsp'"></i>
        </div>

        <div class="feed-container">
        <%
            if(feedPostsList != null && !feedPostsList.isEmpty()) {
                for(Map<String, Object> post : feedPostsList) {
                    int postId = (Integer) post.get("postId");
                    int postUserId = (Integer) post.get("userId");
                    String authorName = (String) post.get("username");
                    String postTitle = (String) post.get("postTitle");
                    String postText = (String) post.get("text");
                    String bgStyle = (String) post.get("bgStyle");
                    String createdAt = (String) post.get("createdAt");
                    int likeCount = (Integer) post.get("likeCount");
                    int commentCount = (Integer) post.get("commentCount");
                    boolean isLikedByMe = post.containsKey("isLikedByMe") && (Boolean) post.get("isLikedByMe");
                    List<String> images = (List<String>) post.get("images");
                    List<Map<String, Object>> commList = (List<Map<String, Object>>) post.get("commentsList");

                    String cardBg = (bgStyle != null && !bgStyle.trim().isEmpty()) ? bgStyle : "#ffffff";
                    String bgStyleAttr = cardBg.startsWith("linear-gradient") ? "background-image: " + cardBg + ";" : "background: " + cardBg + ";";
        %>
                    <div class="post-card" style="<%= bgStyleAttr %>" id="post-<%= postId %>">
                        <div class="post-header-top">
                            <div class="post-user-info">
                                <img src="ImageServlet?user_id=<%= postUserId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="post-user-avatar" alt="Avatar" onclick="window.location.href='ProfileServlet?user_id=<%= postUserId %>'">
                                <div class="post-username-time">
                                    <a href="ProfileServlet?user_id=<%= postUserId %>" class="post-author-name"><%= authorName %></a>
                                    <span class="post-time"><%= createdAt != null ? createdAt : "" %></span>
                                </div>
                            </div>
                            
                            <% if(postUserId == userId) { %>
                            <div style="position: relative;">
                                <button type="button" class="post-options-btn" onclick="togglePostMenu(<%= postId %>, event)">
                                    <i class="fa-solid fa-ellipsis"></i>
                                </button>
                                <div id="postMenu_<%= postId %>" class="post-dropdown-menu">
                                    <a href="EditPostServlet?post_id=<%= postId %>&from=home"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                                    <a href="DeletePostServlet?post_id=<%= postId %>" class="delete-option" onclick="return confirm('Are you sure to Delete?');"><i class="fa-solid fa-trash"></i> Delete</a>
                                </div>
                            </div>
                            <% } %>
                        </div>

                        <% if(postTitle != null && !postTitle.trim().isEmpty()) { %>
                            <div class="post-title"><%= postTitle %></div>
                        <% } %>

                        <% if(postText != null && !postText.trim().isEmpty()) { %>
                            <div class="post-text"><%= postText %></div>
                        <% } %>

                        <% if(images != null && !images.isEmpty()) { %>
                            <div class="post-images-grid">
                                <% for(String imgName : images) { %>
                                    <img src="uploads/<%= imgName %>" alt="Post Image">
                                <% } %>
                            </div>
                        <% } %>

                        <div class="post-stats-bar">
                            <div class="stat-item" onclick="openLikesModal(<%= postId %>)">
                                <i class="fa-solid fa-heart" style="color: #fa383e;"></i> <span class="like-count-text"><%= likeCount %></span> likes
                            </div>
                            <div class="stat-item" onclick="toggleComments(this)">
                                <span class="comment-count-text"><%= commentCount %></span> comments
                            </div>
                        </div>

                        <div class="post-actions-row">
                            <button class="action-action-btn like-btn <%= isLikedByMe ? "liked" : "" %>" onclick="handleLike(<%= postId %>, this)">
                                <i class="<%= isLikedByMe ? "fa-solid" : "fa-regular" %> fa-heart heart-icon" style="<%= isLikedByMe ? "color: #fa383e;" : "" %>"></i> Like
                            </button>
                            <button class="action-action-btn" onclick="toggleComments(this)">
                                <i class="fa-regular fa-comment"></i> Comment
                            </button>
                        </div>

                        <div class="comment-section" style="display: none;">
                            <div class="comment-list">
                                <%
                                    if(commList != null && !commList.isEmpty()) {
                                        // ၁။ Parent Comments များကို အရင်ထုတ်မည် (parentId မရှိသော သို့မဟုတ် 0 ဖြစ်သော)
                                        for(Map<String, Object> comm : commList) {
                                            Integer parentIdObj = (Integer) comm.get("parentId");
                                            if(parentIdObj == null || parentIdObj == 0) {
                                                int cId = comm.get("commentId") != null ? (Integer) comm.get("commentId") : 0;
                                                int cUserId = comm.get("userId") != null ? (Integer) comm.get("userId") : 0;
                                                String cUser = (String) comm.get("username");
                                                String cText = (String) comm.get("commentText");
                                                String displayName = (cUserId == userId) ? "You" : cUser;
                                %>
                                <!-- Parent Comment Item -->
                                <div class="comment-item" id="commentItem_<%= cId %>">
                                    <div class="comment-top-row">
                                        <div class="comment-text-content">
                                            <span class="comment-user"><span id="cUser_<%= cId %>"><%= displayName %></span>:</span> 
                                            <span id="commentText_<%= cId %>" data-comment-text="<%= cText %>"><%= cText %></span>
                                        </div>
                                        
                                        <% if(cUserId == userId) { %>
                                            <div class="comment-menu-wrapper">
                                                <button type="button" class="comment-dots-btn" onclick="toggleCommentMenu(<%= cId %>, event)">
                                                    <i class="fa-solid fa-ellipsis"></i>
                                                </button>
                                                <div class="comment-dropdown-menu" id="commentMenu_<%= cId %>">
                                                    <button type="button" onclick="enableEdit(<%= cId %>, '<%= cUser.replace("'", "\\'") %>')">Edit</button>
                                                    <button type="button" onclick="deleteComment(<%= cId %>)" style="color: #fa383e;">Delete</button>
                                                </div>
                                            </div>
                                        <% } %>
                                    </div>

                                   <%
    String cTime = (String) comm.get("createdAt");
    if(cTime == null || cTime.trim().isEmpty()) cTime = "Just now";
%>
<div class="comment-footer-row">
    <span class="comment-time"><%= cTime %></span>
    <button type="button" class="comment-reply-btn" onclick="openReplyBox(<%= postId %>, <%= cId %>, '<%= cUser.replace("'", "\\'") %>')">Reply</button>
</div>
                                </div>

                                <!-- ၂။ ဤ Parent Comment ၏ အောက်တွင် ရှိသော Reply များကို ဆွဲထုတ်ရန် -->
                                <%
                                                for(Map<String, Object> reply : commList) {
                                                    Integer rParentId = (Integer) reply.get("parentId");
                                                    if(rParentId != null && rParentId == cId) {
                                                        int rId = reply.get("commentId") != null ? (Integer) reply.get("commentId") : 0;
                                                        int rUserId = reply.get("userId") != null ? (Integer) reply.get("userId") : 0;
                                                        String rUser = (String) reply.get("username");
                                                        String rText = (String) reply.get("commentText");
                                                        String rDisplayName = (rUserId == userId) ? "You" : rUser;
                                %>
                                <!-- Reply Comment Item (Indented) -->
                                <div class="comment-item is-reply" id="commentItem_<%= rId %>">
                                    <div class="comment-top-row">
                                        <div class="comment-text-content">
                                            <span class="comment-user"><span id="cUser_<%= rId %>"><%= rDisplayName %></span>:</span> 
                                            <span id="commentText_<%= rId %>" data-comment-text="<%= rText %>"><%= rText %></span>
                                        </div>
                                        
                                        <% if(rUserId == userId) { %>
                                            <div class="comment-menu-wrapper">
                                                <button type="button" class="comment-dots-btn" onclick="toggleCommentMenu(<%= rId %>, event)">
                                                    <i class="fa-solid fa-ellipsis"></i>
                                                </button>
                                                <div class="comment-dropdown-menu" id="commentMenu_<%= rId %>">
                                                    <button type="button" onclick="enableEdit(<%= rId %>, '<%= rUser.replace("'", "\\'") %>')">Edit</button>
                                                    <button type="button" onclick="deleteComment(<%= rId %>)" style="color: #fa383e;">Delete</button>
                                                </div>
                                            </div>
                                        <% } %>
                                    </div>

                                  <%
    String rTime = (String) reply.get("createdAt");
    if(rTime == null || rTime.trim().isEmpty()) rTime = "Just now";
%>
<div class="comment-footer-row">
    <span class="comment-time"><%= rTime %></span>
</div>
                                </div>
                                <%
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                %>
                                    <div style="color: #8a8d91; text-align: center; font-size: 11px; font-style: italic;" class="no-comments">No comments yet.</div>
                                <% } %>
                            </div>

                            <form onsubmit="submitComment(event, <%= postId %>)" class="comment-input-box">
                                <input type="hidden" name="postId" value="<%= postId %>">
                                <input type="text" name="commentText" class="comment-input" placeholder="Add comment" required>
                                <button type="submit" class="comment-send-btn">Send</button>
                            </form>
                        </div>
                    </div>
        <%
                }
            } else {
        %>
            <div style="text-align: center; color: #8a8d91; font-style: italic; font-size: 13px; padding: 40px 0;">No posts yet!</div>
        <%
            }
        %>
        </div>
    </div>

    <!-- Likes Modal -->
    <div id="likesModal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e4e6eb; padding-bottom: 8px; margin-bottom: 10px;">
                <h3 style="font-size: 15px; color: #050505;">liked person</h3>
                <button onclick="closeLikesModal()" style="background: none; border: none; font-size: 16px; cursor: pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div id="likesUserListContainer" style="display: flex; flex-direction: column; gap: 6px;"></div>
        </div>
    </div>

    <div id="toast"></div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<%
    String successMsg = (String) session.getAttribute("successMessage");
    if (successMsg != null) {
        session.removeAttribute("successMessage");
%>
    <script>
        window.onload = function() {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<%= successMsg %>',
                timer: 2000,
                showConfirmButton: false,
                width: '300px',
                padding: '1em'
            });
        };
    </script>
<%
    }
%>
    <script>
        window.onclick = function(event) {
            if (!event.target.matches('.fa-ellipsis') && !event.target.matches('.post-options-btn')) {
                var menus = document.getElementsByClassName('post-dropdown-menu');
                for (var i = 0; i < menus.length; i++) {
                    menus[i].style.display = 'none';
                }
            }
            const likesModal = document.getElementById('likesModal');
            if (event.target === likesModal) {
                closeLikesModal();
            }
        }

        function togglePostMenu(postId, event) {
            event.stopPropagation();
            var menus = document.getElementsByClassName('post-dropdown-menu');
            for (var i = 0; i < menus.length; i++) {
                if (menus[i].id !== 'postMenu_' + postId) {
                    menus[i].style.display = 'none';
                }
            }
            var currentMenu = document.getElementById('postMenu_' + postId);
            currentMenu.style.display = currentMenu.style.display === 'block' ? 'none' : 'block';
        }

        function handleLike(postId, btn) {
            fetch('InteractServlet?action=like&postId=' + postId)
            .then(response => {
                if (response.ok) {
                    const icon = btn.querySelector('.heart-icon');
                    const postCard = document.getElementById('post-' + postId);
                    const countSpan = postCard.querySelector('.like-count-text');
                    let currentCount = parseInt(countSpan.textContent) || 0;

                    if (icon.classList.contains('fa-regular')) {
                        icon.classList.remove('fa-regular');
                        icon.classList.add('fa-solid');
                        icon.style.color = '#fa383e';
                        btn.classList.add('liked');
                        countSpan.textContent = currentCount + 1;
                    } else {
                        icon.classList.remove('fa-solid');
                        icon.classList.add('fa-regular');
                        icon.style.color = '';
                        btn.classList.remove('liked');
                        countSpan.textContent = Math.max(0, currentCount - 1);
                    }
                }
            })
            .catch(err => console.error("Error liking post:", err));
        }

        function submitComment(event, postId) {
            event.preventDefault();
            const form = event.target;
            
            const cTextInput = form.querySelector('input[name="commentText"]');
            const cText = cTextInput ? cTextInput.value : "";
            if (!cText.trim()) return;

            const formData = new FormData(form);
            formData.append('action', 'comment');

            // Database သို့ တိုက်ရိုက် ပို့မည်
            fetch('InteractServlet', {
                method: 'POST',
                body: new URLSearchParams(formData)
            })
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                if (data.status === "success" || data.commentId) {
                    // Page Reload မလုပ်ခင် သက်ဆိုင်ရာ Post ရဲ့ Comment Section ကို အလိုအလျောက် ဖွင့်ထားရန် URL hash တွင် မှတ်သားမည်
                    window.location.href = window.location.pathname + '#post-' + postId;
                    location.reload();
                }
            })
            .catch(err => {
                console.error("Error submitting comment:", err);
                // Error တက်ရင်တောင် reload လုပ်ပေးခြင်းဖြင့် comment ပေါ်လာစေရန်
                window.location.href = window.location.pathname + '#post-' + postId;
                location.reload();
            });
        }

        function toggleCommentMenu(commentId, event) {
            event.stopPropagation();
            document.querySelectorAll('.comment-dropdown-menu').forEach(menu => {
                if (menu.id !== 'commentMenu_' + commentId) {
                    menu.classList.remove('show');
                }
            });
            let menu = document.getElementById('commentMenu_' + commentId);
            if(menu) {
                menu.classList.toggle('show');
            }
        }

        window.addEventListener('click', function(event) {
            if (!event.target.matches('.comment-dots-btn') && !event.target.closest('.comment-dots-btn')) {
                document.querySelectorAll('.comment-dropdown-menu').forEach(menu => {
                    menu.classList.remove('show');
                });
            }
        });

        function openReplyBox(postId, commentId, userName) {
            const existingReplyBox = document.getElementById('activeReplyBox_' + commentId);
            if (existingReplyBox) {
                existingReplyBox.remove();
                return;
            }

            const commentItem = document.getElementById('commentItem_' + commentId);
            
            const replyBoxHtml = document.createElement('form');
            replyBoxHtml.id = 'activeReplyBox_' + commentId;
            replyBoxHtml.className = 'reply-input-box';
            replyBoxHtml.onsubmit = function(event) {
                submitReply(event, postId, commentId);
            };

            replyBoxHtml.innerHTML = 
                '<input type="text" name="commentText" class="reply-input" placeholder="Send reply to ' + userName + '" required autofocus>' +
                '<button type="submit" class="reply-send-btn">Send</button>';

            commentItem.appendChild(replyBoxHtml);
        }

        function submitReply(event, postId, parentCommentId) {
            event.preventDefault();
            const form = event.target;
            const commentInput = form.querySelector('input[name="commentText"]');
            const commentText = commentInput ? commentInput.value : "";

            if (!commentText.trim()) return;

            const params = new URLSearchParams();
            params.append('action', 'comment');
            params.append('postId', postId);
            params.append('commentText', commentText);
            params.append('parentId', parentCommentId);

            fetch('InteractServlet', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: params.toString()
            })
            .then(response => {
                if(!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                form.remove(); // Reply Box ကို ဖယ်ရှားမည်
                showToast('Reply success');

                if (data.status === "success" || data.commentId) {
                    const parentCommentItem = document.getElementById('commentItem_' + parentCommentId);
                    if (parentCommentItem) {
                        const newReplyId = data.commentId || Date.now();
                        const newReplyHTML = `
                            <div class="comment-item is-reply" id="commentItem_${newReplyId}">
                                <div class="comment-top-row">
                                    <div class="comment-text-content">
                                        <span class="comment-user"><span id="cUser_${newReplyId}">You</span>:</span> 
                                        <span id="commentText_${newReplyId}" data-comment-text="${commentText}">${commentText}</span>
                                    </div>
                                    <div class="comment-menu-wrapper">
                                        <button type="button" class="comment-dots-btn" onclick="toggleCommentMenu(${newReplyId}, event)">
                                            <i class="fa-solid fa-ellipsis"></i>
                                        </button>
                                        <div class="comment-dropdown-menu" id="commentMenu_${newReplyId}">
                                            <button type="button" onclick="enableEdit(${newReplyId}, 'You')">Edit</button>
                                            <button type="button" onclick="deleteComment(${newReplyId})" style="color: #fa383e;">Delete</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="comment-footer-row">
                                    <span class="comment-time">Just now</span>
                                </div>
                            </div>
                        `;
                        // Parent Comment ရဲ့ အောက်နားမှာ Reply အသစ်ကို ထည့်သွင်းခြင်း
                        parentCommentItem.insertAdjacentHTML('afterend', newReplyHTML);
                    }
                }
            })
            .catch(err => {
                console.error("Error submitting reply:", err);
                showToast('Something went wrong!');
            });
        }
        function enableEdit(commentId, userName) {
            const textSpan = document.getElementById("commentText_" + commentId);
            if (!textSpan) return;
            const originalText = textSpan.getAttribute("data-comment-text") || textSpan.innerText;
            const commentItem = document.getElementById("commentItem_" + commentId);
            
            commentItem.innerHTML = 
                '<div style="display: flex; gap: 6px; align-items: center; width: 100%; padding: 4px 0;">' +
                    '<input type="text" id="editText_' + commentId + '" value="' + originalText + '" style="flex: 1; padding: 6px 10px; font-size: 13px; border: 1px solid #ccd0d5; border-radius: 4px; outline: none;" />' +
                    '<button type="button" onclick="saveEdit(' + commentId + ', \'' + userName.replace(/'/g, "\\'") + '\')" style="font-size: 12px; background: #2e7d32; color: #fff; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-weight: 600;">Save</button>' +
                    '<button type="button" onclick="cancelEdit(' + commentId + ', \'' + originalText.replace(/'/g, "\\'") + '\', \'' + userName.replace(/'/g, "\\'") + '\')" style="font-size: 12px; background: #e4e6eb; color: #050505; border: none; padding: 6px 10px; border-radius: 4px; cursor: pointer;">Cancel</button>' +
                '</div>';
            
            const inputField = document.getElementById("editText_" + commentId);
            if(inputField) {
                inputField.focus();
                inputField.setSelectionRange(inputField.value.length, inputField.value.length);
            }
        }

        function cancelEdit(commentId, originalText, userName) {
            const commentItem = document.getElementById("commentItem_" + commentId);
            commentItem.innerHTML = 
                '<div class="comment-top-row">' +
                    '<div class="comment-text-content">' +
                        '<span class="comment-user"><span id="cUser_' + commentId + '">You</span>:</span> ' +
                        '<span id="commentText_' + commentId + '" data-comment-text="' + originalText + '">' + originalText + '</span>' +
                    '</div>' +
                    '<div class="comment-menu-wrapper">' +
                        '<button type="button" class="comment-dots-btn" onclick="toggleCommentMenu(' + commentId + ', event)">' +
                            '<i class="fa-solid fa-ellipsis"></i>' +
                        '</button>' +
                        '<div class="comment-dropdown-menu" id="commentMenu_' + commentId + '">' +
                            '<button type="button" onclick="enableEdit(' + commentId + ', \'' + userName.replace(/'/g, "\\'") + '\')">Edit</button>' +
                            '<button type="button" onclick="deleteComment(' + commentId + ')" style="color: #fa383e;">Delete</button>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="comment-footer-row">' +
                    '<span class="comment-time">Just now</span>' +
                    '<button type="button" class="comment-reply-btn" onclick="openReplyBox(0, ' + commentId + ', \'' + userName.replace(/'/g, "\\'") + '\')">Reply</button>' +
                '</div>';
        }

        function saveEdit(commentId, userName) {
            const inputElement = document.getElementById("editText_" + commentId);
            if (!inputElement) return;
            const newText = inputElement.value;
            if(!newText.trim()) return;

            fetch('InteractServlet', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=editComment&commentId=' + commentId + '&newText=' + encodeURIComponent(newText)
            })
            .then(response => {
                if(response.ok) {
                    cancelEdit(commentId, newText, userName);
                }
            })
            .catch(err => console.error("Error editing comment:", err));
        }

        let currentCommentIdToDelete = null;

        function deleteComment(commentId) {
            currentCommentIdToDelete = commentId;
            const alertModal = document.getElementById('customAlert');
            if (alertModal) {
                alertModal.style.display = 'flex';
            }
        }

        function closeCustomAlert() {
            const alertModal = document.getElementById('customAlert');
            if (alertModal) {
                alertModal.style.display = 'none';
            }
            currentCommentIdToDelete = null;
        }
        function openLikesModal(postId) {
            fetch('GetLikesServlet?postId=' + postId)
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById('likesUserListContainer');
                container.innerHTML = '';
                if(data.length === 0) {
                    container.innerHTML = '<div style="color: #8a8d91; text-align: center; font-size: 12px;">No likes yet</div>';
                } else {
                    data.forEach(username => {
                        container.innerHTML += '<div style="font-weight: 600; font-size: 13px; color: #050505; padding: 6px 8px; background: #f0f2f5; border-radius: 4px;"><i class="fa-solid fa-user" style="margin-right: 6px; color: #2e7d32;"></i>' + username + '</div>';
                    });
                }
                document.getElementById('likesModal').style.display = 'flex';
            })
            .catch(err => console.error("Error fetching likes:", err));
        }

        function closeLikesModal() {
            document.getElementById('likesModal').style.display = 'none';
        }

        function toggleComments(element) {
            const postCard = element.closest('.post-card');
            const commentSection = postCard.querySelector('.comment-section');
            commentSection.style.display = commentSection.style.display === 'flex' ? 'none' : 'flex';
            if (commentSection.style.display === 'flex') {
                commentSection.querySelector('.comment-input').focus();
            }
        }

        function showToast(message) {
            const toast = document.getElementById('toast');
            toast.innerText = message;
            toast.classList.add('show');
            setTimeout(() => { toast.classList.remove('show'); }, 2000);
        }

        function confirmDeleteAction() {
            if (currentCommentIdToDelete !== null) {
                const commentId = currentCommentIdToDelete;
                closeCustomAlert();
                
                fetch('InteractServlet', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=deleteComment&commentId=' + commentId
                })
                .then(response => {
                    if(response.ok) {
                        const commentItem = document.getElementById("commentItem_" + commentId);
                        if(commentItem) {
                            // ဤ comment ပါဝင်သော post-card ကို ရှာမည်
                            const postCard = commentItem.closest('.post-card');
                            if (postCard) {
                                // comment count စာသားကို ရှာပြီး ၁ လျှော့မည်
                                const commentCountSpan = postCard.querySelector('.comment-count-text');
                                if (commentCountSpan) {
                                    let currentCount = parseInt(commentCountSpan.textContent) || 0;
                                    commentCountSpan.textContent = Math.max(0, currentCount - 1);
                                }
                            }
                            // Comment item ကို HTML ထဲမှ ဖယ်ရှားမည်
                            commentItem.remove();
                            showToast('Comment deleted successfully');
                        }
                    }
                })
                .catch(err => {
                    console.error("Error deleting comment:", err);
                    showToast('Something went wrong!');
                });
            }
        }

        document.addEventListener("DOMContentLoaded", function() {
            // 🌟 URL ထဲတွင် Hash ပါလာခြင်း ရှိမရှိ စစ်ဆေးခြင်း (ဥပမာ: #post-5)
            if (window.location.hash) {
                const targetHash = window.location.hash; 
                
                // Feed တွေ အားလုံး పూర్తిగా Load ဖြစ်ရန် အနည်းငယ်စောင့်ရန်
                setTimeout(() => {
                    const targetPost = document.querySelector(targetHash);
                    if (targetPost) {
                        // သက်ဆိုင်ရာ ပို့စ်ဆီသို့ ချောမွေ့စွာ ရွှေ့ပေးခြင်း
                        targetPost.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        
                        // Comment Section ကို အလိုအလျောက် ဖွင့်ပေးခြင်း
                        const commentSection = targetPost.querySelector('.comment-section');
                        if (commentSection) {
                            commentSection.style.display = 'flex';
                        }
                        
                        // ပို့စ်ရောက်လာကြောင်း သိသာစေရန် အရောင်ခဏပြောင်းပြခြင်း (Highlight)
                        targetPost.style.transition = "box-shadow 0.5s ease-in-out";
                        targetPost.style.boxShadow = "0 0 0 3px #2e7d32";
                        setTimeout(() => {
                            targetPost.style.boxShadow = "0 1px 3px rgba(0,0,0,0.1)";
                        }, 2000);
                    }
                }, 400);
            }
        });
        
    </script>

    <!-- Custom Alert Modal -->
    <div id="customAlert" class="custom-alert-overlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); justify-content:center; align-items:center; z-index:2000; backdrop-filter:blur(3px); padding:15px;">
        <div class="custom-alert-box" style="background:#ffffff; width:100%; max-width:360px; border-radius:16px; padding:24px; text-align:center; display:flex; flex-direction:column; gap:14px; box-shadow:0 12px 28px rgba(0,0,0,0.15);">
            <i class="fa-solid fa-triangle-exclamation" style="font-size:38px; color:#e41e3f; margin-bottom:-4px;"></i>
            <div style="font-size:17px; font-weight:700; color:#050505;">Are you sure to delete.</div>
            <div style="font-size:13px; color:#65676b; line-height:1.5;">This action cannot be undone.</div>
            <div style="display:flex; gap:10px; margin-top:6px;">
                <button type="button" onclick="closeCustomAlert()" style="background:#e4e6eb; color:#4b4f56; border:none; padding:10px; border-radius:8px; font-weight:600; width:100%; cursor:pointer;">Cancel</button>
                <button type="button" id="confirmDeleteBtn" style="background:#e41e3f; color:white; border:none; padding:10px; border-radius:8px; font-weight:600; width:100%; cursor:pointer;">Delete</button>
            </div>
        </div>
    </div>
</body>
</html> 