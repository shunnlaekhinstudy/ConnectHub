<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%
    request.setCharacterEncoding("UTF-8");
    if (session.getAttribute("user_id") == null) {
        response.sendRedirect("index.jsp");
        return;
    } String savedBg = (String) session.getAttribute("appBgColor");
    if(savedBg == null) savedBg = "#ffffff";


    List<Map<String, Object>> chatList = (List<Map<String, Object>>) request.getAttribute("chatList");
    if (chatList == null) {
        response.sendRedirect("MessageServlet");
        return;
    }
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messenger - Connect Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
         :root { --app-bg: <%= savedBg %>; }

        .phone-container { 
            width: 100%; max-width: 480px; background: var(--app-bg) !important; background-attachment: fixed;
            min-height: 100vh; box-shadow: 0 0 15px rgba(0,0,0,0.1); position: relative; display: flex; flex-direction: column; padding-bottom: 30px;
        }
        .messenger-header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; background: var(--app-bg) !important; border-bottom: 1px solid #e4e6eb; }
        .header-left { display: flex; align-items: center; gap: 12px; }
        .back-icon-btn { font-size: 20px; color: #2e7d32; cursor: pointer; text-decoration: none; display: flex; align-items: center; justify-content: center; width: 35px; height: 35px; border-radius: 50%; transition: background 0.2s; }
        .back-icon-btn:hover { background-color: #f0f2f5; }
        .messenger-title { font-size: 24px; font-weight: 800; letter-spacing: -0.5px; color: #2e7d32; }
        
        .search-container { padding: 10px 15px; }
        .search-box { background-color: #f0f2f5; border-radius: 20px; padding: 10px 15px; display: flex; align-items: center; gap: 10px; color: #65676b; font-size: 15px; }
        .search-box input { background: none; border: none; color: #050505; outline: none; font-size: 15px; width: 100%; }
        
        .chat-list { flex: 1; overflow-y: auto; padding-bottom: 20px; }
        
        .chat-item { display: flex; align-items: center; gap: 12px; padding: 12px 15px; cursor: pointer; transition: background 0.2s; text-decoration: none; color: inherit; background: var(--app-bg) !important; border-bottom: 1px solid #f8f9fa; }
        .chat-item:hover { background-color: #f2f2f2; }
        
        .chat-item.unread { background-color: #e8f5e9; }
        .chat-item.unread:hover { background-color: #d0ebd4; }
        .chat-item.unread .chat-name { font-weight: 700; color: #1b5e20; }
        .chat-item.unread .chat-msg { font-weight: 700; color: #2e7d32; }
        
        .chat-avatar-wrapper { position: relative; width: 55px; height: 55px; flex-shrink: 0; }
        .chat-avatar { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; background-color: #e4e6eb; }
        
        .unread-dot {
            position: absolute;
            top: 2px; right: 2px;
            width: 14px; height: 14px;
            background-color: #2e7d32;
            border: 2px solid #ffffff;
            border-radius: 50%;
        }

        .chat-info { display: flex; flex-direction: column; gap: 3px; flex: 1; min-width: 0; }
        .chat-name { font-size: 16px; font-weight: 600; color: #050505; }
        .chat-msg { font-size: 14px; color: #65676b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    </style>
</head>
<body>
    <div class="phone-container">
        <!-- Messenger Header -->
        <div class="messenger-header">
            <div class="header-left">
                <div class="back-icon-btn" onclick="location.href='HomeServlet'" title="back">
    <i class="fa-solid fa-arrow-left"></i>
</div>
                <div class="messenger-title">Chats</div>
            </div>
        </div>

        

        <!-- Chat List -->
        <div class="chat-list">
            <% 
                if (chatList.isEmpty()) {
            %>
                <div style="text-align: center; color: #65676b; padding: 40px;">No friend yet</div>
            <% 
                } else {
                    for(Map<String, Object> chat : chatList) {
                        int fId = (int) chat.get("friendId");
                        String fName = (String) chat.get("friendName");
                        String fAvatar = (String) chat.get("friendAvatar");
                        String lastMsg = (String) chat.get("lastMessage");
                        boolean isUnread = (boolean) chat.get("isUnread");
            %>
            <a href="MessageServlet?receiver_id=<%= fId %>" class="chat-item <%= isUnread ? "unread" : "" %>">
                <div class="chat-avatar-wrapper">
                    <!-- fId ကို သုံး၍ ပရိုไฟล์ပုံခေါ်မည်၊ မရှိပါက default-avatar.png ပေါ်မည် -->
                    <img src="<%= fAvatar %>" onerror="this.src='images/default-avatar.png'" class="chat-avatar" alt="Avatar">
                    <% if (isUnread) { %>
                        <div class="unread-dot"></div>
                    <% } %>
                </div>
                <div class="chat-info">
                    <div class="chat-name"><%= fName %></div>
                    <div class="chat-msg"><%= lastMsg %></div>
                </div>
            </a>
            <% 
                    }
                } 
            %>
        </div>
    </div>
</body>
</html>