<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<%
    String userName = (String) session.getAttribute("userName");
    Integer userId = (Integer) session.getAttribute("user_id");
    if(userName == null || userId == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    String savedBg = (String) session.getAttribute("appBgColor");
    if(savedBg == null) savedBg = "#ffffff";

    // Request attributes များရယူခြင်း
    String bio = (String) request.getAttribute("bio");
    String gender = (String) request.getAttribute("gender");
    Object birthdateObj = request.getAttribute("birthdate");
    String birthdate = birthdateObj != null ? birthdateObj.toString() : "";
    String occupation = (String) request.getAttribute("occupation");
    String address = (String) request.getAttribute("address");
    
    List<Map<String, Object>> postsList = (List<Map<String, Object>>) request.getAttribute("postsList");

    // ကိုယ့် Profile ဟုတ်မဟုတ် နှင့် သူငယ်ချင်းအခြေအနေ စစ်ဆေးရန်
    Boolean isOwnProfileObj = (Boolean) request.getAttribute("isOwnProfile");
    boolean isOwnProfile = (isOwnProfileObj != null) ? isOwnProfileObj : true;
    
    Integer targetUserIdObj = (Integer) request.getAttribute("targetUserId");
    int targetUserId = (targetUserIdObj != null) ? targetUserIdObj : userId;
    
    String targetUserName = (String) request.getAttribute("targetUserName");
    if(targetUserName == null || targetUserName.isEmpty()) targetUserName = userName;

    String friendshipStatus = (String) request.getAttribute("friendshipStatus");
    if(friendshipStatus == null) friendshipStatus = "none";

    Boolean isFriendObj = (Boolean) request.getAttribute("isFriend");
    boolean isFriend = (isFriendObj != null) ? isFriendObj : ("friends".equalsIgnoreCase(friendshipStatus) || "accepted".equalsIgnoreCase(friendshipStatus));
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connect Hub - Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        
        :root { --app-bg: <%= savedBg %>; }

        .phone-container { 
            width: 100%; max-width: 480px; background: var(--app-bg) !important; background-attachment: fixed;
            min-height: 100vh; box-shadow: 0 0 15px rgba(0,0,0,0.1); position: relative; display: flex; flex-direction: column; padding-bottom: 30px;
        }

        .cover-photo { width: 100%; height: 160px; object-fit: cover; }
        .profile-section { display: flex; flex-direction: column; align-items: center; margin-top: -50px; padding: 0 15px; }
        .profile-avatar { width: 100px; height: 100px; border-radius: 50%; border: 4px solid #fff; object-fit: cover; background: #fff; }
        .profile-name { font-size: 20px; font-weight: 700; margin-top: 8px; color: #050505; }
        .profile-bio { font-size: 13px; color: #65676b; margin-top: 2px; text-align: center; }
        .avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; cursor: pointer; }
       
        .edit-profile-btn {
            display: flex; align-items: center; justify-content: center; gap: 6px;
            width: 100%; max-width: 450px; background-color: #f0f2f5; border: 1px solid #ccd0d5;
            padding: 8px; border-radius: 6px; font-weight: 600; font-size: 14px; color: #050505;
            text-decoration: none; margin: 12px 0; cursor: pointer;
        }
        .edit-profile-btn:hover { background-color: #e4e6eb; }

        .profile-action-buttons { display: flex; gap: 8px; width: 100%; max-width: 450px; margin: 12px 0; }
        .profile-action-btn {
            flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px;
            padding: 8px; border-radius: 6px; font-weight: 600; font-size: 14px; text-decoration: none; cursor: pointer; border: none;
            text-align: center; white-space: nowrap;
        }
        .btn-light-custom { background-color: #e4e6eb; color: #050505; }
        .btn-light-custom:hover { background-color: #d8dadf; }
        .btn-primary-custom { background-color: #2e7d32; color: #ffffff; }
        .btn-primary-custom:hover { background-color: #1b5e20; }

        .info-card {
            display: flex; align-items: center; gap: 12px; background: #ffffff;
            padding: 10px 15px; border-radius: 8px; margin: 6px 15px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .info-icon { width: 32px; height: 32px; border-radius: 50%; background: #e8f5e9; color: #2e7d32; display: flex; align-items: center; justify-content: center; font-size: 14px; }
        .info-content { display: flex; flex-direction: column; }
        .info-label { font-size: 10px; color: #65676b; font-weight: 700; text-transform: uppercase; }
        .info-value { font-size: 13px; color: #050505; font-weight: 500; }

        .my-posts-title { font-size: 16px; font-weight: 700; margin: 15px 15px 5px 15px; color: #050505; }
        
        .feed-container { display: flex; flex-direction: column; gap: 15px; padding: 15px; }
        
        .post-card { padding: 15px; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #e4e6eb; background-color: #ffffff; position: relative; text-align: left; }
        .post-header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        .post-user-info { display: flex; align-items: center; gap: 8px; }
        .post-user-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; }
        .post-username-time { display: flex; flex-direction: column; }
        .post-author-name { font-size: 13px; font-weight: 700; color: #050505; text-decoration: none; }
        .post-time { color: #65676b; font-size: 11px; }

        .post-options-btn { background: none; border: none; font-size: 16px; cursor: pointer; color: #65676b; padding: 4px 8px; }
        .post-dropdown-menu { display: none; position: absolute; right: 0; top: 35px; background: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.15); border-radius: 6px; overflow: hidden; z-index: 10; width: 110px; border: 1px solid #e4e6eb; }
        .post-dropdown-menu.show { display: block; }
        .post-dropdown-menu a { display: block; padding: 8px 12px; font-size: 12px; color: #050505; text-decoration: none; }
        .post-dropdown-menu a:hover { background-color: #f0f2f5; }
        .delete-option { color: #fa383e !important; }
        
        .post-title { font-size: 16px; font-weight: 700; color: #050505; margin-bottom: 4px; }
        .post-text { font-size: 14px; color: #050505; word-break: break-word; margin-bottom: 10px; line-height: 1.4; }
        .post-images-grid { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
        .post-images-grid img { width: 100%; max-height: 280px; object-fit: cover; border-radius: 6px; } 

        .post-stats-bar { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #e4e6eb; font-size: 13px; color: #65676b; margin-top: 10px; }
        .stat-item { cursor: pointer; display: flex; align-items: center; gap: 5px; }
        .stat-item:hover { color: #2e7d32; }

        .post-actions-row { display: flex; justify-content: space-around; padding-top: 6px; margin-top: 4px; }
        .action-action-btn { background: none; border: none; font-size: 13px; font-weight: 600; color: #65676b; cursor: pointer; display: flex; align-items: center; gap: 6px; padding: 6px 15px; border-radius: 4px; }
        .action-action-btn:hover { background-color: #f0f2f5; color: #2e7d32; }
        .action-action-btn.liked .heart-icon { color: #fa383e; }
        
        .reply-input-box { display: flex; gap: 6px; margin-top: 6px; margin-left: 15px; align-items: center; }
        .reply-input { flex: 1; padding: 5px 10px; border: 1px solid #ccd0d5; border-radius: 15px; font-size: 12px; outline: none; background: #ffffff; }
        .reply-send-btn { background: #2e7d32; color: #fff; border: none; padding: 5px 10px; border-radius: 15px; font-size: 11px; font-weight: 600; cursor: pointer; }
        
        .comment-item { background: #f0f2f5; padding: 8px 12px; border-radius: 12px; display: flex; flex-direction: column; gap: 4px; position: relative; width: 100%; box-sizing: border-box; }
        .comment-item.is-reply { margin-left: 20px; width: calc(100% - 20px); background: #e4e6eb; }

        .comment-top-row { display: flex; align-items: flex-start; justify-content: space-between; width: 100%; gap: 8px; }
        .comment-text-content { flex: 1; word-break: break-word; overflow-wrap: break-word; font-size: 13px; color: #050505; min-width: 0; }
        .comment-footer-row { display: flex; align-items: center; gap: 12px; font-size: 11px; color: #65676b; padding-left: 2px; }
        .comment-reply-btn { background: none; border: none; font-size: 11px; font-weight: 600; color: #65676b; cursor: pointer; padding: 0; }
        .comment-reply-btn:hover { text-decoration: underline; color: #2e7d32; }
        
        .comment-menu-wrapper { position: relative; flex-shrink: 0; }
        .comment-dots-btn { background: none; border: none; font-size: 14px; color: #65676b; cursor: pointer; padding: 2px 6px; border-radius: 50%; }
        .comment-dots-btn:hover { background-color: rgba(0,0,0,0.05); }
        
        .comment-dropdown-menu { display: none; position: absolute; right: 0; top: 22px; background: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.15); border-radius: 6px; overflow: hidden; z-index: 10; width: 100px; border: 1px solid #e4e6eb; }
        .comment-dropdown-menu.show { display: block; }
        .comment-dropdown-menu button { display: block; width: 100%; text-align: left; padding: 6px 10px; font-size: 11px; color: #050505; background: none; border: none; cursor: pointer; }
        .comment-dropdown-menu button:hover { background-color: #f0f2f5; }
        
        .comment-section { display: none; flex-direction: column; gap: 10px; margin-top: 10px; padding-top: 10px; border-top: 1px solid #e4e6eb; }
        .comment-list { font-size: 12px; display: flex; flex-direction: column; gap: 6px; max-height: 250px; overflow-y: auto; width: 100%; scrollbar-width: none; }
        .comment-list::-webkit-scrollbar { display: none; }
        .comment-input-box { display: flex; gap: 8px; width: 100%; align-items: center; }
        .comment-input { flex: 1; padding: 8px 12px; border: 1px solid #e4e6eb; border-radius: 20px; font-size: 13px; outline: none; background: #ffffff; }
        .comment-send-btn { background: #2e7d32; color: #fff; border: none; padding: 8px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer; flex-shrink: 0; }
        
        #likesModal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center; }
        .modal-content { background: #fff; width: 85%; max-width: 320px; border-radius: 8px; padding: 15px; max-height: 350px; overflow-y: auto; text-align: left; }
        
        #toast { visibility: hidden; min-width: 220px; background-color: #333; color: #fff; text-align: center; border-radius: 4px; padding: 10px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; }
        #toast.show { visibility: visible; animation: fadein 0.5s, fadeout 0.5s 1.5s; }
        @keyframes fadein { from { bottom: 0; opacity: 0; } to { bottom: 30px; opacity: 1; } }
        @keyframes fadeout { from { bottom: 30px; opacity: 1; } to { bottom: 0; opacity: 0; } }

        /* Custom Popup Modal Design Styles */
        #customAlertModal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); z-index: 2000; justify-content: center; align-items: center; }
        .custom-alert-box { background: #ffffff; width: 85%; max-width: 300px; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.15); animation: scaleUp 0.2s ease-in-out; }
        .custom-alert-icon { font-size: 36px; color: #e65100; margin-bottom: 12px; }
        .custom-alert-title { font-size: 16px; font-weight: 700; color: #050505; margin-bottom: 8px; }
        .custom-alert-text { font-size: 13px; color: #65676b; margin-bottom: 20px; line-height: 1.4; }
        .custom-alert-btn { background-color: #2e7d32; color: #ffffff; border: none; width: 100%; padding: 10px; border-radius: 6px; font-weight: 600; font-size: 14px; cursor: pointer; }
        .custom-alert-btn:hover { background-color: #1b5e20; }
        @keyframes scaleUp { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    </style>
</head>
<body>

    <div class="phone-container">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; background: var(--app-bg) !important; position: sticky; top: 0; z-index: 100;">
            <button class="menu-btn" onclick="goBackToPrevious()" style="background: none; border: none; font-size: 20px; cursor: pointer; color: #2e7d32;"><i class="fa-solid fa-arrow-left"></i></button>

            <script>
                function goBackToPrevious() {
                    const referrer = document.referrer;
                    if (referrer && referrer.includes('SearchServlet')) {
                        window.location.href = 'SearchServlet';
                    } else {
                        window.location.href = 'HomeServlet';
                    }
                }
            </script>
            <div style="font-weight: 800; color: #2e7d32; font-size: 20px;">Profile</div>
            <div style="width: 18px;"></div>
        </div>

        <!-- Cover & Profile Image -->
        <img src="ImageServlet?user_id=<%= targetUserId %>&type=cover" onerror="this.src='images/default-cover.png'" class="cover-photo" alt="Cover"> 
        <div class="profile-section">
            <img src="ImageServlet?user_id=<%= targetUserId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="profile-avatar" alt="Profile">
            <div class="profile-name"><%= targetUserName %></div>
            <div class="profile-bio"><%= (bio != null && !bio.isEmpty()) ? bio : "New Mood" %></div>
            
            <% if(isOwnProfile) { %>
                <a href="ProfileServlet?action=edit" class="edit-profile-btn">
                    <i class="fa-solid fa-pen"></i> Edit Profile
                </a>
            <% } else { %>
                <div class="profile-action-buttons">
                    <% if("friends".equals(friendshipStatus)) { %>
                        <button class="profile-action-btn btn-light-custom"><i class="fa-solid fa-user-check"></i> Friends</button>
                    <% } else if("pending_sent".equals(friendshipStatus)) { %>
                        <!-- 🛠️ Cancel Request ပြုလုပ်နိုင်သော ခလုတ် -->
                        <button class="profile-action-btn btn-light-custom" onclick="cancelProfileRequest(<%= targetUserId %>, this)">
                            <i class="fa-solid fa-clock"></i> Request Sent
                        </button>
                    <% } else if("pending_received".equals(friendshipStatus)) { %>
                        <button class="profile-action-btn btn-primary-custom" onclick="acceptProfileRequest(<%= targetUserId %>, this)">
                            <i class="fa-solid fa-user-plus"></i> Accept Request
                        </button>
                    <% } else { %>
                        <button class="profile-action-btn btn-primary-custom" onclick="sendProfileFriendRequest(<%= targetUserId %>, this)">
                            <i class="fa-solid fa-user-plus"></i> Add Friend
                        </button>
                    <% } %>
                    
                    <!-- Message ခလုတ် -->
                    <% if(isFriend) { %>
                        <a href="ChatServlet?receiver_id=<%= targetUserId %>" class="profile-action-btn btn-light-custom" style="text-decoration: none;">
                            <i class="fa-solid fa-message"></i> Message
                        </a>
                    <% } else { %>
                        <button type="button" class="profile-action-btn btn-light-custom" onclick="showCustomAlert()">
                            <i class="fa-solid fa-message"></i> Message
                        </button>
                    <% } %>
                </div>
            <% } %> 
        </div>

        <!-- User Info Cards -->
        <div class="info-card">
            <div class="info-icon"><i class="fa-solid fa-briefcase"></i></div>
            <div class="info-content">
                <span class="info-label">Occupation</span>
                <span class="info-value"><%= (occupation != null && !occupation.trim().isEmpty()) ? occupation : "No data" %></span>
            </div>
        </div>

        <div class="info-card">
            <div class="info-icon"><i class="fa-solid fa-location-dot"></i></div>
            <div class="info-content">
                <span class="info-label">Lives In</span>
                <span class="info-value"><%= (address != null && !address.trim().isEmpty()) ? address : "No data" %></span>
            </div>
        </div>

        <div class="info-card">
            <div class="info-icon"><i class="fa-solid fa-venus-mars"></i></div>
            <div class="info-content">
                <span class="info-label">Gender</span>
                <span class="info-value"><%= (gender != null && !gender.trim().isEmpty()) ? gender : "No data" %></span>
            </div>
        </div>

        <div class="info-card">
            <div class="info-icon"><i class="fa-solid fa-cake-candles"></i></div>
            <div class="info-content">
                <span class="info-label">Birthdate</span>
                <span class="info-value"><%= (birthdate != null && !birthdate.trim().isEmpty()) ? birthdate : "No data" %></span>
            </div>
        </div>

        <div class="my-posts-title"><%= isOwnProfile ? "My Posts" : targetUserName + "'s Posts" %></div>

        <!-- Feed Container -->
        <div class="feed-container">
        <%
            if(postsList != null && !postsList.isEmpty()) {
                for(Map<String, Object> post : postsList) {
                    Object postIdObj = post.get("postId");
                    
                    Object postUserIdObj = post.get("userId");
                    if (postUserIdObj == null) {
                        postUserIdObj = post.get("user_id");
                    }
                    
                    int postId = (postIdObj != null) ? (Integer) postIdObj : 0;
                    
                    long postUserId = 0;
                    if (postUserIdObj instanceof Integer) {
                        postUserId = ((Integer) postUserIdObj).longValue();
                    } else if (postUserIdObj instanceof Long) {
                        postUserId = (Long) postUserIdObj;
                    } else if (postUserIdObj != null) {
                        try {
                            postUserId = Long.parseLong(postUserIdObj.toString());
                        } catch(Exception e) {
                            postUserId = 0;
                        }
                    }

                    long currentUserId = userId != null ? userId.longValue() : 0;

                    String authorName = (post.get("username") != null) ? (String) post.get("username") : "";
                    String postTitle = (String) post.get("postTitle");
                    String postText = (String) post.get("text");
                    String bgStyle = (String) post.get("bgStyle");
                    String createdAt = (String) post.get("createdAt");
                    
                    Object likeCountObj = post.get("likeCount");
                    Object commentCountObj = post.get("commentCount");
                    int likeCount = (likeCountObj != null) ? (Integer) likeCountObj : 0;
                    int commentCount = (commentCountObj != null) ? (Integer) commentCountObj : 0;
                    
                    boolean isLikedByMe = post.containsKey("isLikedByMe") && post.get("isLikedByMe") != null && (Boolean) post.get("isLikedByMe");
                    List<String> images = (List<String>) post.get("images");
                    List<Map<String, Object>> commList = (List<Map<String, Object>>) post.get("commentsList");

                    String cardBg = (bgStyle != null && !bgStyle.trim().isEmpty()) ? bgStyle : "#ffffff";
                    String bgStyleAttr = cardBg.startsWith("linear-gradient") ? "background-image: " + cardBg + ";" : "background: " + cardBg + ";";
        %>
                    <div class="post-card" style="<%= bgStyleAttr %>" id="post-<%= postId %>">
                        <div class="post-header-top">
                            <div class="post-user-info">
                               <img src="ImageServlet?user_id=<%= targetUserId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="avatar" alt="Profile" onclick="window.location.href='ProfileServlet?user_id=<%= targetUserId %>'"> 
                               <div class="post-username-time">
                                    <a href="ProfileServlet?user_id=<%= postUserId %>" class="post-author-name"><%= authorName %></a>
                                    <span class="post-time"><%= createdAt != null ? createdAt : "" %></span>
                                </div>
                            </div>
                            
                             <% if(postUserId == currentUserId && postUserId != 0) { %>
                            <div style="position: relative;">
                                <button type="button" class="post-options-btn" onclick="togglePostMenu(<%= postId %>, event)">
                                    <i class="fa-solid fa-ellipsis"></i>
                                </button>
                                <div id="postMenu_<%= postId %>" class="post-dropdown-menu">
                                    <a href="EditPostServlet?post_id=<%= postId %>&from=profile"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                                    <a href="DeletePostServlet?post_id=<%= postId %>" class="delete-option" onclick="return confirm('Are you sure to Delete?');"><i class="fa-solid fa-trash"></i> Delete</a>
                                </div>
                            </div>
                            <% } %>
                        </div>

                        <% if(postTitle != null && !postTitle.trim().isEmpty()) { %>
                            <div class="post-title"><%= postTitle %></div>
                        <% } %>

                        <% if(postText != null && !postText.trim().isEmpty()) { %>
                            <div class="post-text"><%= postText %></div>
                        <% } %>

                        <% if(images != null && !images.isEmpty()) { %>
                            <div class="post-images-grid">
                                <% for(String imgName : images) { %>
                                    <img src="uploads/<%= imgName %>" alt="Post Image">
                                <% } %>
                            </div>
                        <% } %>

                        <div class="post-stats-bar">
                            <div class="stat-item" onclick="openLikesModal(<%= postId %>)">
                                <i class="fa-solid fa-heart" style="color: #fa383e;"></i> <span class="like-count-text"><%= likeCount %></span> likes
                            </div>
                            <div class="stat-item" onclick="toggleComments(this)">
                                <span class="comment-count-text"><%= commentCount %></span> comments
                            </div>
                        </div>

                        <div class="post-actions-row">
                            <button class="action-action-btn like-btn <%= isLikedByMe ? "liked" : "" %>" onclick="handleLike(<%= postId %>, this)">
                                <i class="<%= isLikedByMe ? "fa-solid" : "fa-regular" %> fa-heart heart-icon" style="<%= isLikedByMe ? "color: #fa383e;" : "" %>"></i> Like
                            </button>
                            <button class="action-action-btn" onclick="toggleComments(this)">
                                <i class="fa-regular fa-comment"></i> Comment
                            </button>
                        </div>

                        <!-- Comment Section -->
                        <div class="comment-section" style="display: none;">
                            <div class="comment-list">
                                <%
                                    if(commList != null && !commList.isEmpty()) {
                                        for(Map<String, Object> comm : commList) {
                                            Object parentIdObj = comm.get("parentId");
                                            int parentId = (parentIdObj != null) ? (Integer) parentIdObj : 0;

                                            if(parentId == 0) {
                                                Object cIdObj = comm.get("commentId");
                                                int cId = (cIdObj != null) ? (Integer) cIdObj : 0;

                                                Object cUserIdObj = comm.get("userId");
                                                int cUserId = (cUserIdObj != null) ? (Integer) cUserIdObj : 0;

                                                String cUser = (comm.get("username") != null) ? (String) comm.get("username") : "";
                                                String cText = (comm.get("commentText") != null) ? (String) comm.get("commentText") : "";
                                                String displayName = (cUserId == userId) ? "You" : cUser;
                                %>
                                <div class="comment-item" id="commentItem_<%= cId %>">
                                    <div class="comment-top-row">
                                        <div class="comment-text-content">
                                            <span class="comment-user"><span id="cUser_<%= cId %>"><%= displayName %></span>:</span> 
                                            <span id="commentText_<%= cId %>" data-comment-text="<%= cText %>"><%= cText %></span>
                                        </div>
                                        
                                        <% if(cUserId == userId) { %>
                                            <div class="comment-menu-wrapper">
                                                <button type="button" class="comment-dots-btn" onclick="toggleCommentMenu(<%= cId %>, event)">
                                                    <i class="fa-solid fa-ellipsis"></i>
                                                </button>
                                                <div class="comment-dropdown-menu" id="commentMenu_<%= cId %>">
                                                    <button type="button" onclick="enableEdit(<%= cId %>, '<%= cUser.replace("'", "\\'") %>')">Edit</button>
                                                    <button type="button" onclick="deleteComment(<%= cId %>)" style="color: #fa383e;">Delete</button>
                                                </div>
                                            </div>
                                        <% } %>
                                    </div>

                                    <%
                                        String cTime = (String) comm.get("createdAt");
                                        if(cTime == null || cTime.trim().isEmpty()) cTime = "Just now";
                                    %>
                                    <div class="comment-footer-row">
                                        <span class="comment-time"><%= cTime %></span>
                                        <button type="button" class="comment-reply-btn" onclick="openReplyBox(<%= postId %>, <%= cId %>, '<%= cUser.replace("'", "\\'") %>')">Reply</button>
                                    </div>
                                </div>

                                <!-- Reply Comments -->
                                <%
                                                for(Map<String, Object> reply : commList) {
                                                    Object rParentIdObj = reply.get("parentId");
                                                    int rParentId = (rParentIdObj != null) ? (Integer) rParentIdObj : 0;

                                                    if(rParentId == cId) {
                                                        Object rIdObj = reply.get("commentId");
                                                        int rId = (rIdObj != null) ? (Integer) rIdObj : 0;

                                                        Object rUserIdObj = reply.get("userId");
                                                        int rUserId = (rUserIdObj != null) ? (Integer) rUserIdObj : 0;

                                                        String rUser = (reply.get("username") != null) ? (String) reply.get("username") : "";
                                                        String rText = (reply.get("commentText") != null) ? (String) reply.get("commentText") : "";
                                                        String rDisplayName = (rUserId == userId) ? "You" : rUser;
                                %>
                                <div class="comment-item is-reply" id="commentItem_<%= rId %>">
                                    <div class="comment-top-row">
                                        <div class="comment-text-content">
                                            <span class="comment-user"><span id="cUser_<%= rId %>"><%= rDisplayName %></span>:</span> 
                                            <span id="commentText_<%= rId %>" data-comment-text="<%= rText %>"><%= rText %></span>
                                        </div>
                                        
                                        <% if(rUserId == userId) { %>
                                            <div class="comment-menu-wrapper">
                                                <button type="button" class="comment-dots-btn" onclick="toggleCommentMenu(<%= rId %>, event)">
                                                    <i class="fa-solid fa-ellipsis"></i>
                                                </button>
                                                <div class="comment-dropdown-menu" id="commentMenu_<%= rId %>">
                                                    <button type="button" onclick="enableEdit(<%= rId %>, '<%= rUser.replace("'", "\\'") %>')">Edit</button>
                                                    <button type="button" onclick="deleteComment(<%= rId %>)" style="color: #fa383e;">Delete</button>
                                                </div>
                                            </div>
                                        <% } %>
                                    </div>

                                    <%
                                        String rTime = (String) reply.get("createdAt");
                                        if(rTime == null || rTime.trim().isEmpty()) rTime = "Just now";
                                    %>
                                    <div class="comment-footer-row">
                                        <span class="comment-time"><%= rTime %></span>
                                    </div>
                                </div>
                                <%
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                %>
                                    <div style="color: #8a8d91; text-align: center; font-size: 11px; font-style: italic;">No comments yet.</div>
                                <% } %>
                            </div>

                            <form onsubmit="submitComment(event, <%= postId %>)" class="comment-input-box">
                                <input type="hidden" name="postId" value="<%= postId %>">
                                <input type="text" name="commentText" class="comment-input" placeholder="Add comment" required>
                                <button type="submit" class="comment-send-btn">Send</button>
                            </form>
                        </div>
                    </div>
        <%
                }
            } else {
        %>
            <div style="text-align: center; color: #8a8d91; font-style: italic; font-size: 13px; padding: 30px 0;"> No posts yet.</div>
        <% } %>
        </div>
    </div>

    <!-- Likes Modal -->
    <div id="likesModal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e4e6eb; padding-bottom: 8px; margin-bottom: 10px;">
                <h3 style="font-size: 15px; color: #050505;">liked</h3>
                <button onclick="closeLikesModal()" style="background: none; border: none; font-size: 16px; cursor: pointer;"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div id="likesUserListContainer" style="display: flex; flex-direction: column; gap: 6px;"></div>
        </div>
    </div>

    <!-- Custom Alert Modal HTML Structure -->
    <div id="customAlertModal">
        <div class="custom-alert-box">
            <div class="custom-alert-icon"><i class="fa-solid fa-user-lock"></i></div>
            <div class="custom-alert-title">Not Friends Yet</div>
            <div class="custom-alert-text">You must be friends with this user to send a message.</div>
            <button type="button" class="custom-alert-btn" onclick="closeCustomAlert()">OK</button>
        </div>
    </div>

    <div id="toast"></div>

    <script>
        // Accept Request function
        function acceptProfileRequest(senderId, btn) {
            fetch('FriendServlet?action=accept&user_id=' + senderId, { method: 'POST' })
            .then(response => response.text())
            .then(data => {
                showToast('Friend Request Accepted');
                setTimeout(() => { location.reload(); }, 500);
            })
            .catch(err => {
                window.location.href = 'FriendServlet?action=accept&user_id=' + senderId;
            });
        }

        // Add Friend function
      function sendProfileFriendRequest(userId, btn) {
    // user_id ရော receiverId ရော နှစ်ခုစလုံး ပို့ပေးခြင်းဖြင့် Servlet တွင် အမှားအယွင်းမရှိ လက်ခံနိုင်မည်
    fetch('FriendServlet?action=send&user_id=' + userId + '&receiverId=' + userId, { method: 'POST' })
    .then(response => response.text())
    .then(data => {
        showToast('Friend Request Sent');
        btn.innerHTML = '<i class="fa-solid fa-clock"></i> Request Sent';
        btn.className = 'profile-action-btn btn-light-custom';
        btn.setAttribute('onclick', 'cancelProfileRequest(' + userId + ', this)');
    })
    .catch(err => {
        console.error('Error sending request:', err);
    });
}
        // 🌟 Cancel / Remove Request function (Request Sent ကို ပြန်နှိပ်ရင် Add Friend ပြန်ဖြစ်ရန်)
        function cancelProfileRequest(userId, btn) {
            fetch('FriendServlet?action=remove&user_id=' + userId, { method: 'POST' })
            .then(response => response.text())
            .then(data => {
                showToast('Request Cancelled');
                btn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Add Friend';
                btn.className = 'profile-action-btn btn-primary-custom';
                btn.setAttribute('onclick', 'sendProfileFriendRequest(' + userId + ', this)');
            })
            .catch(err => {
                console.error('Error cancelling request:', err);
                location.reload();
            });
        }

        // Custom Alert ထိန်းချုပ်ရန် Functions များ
        function showCustomAlert() {
            document.getElementById('customAlertModal').style.display = 'flex';
        }

        function closeCustomAlert() {
            document.getElementById('customAlertModal').style.display = 'none';
        }

        window.onclick = function(event) {
            if (!event.target.matches('.fa-ellipsis') && !event.target.closest('.post-options-btn')) {
                document.querySelectorAll('.post-dropdown-menu').forEach(menu => {
                    menu.classList.remove('show');
                });
            }
            if (!event.target.matches('.comment-dots-btn') && !event.target.closest('.comment-dots-btn')) {
                document.querySelectorAll('.comment-dropdown-menu').forEach(menu => {
                    menu.classList.remove('show');
                });
            }
            const likesModal = document.getElementById('likesModal');
            if (event.target === likesModal) {
                closeLikesModal();
            }
            const customAlertModal = document.getElementById('customAlertModal');
            if (event.target === customAlertModal) {
                closeCustomAlert();
            }
        }

        function togglePostMenu(postId, event) {
            event.stopPropagation();
            document.querySelectorAll('.post-dropdown-menu').forEach(menu => {
                if (menu.id !== 'postMenu_' + postId) {
                    menu.classList.remove('show');
                }
            });
            let menu = document.getElementById('postMenu_' + postId);
            if(menu) {
                menu.classList.toggle('show');
            }
        }

        function toggleCommentMenu(commentId, event) {
            event.stopPropagation();
            document.querySelectorAll('.comment-dropdown-menu').forEach(menu => {
                if (menu.id !== 'commentMenu_' + commentId) {
                    menu.classList.remove('show');
                }
            });
            let menu = document.getElementById('commentMenu_' + commentId);
            if(menu) {
                menu.classList.toggle('show');
            }
        }

        function handleLike(postId, btn) {
            fetch('InteractServlet?action=like&postId=' + postId)
            .then(response => {
                if (response.ok) {
                    const icon = btn.querySelector('.heart-icon');
                    const postCard = document.getElementById('post-' + postId);
                    const countSpan = postCard.querySelector('.like-count-text');
                    let currentCount = parseInt(countSpan.textContent) || 0;

                    if (icon.classList.contains('fa-regular')) {
                        icon.classList.remove('fa-regular');
                        icon.classList.add('fa-solid');
                        icon.style.color = '#fa383e';
                        btn.classList.add('liked');
                        countSpan.textContent = currentCount + 1;
                    } else {
                        icon.classList.remove('fa-solid');
                        icon.classList.add('fa-regular');
                        icon.style.color = '';
                        btn.classList.remove('liked');
                        countSpan.textContent = Math.max(0, currentCount - 1);
                    }
                }
            })
            .catch(err => console.error("Error liking post:", err));
        }

        function submitComment(event, postId) {
            event.preventDefault();
            const form = event.target;
            
            const cTextInput = form.querySelector('input[name="commentText"]');
            const cText = cTextInput ? cTextInput.value : "";
            if (!cText.trim()) return;

            const formData = new FormData(form);
            formData.append('action', 'comment');

            fetch('InteractServlet', {
                method: 'POST',
                body: new URLSearchParams(formData)
            })
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                if (data.status === "success" || data.commentId) {
                    window.location.href = window.location.pathname + window.location.search + '#post-' + postId;
                    location.reload();
                }
            })
            .catch(err => {
                console.error("Error submitting comment:", err);
                window.location.href = window.location.pathname + window.location.search + '#post-' + postId;
                location.reload();
            });
        }

        window.addEventListener('DOMContentLoaded', () => {
            if (window.location.hash) {
                setTimeout(() => {
                    const targetPostCard = document.querySelector(window.location.hash);
                    if (targetPostCard) {
                        const commentSection = targetPostCard.querySelector('.comment-section');
                        if (commentSection) {
                            commentSection.style.display = 'flex';
                        }
                        targetPostCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                }, 150);
            }
        });

        function openReplyBox(postId, commentId, userName) {
            const existingReplyBox = document.getElementById('activeReplyBox_' + commentId);
            if (existingReplyBox) {
                existingReplyBox.remove();
                return;
            }

            const commentItem = document.getElementById('commentItem_' + commentId);
            const replyBoxHtml = document.createElement('form');
            replyBoxHtml.id = 'activeReplyBox_' + commentId;
            replyBoxHtml.className = 'reply-input-box';
            replyBoxHtml.onsubmit = function(event) {
                submitReply(event, postId, commentId);
            };

            replyBoxHtml.innerHTML = 
                '<input type="text" name="commentText" class="reply-input" placeholder="Reply to ' + userName + '" required autofocus>' +
                '<button type="submit" class="reply-send-btn">Send</button>';

            commentItem.appendChild(replyBoxHtml);
        }

        function submitReply(event, postId, parentCommentId) {
            event.preventDefault();
            const form = event.target;
            const commentInput = form.querySelector('input[name="commentText"]');
            const commentText = commentInput ? commentInput.value : "";
            if (!commentText.trim()) return;

            const params = new URLSearchParams();
            params.append('action', 'comment');
            params.append('postId', postId);
            params.append('commentText', commentText);
            params.append('parentId', parentCommentId);

            fetch('InteractServlet', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: params.toString()
            })
            .then(response => {
                if(response.ok) {
                    form.remove();
                    showToast('Reply sent');
                    setTimeout(() => { location.reload(); }, 1000);
                } else {
                    showToast('Something went wrong!');
                }
            })
            .catch(err => console.error("Error submitting reply:", err));
        }

        function enableEdit(commentId, userName) {
            const textSpan = document.getElementById("commentText_" + commentId);
            if (!textSpan) return;
            const originalText = textSpan.getAttribute("data-comment-text") || textSpan.innerText;
            const commentItem = document.getElementById("commentItem_" + commentId);
            
            commentItem.innerHTML = 
                '<div style="display: flex; gap: 6px; align-items: center; width: 100%; padding: 4px 0;">' +
                    '<input type="text" id="editText_' + commentId + '" value="' + originalText + '" style="flex: 1; padding: 6px 10px; font-size: 13px; border: 1px solid #ccd0d5; border-radius: 4px; outline: none;" />' +
                    '<button type="button" onclick="saveEdit(' + commentId + ', \'' + userName.replace(/'/g, "\\'") + '\')" style="font-size: 12px; background: #2e7d32; color: #fff; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-weight: 600;">Save</button>' +
                    '<button type="button" onclick="cancelEdit()" style="font-size: 12px; background: #e4e6eb; color: #050505; border: none; padding: 6px 10px; border-radius: 4px; cursor: pointer;">Cancel</button>' +
                '</div>';
            
            const inputField = document.getElementById("editText_" + commentId);
            if(inputField) {
                inputField.focus();
                inputField.setSelectionRange(inputField.value.length, inputField.value.length);
            }
        }

        function cancelEdit() {
            location.reload();
        }

        function saveEdit(commentId, userName) {
            const inputElement = document.getElementById("editText_" + commentId);
            if (!inputElement) return;
            const newText = inputElement.value;
            if(!newText.trim()) return;

            fetch('InteractServlet', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=editComment&commentId=' + commentId + '&newText=' + encodeURIComponent(newText)
            })
            .then(response => {
                if(response.ok) {
                    showToast('editing success!');
                    setTimeout(() => { location.reload(); }, 1000);
                }
            })
            .catch(err => console.error("Error editing comment:", err));
        }

        function deleteComment(commentId) {
            if(confirm("Are you sure you want to delete this comment?")) {
                fetch('InteractServlet', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=deleteComment&commentId=' + commentId
                })
                .then(response => {
                    if(response.ok) {
                        const commentItem = document.getElementById("commentItem_" + commentId);
                        if(commentItem) commentItem.remove();
                    }
                })
                .catch(err => console.error("Error deleting comment:", err));
            }
        }

        function openLikesModal(postId) {
            fetch('GetLikesServlet?postId=' + postId)
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById('likesUserListContainer');
                container.innerHTML = '';
                if(data.length === 0) {
                    container.innerHTML = '<div style="color: #8a8d91; text-align: center; font-size: 12px;">No likes yet</div>';
                } else {
                    data.forEach(username => {
                        container.innerHTML += '<div style="font-weight: 600; font-size: 13px; color: #050505; padding: 6px 8px; background: #f0f2f5; border-radius: 4px;"><i class="fa-solid fa-user" style="margin-right: 6px; color: #2e7d32;"></i>' + username + '</div>';
                    });
                }
                document.getElementById('likesModal').style.display = 'flex';
            })
            .catch(err => console.error("Error fetching likes:", err));
        }

        function closeLikesModal() {
            document.getElementById('likesModal').style.display = 'none';
        }

        function toggleComments(element) {
            const postCard = element.closest('.post-card');
            const commentSection = postCard.querySelector('.comment-section');
            commentSection.style.display = commentSection.style.display === 'flex' ? 'none' : 'flex';
            if (commentSection.style.display === 'flex') {
                commentSection.querySelector('.comment-input').focus();
            }
        }

        function showToast(message) {
            const toast = document.getElementById('toast');
            toast.innerText = message;
            toast.classList.add('show');
            setTimeout(() => { toast.classList.remove('show'); }, 2000);
        }
    </script>
</body>
</html>