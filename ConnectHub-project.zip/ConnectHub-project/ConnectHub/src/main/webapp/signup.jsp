<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Social Media</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, sans-serif; }
        body { background-color: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .signup-container { background: white; padding: 35px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        .signup-container h2 { text-align: center; margin-bottom: 24px; color: #2e7d32; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; color: #555; font-size: 14px; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ccd0d5; border-radius: 6px; font-size: 14px; }
        .form-group input:focus { border-color: #2e7d32; outline: none; box-shadow: 0 0 4px rgb(0, 128, 0); }
        .btn-container { display: flex; gap: 10px; margin-top: 20px; }
        .btn { width: 100%; padding: 12px; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer; }
        .create-btn { background: #42b72a; color: white; }
        .create-btn:hover { background: #36a420; }
        .cancel-btn { background: #e4e6eb; color: #4b4f56; }
        .cancel-btn:hover { background: #d8dadf; }
        .error-msg { color: red; text-align: center; font-size: 14px; margin-bottom: 15px; }
        .login-link { text-align: center; margin-top: 20px; font-size: 14px; color: #666; }
        .login-link a { color: #2e7d32; text-decoration: none; }
        .login-link a:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <div class="signup-container">
        <h2>Create Account</h2>
        
        <!-- Error ရှိက ပြရန် -->
        <% 
            String error = request.getParameter("error");
            if(error != null) {
                if(error.equals("duplicate")) {
        %>
            <div class="error-msg">This email has already account. Please Log In.</div>
        <%      } else { %>
            <div class="error-msg">Something went wrong!Please try again.</div>
        <%      } 
            } 
        %>
        
        <form id="signupForm" action="SignupServlet" method="POST">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="name" placeholder="Enter your name" required>
            </div>

            <div class="form-group">
                <label>Gmail</label>
                <input type="email" name="email" placeholder="example@gmail.com" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="create password" required>
            </div>

            <div class="btn-container">
                <button type="button" class="btn cancel-btn" onclick="clearForm()">Cancel</button>
                <button type="submit" class="btn create-btn">Create Account</button>
            </div>
        </form>

        <div class="login-link">
            Have a count? <a href="index.jsp">Log In</a>
        </div>
    </div>

    <script>
        
        function clearForm() {
            document.getElementById('signupForm').reset();
        }
    </script>

</body>
</html>