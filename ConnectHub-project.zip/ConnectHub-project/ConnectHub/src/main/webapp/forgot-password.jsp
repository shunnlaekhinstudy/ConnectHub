<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Forgot Password - ConnectHub</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, sans-serif; }
        body { background-color: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .container { background: white; padding: 35px; border-radius: 10px; box-shadow: 0 4px 12px rgb(0, 128, 0); width: 100%; max-width: 400px; }
        h2 { text-align: center; margin-bottom: 20px; color: #2e7d32; }
        p { font-size: 14px; color: #666; text-align: center; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; color: #555; font-size: 14px; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ccd0d5; border-radius: 6px; font-size: 14px; }
        .btn { width: 100%; padding: 12px; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer; background:#2e7d32; color: white; margin-top: 10px; }
        .btn:hover { background: #2e7d32; }
        .error-msg { color: red; text-align: center; font-size: 14px; margin-bottom: 15px; }
        .back-link { text-align: center; margin-top: 20px; font-size: 14px; }
        .back-link a { color: #2e7d32; text-decoration: none; }
    </style>
</head>
<body>

    <div class="container">
        <h2>Reset Password</h2>
        <p>Fill your email</p>
        
        <% 
            String error = request.getParameter("error");
            if(error != null) {
        %>
            <div class="error-msg">No Account</div>
        <% } %>

        <form action="ForgotPasswordServlet" method="POST">
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="example@gmail.com" required>
            </div>
            <button type="submit" class="btn">Continue</button>
        </form>

        <div class="back-link">
            <a href="index.jsp">← Log In page</a>
        </div>
    </div>

</body>
</html>