<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String resetEmail = (String) session.getAttribute("resetEmail");
    if(resetEmail == null) {
        response.sendRedirect("forgot-password.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reset Password - ConnectHub</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, sans-serif; }
        body { background-color: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .container { background: white; padding: 35px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        h2 { text-align: center; margin-bottom: 20px; color: #2e7d32; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; color: #555; font-size: 14px; }
        .form-group input { width: 100%; padding: 10px; box-shadow: 0 0 4px rgb(0, 128, 0); border-radius: 6px; font-size: 14px; }
        .btn { width: 100%; padding: 12px; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer; background:#2e7d32; color: white; margin-top: 10px; }
        .btn:hover { background:#2e7d32; }
    </style>
</head>
<body>

    <div class="container">
        <h2>Reset Password</h2>
        
        <form action="ResetPasswordServlet" method="POST">
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="newPassword" placeholder="Create new password" required>
            </div>
            <button type="submit" class="btn">Submit</button>
        </form>
    </div>

</body>
</html>