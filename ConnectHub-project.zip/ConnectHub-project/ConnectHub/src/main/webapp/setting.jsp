<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String userName = (String) session.getAttribute("userName");
    Integer userId = (Integer) session.getAttribute("user_id");
    
    if(userName == null || userId == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    
    // Session ထဲတွင် ရှိနေသော User ၏ သီးသန့် Background ကို ယူသုံးသည်
    String savedBg = (String) session.getAttribute("appBgColor");
    if(savedBg == null) savedBg = "#ffffff"; 

    // အကယ်၍ Session ထဲမှာ သိမ်းထားတယ်ဆိုရင်
    String userEmail = (String) session.getAttribute("userEmail");
    if(userEmail == null) userEmail = "";
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setting - Connect Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --app-bg: <%= savedBg %>;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; transition: background 0.3s, color 0.3s; }
        
        body {
            background: #f0f2f5;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            padding: 20px 10px;
        }

        /* Custom Toast Notification Styling */
        .custom-toast {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%) translateY(100px);
            background: #2e7d32;
            color: #ffffff;
            padding: 12px 24px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 9999;
            opacity: 0;
            transition: all 0.3s ease-in-out;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .custom-toast.show {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }

        .phone-container {
            width: 100%;
            max-width: 480px;
            background: var(--app-bg) !important;
            background-attachment: fixed;
            min-height: 100vh;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            position: relative;
            display: flex;
            flex-direction: column;
            padding-bottom: 30px;
            box-sizing: border-box;
        }

        .app-header {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 16px 20px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.08);
            background: transparent;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        .back-btn {
            background: rgba(0, 0, 0, 0.05);
            border: none;
            color: #2e7d32;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            font-size: 15px;
            cursor: pointer;
        }
        .back-btn:hover { background: rgba(0, 0, 0, 0.1); }
        .app-title { color: #2e7d32; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; cursor: pointer; }

        .settings-body {
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            background: transparent;
            flex: 1;
        }

        .section-label {
            font-size: 12px;
            font-weight: 700;
            color: #555;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-bottom: 6px;
            padding-left: 4px;
        }

        .card-list {
            background: transparent !important;
            backdrop-filter: blur(5px);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }

        .setting-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 18px;
            text-decoration: none;
            color: #050505;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            background: transparent;
            width: 100%;
            border-top: none;
            border-left: none;
            border-right: none;
            cursor: pointer;
            text-align: left;
        }
        .setting-item:last-child { border-bottom: none; }
        .setting-item:hover { background: rgba(255, 255, 255, 0.6); }

        .item-left { display: flex; align-items: center; gap: 14px; }
        .item-left i { font-size: 16px; color: #4b4f56; width: 22px; text-align: center; }
        .item-text { font-size: 14px; font-weight: 600; color: #050505; }
        
        .item-right { display: flex; align-items: center; gap: 8px; color: #4b4f56; font-size: 13px; }
        .text-danger { color: #e41e3f !important; }

        .modal-overlay {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            backdrop-filter: blur(3px);
            padding: 15px;
        }
        .modal-box {
            background: #ffffff;
            width: 100%;
            max-width: 420px;
            border-radius: 16px;
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 16px;
            box-shadow: 0 12px 28px rgba(0,0,0,0.15);
            animation: fadeInScale 0.2s ease;
        }
        @keyframes fadeInScale {
            from { transform: scale(0.92); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .modal-header-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 16px;
            font-weight: 700;
            color: #050505;
        }
        .close-btn { background: #f0f2f5; border: none; color: #65676b; width: 30px; height: 30px; border-radius: 50%; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; }

        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-label { font-size: 12px; font-weight: 600; color: #65676b; }
        .form-control {
            padding: 12px 14px;
            border-radius: 8px;
            border: 1px solid #ccd0d5;
            background: #ffffff;
            color: #050505;
            font-size: 14px;
            outline: none;
        }
        .form-control:focus { border-color: #1b74e4; }

        .btn-action {
            background: rgb(0, 128, 0);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            text-align: center;
        }
        .btn-action:hover { background: rgb(0, 128, 0); }

        .color-palette-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 10px;
            max-height: 260px;
            overflow-y: auto;
            padding: 4px;
        }
        .color-box {
            width: 100%;
            height: 38px;
            border-radius: 8px;
            cursor: pointer;
            border: 1px solid rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .color-box:hover { transform: scale(1.08); }

        .custom-alert-overlay {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            backdrop-filter: blur(3px);
            padding: 15px;
        }
        .custom-alert-box {
            background: #ffffff;
            width: 100%;
            max-width: 360px;
            border-radius: 16px;
            padding: 24px;
            text-align: center;
            display: flex;
            flex-direction: column;
            gap: 14px;
            box-shadow: 0 12px 28px rgba(0,0,0,0.15);
        }
        .alert-icon { font-size: 38px; color: #f7b125; margin-bottom: -4px; }
        .alert-title { font-size: 17px; font-weight: 700; color: #050505; }
        .alert-msg { font-size: 13px; color: #65676b; line-height: 1.5; }
        .alert-btn-group { display: flex; gap: 10px; margin-top: 6px; }
        .btn-cancel { background: #e4e6eb; color: #4b4f56; border: none; padding: 10px; border-radius: 8px; font-weight: 600; width: 100%; cursor: pointer; }
        .btn-confirm-ok { background: #e41e3f; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: 600; width: 100%; cursor: pointer; }
    </style>
</head>
<body>

    <div class="phone-container">
        <div class="app-header">
            <a href="HomeServlet" class="back-btn"><i class="fa-solid fa-arrow-left"></i></a>
            <div class="app-title">Setting</div>
        </div>

        <div class="settings-body">
            <div>
                <div class="section-label">Account Management</div>
                <div class="card-list">
                    <button onclick="openModal('infoModal')" class="setting-item">
                        <div class="item-left"><i class="fa-solid fa-user-pen"></i><span class="item-text">Change Account Information</span></div>
                        <div class="item-right"><span><%= userName %></span><i class="fa-solid fa-chevron-right"></i></div>
                    </button>
                    
                    <button onclick="showLogoutConfirm()" class="setting-item">
                        <div class="item-left"><i class="fa-solid fa-right-from-bracket" style="color: #f7b125;"></i><span class="item-text">Log Out</span></div>
                        <div class="item-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </button>

                    <button onclick="showDeleteConfirm()" class="setting-item">
                        <div class="item-left"><i class="fa-solid fa-trash-can text-danger"></i><span class="item-text text-danger">Delete Account</span></div>
                        <div class="item-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </button>
                </div>
            </div>

            <div>
                <div class="section-label">Customization</div>
                <div class="card-list">
                    <button onclick="openModal('themeModal')" class="setting-item">
                        <div class="item-left"><i class="fa-solid fa-palette"></i><span class="item-text">Background Theme</span></div>
                        <div class="item-right"><span>Change color</span><i class="fa-solid fa-chevron-right"></i></div>
                    </button>
                </div>
            </div>

            <div>
                <div class="section-label">Support & Feedback</div>
                <div class="card-list">
                    <button onclick="openModal('aboutModal')" class="setting-item">
                        <div class="item-left"><i class="fa-solid fa-circle-info"></i><span class="item-text">Contact us</span></div>
                        <div class="item-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </button>

                    <button onclick="openModal('feedbackModal')" class="setting-item">
                        <div class="item-left"><i class="fa-solid fa-comments"></i><span class="item-text">Feedback and Advice</span></div>
                        <div class="item-right"><i class="fa-solid fa-chevron-right"></i></div>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL 1 -->
    <div id="infoModal" class="modal-overlay">
        <form action="SettingServlet" method="POST" class="modal-box">
            <input type="hidden" name="action" value="updateInfo">
            <div class="modal-header-bar">
                <span>Change Account Information</span>
                <button type="button" class="close-btn" onclick="closeModal('infoModal')">&times;</button>
            </div>
            <div class="form-group">
                <label class="form-label"><%= userName %></label>
                <input type="text" name="name" class="form-control" value="<%= userName %>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<%= userEmail %>" placeholder="example@gmail.com" required>
            </div>
            <div class="form-group">
                <label class="form-label">New Password</label>
                <input type="password" name="password" class="form-control" placeholder="Leave blank if you do not want to change it">
            </div>
            <button type="submit" class="btn-action">Change</button>
        </form>
    </div>

    <!-- MODAL 2 (30 Colors) -->
    <div id="themeModal" class="modal-overlay">
        <div class="modal-box">
            <div class="modal-header-bar">
                <span>Choose background</span>
                <button type="button" class="close-btn" onclick="closeModal('themeModal')">&times;</button>
            </div>
            <div class="form-group">
                <label class="form-label">choose one color</label>
            </div>
            <div class="color-palette-grid">
                <div class="color-box" style="background:#ffffff;" onclick="setBg('#ffffff')"></div>
                <div class="color-box" style="background:#fdf2e9;" onclick="setBg('#fdf2e9')"></div>
                <div class="color-box" style="background:#fadbd8;" onclick="setBg('#fadbd8')"></div>
                <div class="color-box" style="background:#d4efdf;" onclick="setBg('#d4efdf')"></div>
                <div class="color-box" style="background:#d1f2eb;" onclick="setBg('#d1f2eb')"></div>
                <div class="color-box" style="background:#ebdef0;" onclick="setBg('#ebdef0')"></div>
                <div class="color-box" style="background:#fcf3cf;" onclick="setBg('#fcf3cf')"></div>
                <div class="color-box" style="background:#e8f8f5;" onclick="setBg('#e8f8f5')"></div>
                <div class="color-box" style="background:#f9ebea;" onclick="setBg('#f9ebea')"></div>
                <div class="color-box" style="background:#eaeded;" onclick="setBg('#eaeded')"></div>
                <div class="color-box" style="background:#e0f2fe;" onclick="setBg('#e0f2fe')"></div>
                <div class="color-box" style="background:#f3e8ff;" onclick="setBg('#f3e8ff')"></div>
                <div class="color-box" style="background:#ffe4e6;" onclick="setBg('#ffe4e6')"></div>
                <div class="color-box" style="background:#ccfbf1;" onclick="setBg('#ccfbf1')"></div>
                <div class="color-box" style="background:#fef9c3;" onclick="setBg('#fef9c3')"></div>
                
                <div class="color-box" style="background:linear-gradient(135deg, #f6d365, #fda085);" onclick="setBg('linear-gradient(135deg, #f6d365, #fda085)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #84fab0, #8fd3f4);" onclick="setBg('linear-gradient(135deg, #84fab0, #8fd3f4)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #a1c4fd, #c2e9fb);" onclick="setBg('linear-gradient(135deg, #a1c4fd, #c2e9fb)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #ff9a9e, #fecfef);" onclick="setBg('linear-gradient(135deg, #ff9a9e, #fecfef)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #ffecd2, #fcb69f);" onclick="setBg('linear-gradient(135deg, #ffecd2, #fcb69f)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #ff758c, #ff7eb3);" onclick="setBg('linear-gradient(135deg, #ff758c, #ff7eb3)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #65dfc9, #6cdbeb);" onclick="setBg('linear-gradient(135deg, #65dfc9, #6cdbeb)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #fbc531, #e84118);" onclick="setBg('linear-gradient(135deg, #fbc531, #e84118)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #4cd137, #009432);" onclick="setBg('linear-gradient(135deg, #4cd137, #009432)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #192a56, #273c75);" onclick="setBg('linear-gradient(135deg, #192a56, #273c75)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #ff4e50, #f9d423);" onclick="setBg('linear-gradient(135deg, #ff4e50, #f9d423)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #2b5876, #4e4376);" onclick="setBg('linear-gradient(135deg, #2b5876, #4e4376)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #fa709a, #fee140);" onclick="setBg('linear-gradient(135deg, #fa709a, #fee140)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #30cfd0, #330867);" onclick="setBg('linear-gradient(135deg, #30cfd0, #330867)')"></div>
                <div class="color-box" style="background:linear-gradient(135deg, #c471f5, #fa71cd);" onclick="setBg('linear-gradient(135deg, #c471f5, #fa71cd)')"></div>
            </div>
        </div>
    </div>

    <!-- MODAL 3 -->
    <!-- MODAL 3: About Us & Contact -->
    <div id="aboutModal" class="modal-overlay">
        <div class="modal-box">
            <div class="modal-header-bar">
                <span>About Us & Support</span>
                <button type="button" class="close-btn" onclick="closeModal('aboutModal')">&times;</button>
            </div>
            <p style="font-size: 13px; color: #65676b; line-height: 1.6;">
                <b>Connect Hub System v1.0</b><br>
                A collaborative mini social media platform created by students to connect and share experiences.<br><br>
                <b>Support Email:</b> support@connecthub.edu.mm<br>
                <b>Working Hours:</b> Mon - Fri (9:00 AM - 5:00 PM)
            </p>
        </div>
    </div>

    <!-- MODAL 4 -->
    <div id="feedbackModal" class="modal-overlay">
        <form action="SettingServlet" method="POST" class="modal-box">
            <input type="hidden" name="action" value="submitFeedback">
            <div class="modal-header-bar">
                <span>Advice and feedback</span>
                <button type="button" class="close-btn" onclick="closeModal('feedbackModal')">&times;</button>
            </div>
            <div class="form-group">
                <label class="form-label">Your advice</label>
                <textarea name="feedback" class="form-control" rows="4" placeholder="Write advice and feedback...." required></textarea>
            </div>
            <button type="submit" class="btn-action" style="background: rgb(0, 128, 0);">Send advice</button>
        </form>
    </div>

    <!-- CUSTOM ALERT CONFIRMATION -->
    <div id="customAlert" class="custom-alert-overlay">
        <div class="custom-alert-box">
            <i class="fa-solid fa-triangle-exclamation alert-icon" id="alertIcon"></i>
            <div class="alert-title" id="alertTitle">Are you sure?</div>
            <div class="alert-msg" id="alertMsg">Are you sure to do this Action?</div>
            <div class="alert-btn-group">
                <button type="button" class="btn-cancel" onclick="closeCustomAlert()">Cancel</button>
                <button type="button" class="btn-confirm-ok" id="alertConfirmBtn" onclick="executeConfirmedAction()">OK</button>
            </div>
        </div>
    </div>

    <!-- Custom Toast Box -->
    <div id="successToast" class="custom-toast">
        <i class="fa-solid fa-circle-check" style="font-size: 16px;"></i>
        <span id="toastMsg">Success!</span>
    </div>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
        }
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function setBg(colorValue) {
            window.location.href = "SettingServlet?action=updateTheme&bg=" + encodeURIComponent(colorValue);
        }

        let currentConfirmAction = null;

        function showLogoutConfirm() {
            document.getElementById('alertIcon').className = "fa-solid fa-right-from-bracket alert-icon";
            document.getElementById('alertIcon').style.color = "#f7b125";
            document.getElementById('alertTitle').innerText = "Log out";
            document.getElementById('alertMsg').innerText = "Are you sure to log out?";
            document.getElementById('alertConfirmBtn').style.background = "#f7b125";
            document.getElementById('alertConfirmBtn').innerText = "Log out";
            currentConfirmAction = function() {
                window.location.href = "SettingServlet?action=logout";
            };
            document.getElementById('customAlert').style.display = 'flex';
        }

        function showDeleteConfirm() {
            document.getElementById('alertIcon').className = "fa-solid fa-triangle-exclamation alert-icon";
            document.getElementById('alertIcon').style.color = "#e41e3f";
            document.getElementById('alertTitle').innerText = "Delete Account";
            document.getElementById('alertMsg').innerText = "Are you sure to delete? This action cannot be undone.";
            document.getElementById('alertConfirmBtn').style.background = "#e41e3f";
            document.getElementById('alertConfirmBtn').innerText = "Delete";
            currentConfirmAction = function() {
                window.location.href = "SettingServlet?action=deleteAccount";
            };
            document.getElementById('customAlert').style.display = 'flex';
        }

        function closeCustomAlert() {
            document.getElementById('customAlert').style.display = 'none';
        }

        function executeConfirmedAction() {
            if(currentConfirmAction) currentConfirmAction();
        }

        // URL ထဲတွင် success=feedback ပါလာလျှင် လှပသော Toast ပြရန်
        document.addEventListener("DOMContentLoaded", function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('success') === 'feedback') {
                showToast("Feedback Sent!");
                
                // URL ထဲက ?success=feedback ကို ဖြတ်ထုတ်ရန်
                window.history.replaceState({}, document.title, window.location.pathname);
            }
        });

        // Toast ပြသရန် Function (၃ စက္ကန့်ကြာလျှင် အလိုလို ပျောက်သွားမည်)
        function showToast(message) {
            const toast = document.getElementById('successToast');
            document.getElementById('toastMsg').innerText = message;
            
            toast.classList.add('show');
            
            setTimeout(function() {
                toast.classList.remove('show');
            }, 3000); // ၃ စက္ကန့် (3000 ms) ကြာလျှင် အလိုလို ပျောက်မည်
        }
    </script>
</body>
</html>