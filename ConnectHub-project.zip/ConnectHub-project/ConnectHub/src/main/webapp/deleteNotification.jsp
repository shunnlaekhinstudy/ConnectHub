<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="model.NotificationDAO" %>
<%@ page import="jakarta.servlet.http.HttpSession" %>
<%
    request.setCharacterEncoding("UTF-8");
    
    HttpSession currentSession = request.getSession(false);
    Object userIdObj = (currentSession != null) ? currentSession.getAttribute("user_id") : null;
    
    if (userIdObj == null) {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        out.print("UNAUTHORIZED");
        return;
    }

    int currentUserId = 0;
    try {
        currentUserId = Integer.parseInt(String.valueOf(userIdObj));
    } catch (NumberFormatException e) {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        out.print("UNAUTHORIZED");
        return;
    }

    String notifIdStr = request.getParameter("notif_id");
    
    if (notifIdStr != null && !notifIdStr.trim().isEmpty()) {
        try {
            int notifId = Integer.parseInt(notifIdStr);
            
            NotificationDAO notifDao = new NotificationDAO();
            boolean success = notifDao.deleteNotification(notifId, currentUserId);
            
            if (success) {
                response.setStatus(HttpServletResponse.SC_OK);
                out.print("SUCCESS");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print("NOT_FOUND");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("ERROR");
        }
    } else {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        out.print("BAD_REQUEST");
    }
%>