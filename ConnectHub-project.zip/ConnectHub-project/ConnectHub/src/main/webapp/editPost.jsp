<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*, model.DBConnection" %>
<%
    Integer postId = (Integer) request.getAttribute("postId");
    String postTitle = (String) request.getAttribute("postTitle");
    String postContent = (String) request.getAttribute("postContent");
    String bgStyle = (String) request.getAttribute("bgStyle");
    
    // URL ကနေ 'from' parameter ကို လက်ခံရယူခြင်း (home လား၊ profile လား)
    String from = request.getParameter("from");
    if (from == null || from.trim().isEmpty()) {
        from = "home"; // Default အနေဖြင့် home သို့ ပို့ရန်
    }

    if (postId == null) {
        response.sendRedirect("ProfileServlet");
        return;
    }

    if (postTitle == null) postTitle = "";
    if (postContent == null) postContent = "";
    if (bgStyle == null || bgStyle.trim().isEmpty()) bgStyle = "#ffffff";
%>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post - Connect Hub</title>
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* သင်၏ မူရင်း CSS များ အတိုင်း အားလုံး ထားရှိပါသည် */
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
        }
        .phone-container {
            width: 100%;
            max-width: 480px;
            background-color: #ffffff;
            min-height: 100vh;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            position: relative;
            display: flex;
            flex-direction: column;
            padding-bottom: 30px;
            box-sizing: border-box;
        }
        .phone-top-header {
            display: flex; justify-content: space-between; align-items: center; padding: 12px 15px; background-color: #fff; border-bottom: 1px solid #e4e6eb; position: sticky; top: 0; z-index: 100; 
        }
        .back-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: #050505; padding: 0; text-decoration: none; }
        .header-title { font-size: 18px; font-weight: 700; color: #050505; }
        .phone-screen-content {
            flex: 1;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
        }
        .post-inputs-wrapper {
            background-color: #ffffff;
            border-radius: 12px;
            padding: 15px;
            box-sizing: border-box;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            border: 1px solid #f0f2f5;
            transition: background 0.3s ease, background-image 0.3s ease;
            background-size: cover;
            background-position: center;
        }
        .post-title-input {
            width: 100%;
            border: none !important;
            background: transparent !important;
            outline: none;
            font-size: 16px;
            font-weight: bold;
            color: #050505;
            border-bottom: 1px solid rgba(0,0,0,0.15) !important;
            padding-bottom: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
        .post-text-input {
            width: 100%;
            border: none !important;
            background: transparent !important;
            outline: none;
            font-family: inherit;
            font-size: 14px;
            color: #050505;
            line-height: 1.5;
            resize: none;
            min-height: 80px;
            box-sizing: border-box;
        }
        .post-images-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 15px;
        }
        .post-images-grid img {
            width: 100%;
            max-height: 250px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid rgba(0,0,0,0.1);
        }
        .bottom-action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 18px;
            border-top: 1px solid #f0f2f5;
            padding-top: 12px;
            position: relative;
        }
        .tools-group { display: flex; align-items: center; gap: 10px; }
        .color-picker-wrapper { position: relative; }
        .color-logo-btn {
            background: #f0f2f5; border: 1px solid #ccd0d5; padding: 7px 12px; border-radius: 20px; cursor: pointer; font-size: 13px; display: flex; align-items: center; justify-content: center; color: #333; font-weight: 500; gap: 5px;
        }
        .color-palette-grid {
            display: none; position: absolute; bottom: 45px; left: 0; background: #fff; border: 1px solid #ccd0d5; padding: 12px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); grid-template-columns: repeat(5, 1fr); gap: 10px; z-index: 150; width: 240px; box-sizing: border-box;
        }
        .color-box { width: 34px; height: 34px; border-radius: 50%; cursor: pointer; border: 1px solid #ddd; justify-self: center; }
        .btn-small-post { background: #1877f2; color: white; border: none; padding: 8px 18px; border-radius: 20px; cursor: pointer; font-size: 13px; font-weight: bold; }
        .btn-small-post:hover { background: #166fe5; }
    </style>
</head>
<body>

    <div class="phone-container">
        <div class="phone-top-header">
            <!-- Back Button ကို History သို့မဟုတ် လာခဲ့သည့်နေရာအလိုက် ပြန်ရန် -->
            <a href="javascript:history.back()" class="back-btn"><i class="fa-solid fa-arrow-left"></i></a>
            <div class="header-title">Edit Post</div>
            <div style="width: 20px;"></div>
        </div>

        <form action="EditPostServlet" method="POST" class="phone-screen-content">
            
            <input type="hidden" name="postId" value="<%= postId %>">
            <input type="hidden" name="bgStyle" id="bgStyleInput" value="<%= bgStyle %>">
            <!-- ဘယ်ကလာတယ်ဆိုတာကို Servlet သို့ ပို့ရန် Hidden Field ထည့်ခြင်း -->
            <input type="hidden" name="from" value="<%= from %>">

            <%
                String cardBg = bgStyle;
                String bgStyleAttr;
                if (cardBg != null && cardBg.startsWith("linear-gradient")) {
                    bgStyleAttr = "background-image: " + cardBg + "; background-color: transparent;";
                } else {
                    bgStyleAttr = "background-color: " + (cardBg != null ? cardBg : "#ffffff") + "; background-image: none;";
                }
            %>

            <div class="post-inputs-wrapper" id="postCardBg" style="<%= bgStyleAttr %>">
                <input type="text" name="postTitle" class="post-title-input" placeholder="ခေါင်းစဉ် ရေးပါ..." value="<%= postTitle %>" required>
                
                <textarea name="postContent" class="post-text-input" placeholder="ဘာတွေ စဉ်းစားနေလဲ..." required><%= postContent %></textarea>
                
                <div class="post-images-grid">
                    <%
                        Connection conn = null;
                        PreparedStatement imgStmt = null;
                        ResultSet imgRs = null;
                        try {
                            conn = DBConnection.getConnection();
                            imgStmt = conn.prepareStatement("SELECT image_name FROM post_images WHERE post_id = ?");
                            imgStmt.setInt(1, postId);
                            imgRs = imgStmt.executeQuery();
                            while(imgRs.next()) {
                                String imgName = imgRs.getString("image_name");
                    %>
                                <img src="uploads/<%= imgName %>" alt="Post Image">
                    <%
                            }
                        } catch(Exception e) {
                            out.println("<p style='color:red; font-size:12px;'>Error loading images</p>");
                        } finally {
                            if(imgRs != null) imgRs.close();
                            if(imgStmt != null) imgStmt.close();
                            if(conn != null) conn.close();
                        }
                    %>
                </div>
            </div>

            <div class="bottom-action-bar">
                <div class="tools-group">
                    <div class="color-picker-wrapper">
                        <button type="button" class="color-logo-btn" onclick="toggleColorPalette()">🎨 အရောင်</button>
                        
                        <div class="color-palette-grid" id="colorPaletteGrid">
                            <div class="color-box" style="background:#ffffff;" onclick="setBg('#ffffff')"></div>
                            <div class="color-box" style="background:#fdf2e9;" onclick="setBg('#fdf2e9')"></div>
                            <div class="color-box" style="background:#fadbd8;" onclick="setBg('#fadbd8')"></div>
                            <div class="color-box" style="background:#d4efdf;" onclick="setBg('#d4efdf')"></div>
                            <div class="color-box" style="background:#d1f2eb;" onclick="setBg('#d1f2eb')"></div>
                            <div class="color-box" style="background:#ebdef0;" onclick="setBg('#ebdef0')"></div>
                            <div class="color-box" style="background:#fcf3cf;" onclick="setBg('#fcf3cf')"></div>
                            <div class="color-box" style="background:#e8f8f5;" onclick="setBg('#e8f8f5')"></div>
                            <div class="color-box" style="background:#f9ebea;" onclick="setBg('#f9ebea')"></div>
                            <div class="color-box" style="background:#eaeded;" onclick="setBg('#eaeded')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #f6d365, #fda085);" onclick="setBg('linear-gradient(135deg, #f6d365, #fda085)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #84fab0, #8fd3f4);" onclick="setBg('linear-gradient(135deg, #84fab0, #8fd3f4)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #a1c4fd, #c2e9fb);" onclick="setBg('linear-gradient(135deg, #a1c4fd, #c2e9fb)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #ff9a9e, #fecfef);" onclick="setBg('linear-gradient(135deg, #ff9a9e, #fecfef)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #ffecd2, #fcb69f);" onclick="setBg('linear-gradient(135deg, #ffecd2, #fcb69f)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #ff758c, #ff7eb3);" onclick="setBg('linear-gradient(135deg, #ff758c, #ff7eb3)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #65dfc9, #6cdbeb);" onclick="setBg('linear-gradient(135deg, #65dfc9, #6cdbeb)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #fbc531, #e84118);" onclick="setBg('linear-gradient(135deg, #fbc531, #e84118)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #4cd137, #009432);" onclick="setBg('linear-gradient(135deg, #4cd137, #009432)')"></div>
                            <div class="color-box" style="background:linear-gradient(135deg, #192a56, #273c75);" onclick="setBg('linear-gradient(135deg, #192a56, #273c75)')"></div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-small-post">Save Changes</button>
            </div>

        </form>
    </div>

    <script>
        function toggleColorPalette() {
            const grid = document.getElementById('colorPaletteGrid');
            grid.style.display = grid.style.display === 'grid' ? 'none' : 'grid';
        }

        function setBg(colorValue) {
            const postCard = document.getElementById('postCardBg');
            
            if (colorValue.startsWith('linear-gradient')) {
                postCard.style.backgroundImage = colorValue;
                postCard.style.backgroundColor = 'transparent';
            } else {
                postCard.style.backgroundColor = colorValue;
                postCard.style.backgroundImage = 'none';
            }

            document.getElementById('bgStyleInput').value = colorValue;
            document.getElementById('colorPaletteGrid').style.display = 'none';
        }
    </script>
</body>
</html>