<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>

<%
    Integer userId = (Integer) session.getAttribute("user_id");
    String userName = (String) session.getAttribute("userName");
    if (userName == null) {
        userName = (String) session.getAttribute("user");
    }
    if (userName == null) {
        userName = "User";
    }

    // Login ဝင်ထားခြင်း မရှိလျှင် index.jsp သို့ ပြန်ပို့ရန်
    if (userId == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    String savedBg = (String) session.getAttribute("appBgColor");
    if(savedBg == null) savedBg = "#ffffff";

    // Servlet မှ ပို့ပေးသော ဒေတာများကို ရယူခြင်း
    List<Map<String, Object>> feedPostsList = (List<Map<String, Object>>) request.getAttribute("feedPostsList");
    List<Map<String, Object>> myFriends = (List<Map<String, Object>>) request.getAttribute("friendList");
    List<Map<String, Object>> suggestions = (List<Map<String, Object>>) request.getAttribute("suggestions");
    List<Map<String, Object>> friendRequests = (List<Map<String, Object>>) request.getAttribute("friendRequests");

    Integer unreadCountObj = (Integer) request.getAttribute("unreadCount");
    int unreadCount = (unreadCountObj != null) ? unreadCountObj : 0;

    boolean hasUnreadNotifications = request.getAttribute("hasUnreadNotifications") != null && (Boolean) request.getAttribute("hasUnreadNotifications");
    boolean hasPendingRequests = request.getAttribute("hasPendingRequests") != null && (Boolean) request.getAttribute("hasPendingRequests");
    boolean hasUnreadMessages = request.getAttribute("hasUnreadMessages") != null && (Boolean) request.getAttribute("hasUnreadMessages");
%> 
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Friends - Connect Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
     :root { --app-bg: <%= savedBg %>; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
         .phone-container { 
            width: 100%; 
            max-width: 480px; 
            background: var(--app-bg); 
            min-height: 100vh; 
            box-shadow: 0 0 15px rgba(0,0,0,0.1); 
            position: relative; 
            display: flex; 
            flex-direction: column; 
            padding-bottom: 30px; 
        }
        /* Header */
        .header { display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; background: var(--app-bg); position: sticky; top: 0; z-index: 100; border-bottom: 1px solid #e4e6eb; }
        .logo-area { display: flex; align-items: center; gap: 10px; }
        .menu-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: #2e7d32; }
        .logo { color: #2e7d32; font-size: 24px; font-weight: 800; letter-spacing: -0.5px; cursor: pointer; }
        .icon-btn { background-color: #e8f5e9; border: none; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 16px; color: #2e7d32; cursor: pointer; }

        /* Navigation Tabs */
         .nav-tabs { display: flex; justify-content: space-around; background: var(--app-bg); border-bottom: 1px solid #e4e6eb; padding: 0 10px; position: sticky; top: 57px; z-index: 99; }
        .nav-tab { flex: 1; text-align: center; padding: 12px 0; font-size: 20px; color: #65676b; cursor: pointer; position: relative; }
        .nav-tab.active { color: #2e7d32; }
        .nav-tab.active::after { content: ''; position: absolute; bottom: 0; left: 0; width: 100%; height: 3px; background-color: #2e7d32; }
        .red-dot { position: absolute; top: 6px; right: 32%; width: 9px; height: 9px; background-color: #e41e3f; border-radius: 50%; border: 2px solid #ffffff; }

        /* Sub Filters */
        .sub-filters { display: flex; gap: 8px; padding: 12px 15px; background: var(--app-bg); border-bottom: 1px solid #e4e6eb; overflow-x: auto; }
        .filter-chip { background-color: #e4e6eb; padding: 8px 16px; border-radius: 20px; font-size: 14px; font-weight: 600; cursor: pointer; color: #050505; transition: 0.2s; white-space: nowrap; }
        .filter-chip.active { background-color: #e8f5e9; color: #2e7d32; }

        /* Section Container */
        .tab-content { display: none; flex: 1; overflow-y: auto; padding-bottom: 20px; }
        .tab-content.active { display: block; }

        .section-header { display: flex; justify-content: space-between; align-items: center; padding: 15px; }
        .section-title { font-size: 20px; font-weight: 800; }

        /* --- 2 Columns Grid Layout --- */
        .cards-grid { padding: 0 15px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .friend-card { border: 1px solid #e4e6eb; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; justify-content: space-between; }
        .card-avatar { width: 100%; height: 160px; object-fit: cover; display: block; background-color: #f0f2f5; }
        .card-info { padding: 10px; display: flex; flex-direction: column; flex-grow: 1; justify-content: space-between; }
        .card-name { font-size: 15px; font-weight: 700; color: #050505; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .card-subtitle { font-size: 12px; color: #65676b; margin-top: 2px; margin-bottom: 8px; }
        .card-actions { display: flex; flex-direction: column; gap: 6px; width: 100%; }

        /* Buttons Styling */
        .btn-green { background-color: #2e7d32; color: white; border: none; padding: 8px 0; border-radius: 6px; font-weight: 600; font-size: 13px; cursor: pointer; width: 100%; text-align: center; text-decoration: none; display: block; }
        .btn-green:hover { background-color: #1b5e20; }
        
        .btn-gray { background-color: #e4e6eb; color: #050505; border: none; padding: 8px 0; border-radius: 6px; font-weight: 600; font-size: 13px; cursor: pointer; width: 100%; text-align: center; }
        .btn-gray:hover { background-color: #d8dadf; }

        /* Toast Message */
        #toast {
            visibility: hidden;
            min-width: 220px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 4px;
            padding: 10px;
            position: fixed;
            z-index: 1000;
            left: 50%;
            bottom: 30px;
            transform: translateX(-50%);
            font-size: 14px;
        }
        #toast.show {
            visibility: visible;
            animation: fadein 0.5s, fadeout 0.5s 1.5s;
        }
        @keyframes fadein { from { bottom: 0; opacity: 0; } to { bottom: 30px; opacity: 1; } }
        @keyframes fadeout { from { bottom: 30px; opacity: 1; } to { bottom: 0; opacity: 0; } }
    </style>
</head>
<body>
    <div class="phone-container">
        <!-- Header -->
        <div class="header">
            <div class="logo-area">
                <button class="menu-btn" onclick="window.location.href='SettingServlet'"><i class="fa-solid fa-bars"></i></button>
                <div class="logo" onclick="window.location.href='HomeServlet'">connect hub</div>
            </div>
            <button class="icon-btn" onclick="window.location.href='SearchServlet'"><i class="fa-solid fa-magnifying-glass"></i></button>
        </div>

        <!-- Navigation Tabs -->
         <div class="nav-tabs">
            <div class="nav-tab" onclick="window.location.href='HomeServlet'"><i class="fa-solid fa-house"></i></div>
            <div class="nav-tab" onclick="window.location.href='ViewProfileServlet?user_id=<%= session.getAttribute("user_id") %>'"><i class="fa-solid fa-circle-user"></i></div>
            <div class="nav-tab active" onclick="window.location.href='FriendServlet'" style="position: relative;">
                <i class="fa-solid fa-user-group"></i>
                <% 
                    Boolean hasPending = (Boolean) request.getAttribute("hasPendingRequests");
                    if(hasPending != null && hasPending) { 
                %>
                    <span class="red-dot"></span>
                <% } %>
            </div>
            <div class="nav-tab" onclick="window.location.href='NotificationServlet'" style="position: relative;">
                <i class="fa-solid fa-bell"></i>
                <% if(unreadCount > 0) { %>
                    <span class="red-dot"></span>
                <% } %>
            </div>
            <div class="nav-tab" onclick="window.location.href='MessageServlet'" style="position: relative;">
                <i class="fa-solid fa-comment-dots"></i>
                <% 
                    Boolean hasMsgs = (Boolean) request.getAttribute("hasUnreadMessages");
                    if(hasMsgs != null && hasMsgs) { 
                %>
                    <span class="red-dot"></span>
                <% } %>
            </div>
        </div>

        <!-- Sub Filters -->
        <div class="sub-filters">
            <div id="btnSuggestions" class="filter-chip active" onclick="switchTab('suggestions')">Suggestions</div>
            <div id="btnYourFriends" class="filter-chip" onclick="switchTab('yourFriends')">Your friends</div>
            <div id="btnRequests" class="filter-chip" onclick="switchTab('requests')">Requests</div>
        </div>

        <div>
            <!-- Tab 1: Suggestions Section -->
            <div id="tabSuggestions" class="tab-content active">
                <div class="section-header">
                    <div class="section-title">People you may know</div>
                </div>
                <div class="cards-grid">
                    <% 
                        if (suggestions != null && !suggestions.isEmpty()) {
                            for (Map<String, Object> sug : suggestions) {
                                int uId = (Integer) sug.get("user_id");
                                String uName = (String) sug.get("name");
                                if (uName == null || uName.trim().isEmpty()) {
                                    uName = "User " + uId;
                                }
                                String uBgColor = (String) sug.get("bg_color");
                                if (uBgColor == null || uBgColor.trim().isEmpty()) { uBgColor = "#ffffff"; }
                    %>
                    <div class="friend-card" style="background-color: <%= uBgColor %>;">
                        <img src="ImageServlet?user_id=<%= uId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="card-avatar" alt="Avatar" onclick="window.location.href='ProfileServlet?user_id=<%= uId %>'">
                        <div class="card-info">
                            <div>
                                <div class="card-name"><%= uName %></div>
                                <div class="card-subtitle">People you may know</div>
                            </div>
                            <div class="card-actions" onclick="event.stopPropagation()">
                                <button class="btn-green" onclick="sendFriendRequest(<%= uId %>, this)">Add</button>
                                <button class="btn-gray" onclick="removeSuggestion(this)">Remove</button>
                            </div>
                        </div>
                    </div>
                    <% 
                            }
                        } else { 
                    %>
                        <div style="grid-column: span 2; text-align: center; color: #65676b; padding: 30px;">No suggested friend yet!</div>
                    <% } %>
                </div>
            </div>

            <!-- Tab 2: Your Friends Section -->
            <div id="tabYourFriends" class="tab-content">
                <div class="section-header">
                    <div class="section-title">Your Friends</div>
                </div>
                <div class="cards-grid">
                    <% 
                        if (myFriends != null && !myFriends.isEmpty()) {
                            for (Map<String, Object> friend : myFriends) {
                                int fId = (Integer) friend.get("user_id");
                                String fName = (String) friend.get("name");
                                if (fName == null) fName = "User " + fId;
                                String fBgColor = (String) friend.get("bg_color");
                                if (fBgColor == null || fBgColor.trim().isEmpty()) { fBgColor = "#ffffff"; }
                    %>
                    <div class="friend-card" style="background-color: <%= fBgColor %>;">
                        <img src="ImageServlet?user_id=<%= fId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="card-avatar" alt="Friend"onclick="window.location.href='ProfileServlet?user_id=<%= fId %>'">
                        <div class="card-info">
                            <div>
                                <div class="card-name"><%= fName %></div>
                                <div class="card-subtitle">Connected</div>
                            </div>
                            <div class="card-actions" onclick="event.stopPropagation()">
                                <a href="MessageServlet?receiver_id=<%= fId %>" class="btn-green">Message</a>
                                <button class="btn-gray" onclick="removeFriend(<%= fId %>, this)">Unfriend</button>
                            </div>
                        </div>
                    </div>
                    <% 
                            } 
                        } else { 
                    %>
                        <div style="grid-column: span 2; text-align: center; color: #65676b; padding: 30px;">Not found Friends</div>
                    <% } %>
                </div>
            </div>

            <!-- Tab 3: Friend Requests Section (Delete ခလုတ် ဖြုတ်ပြီးသား) -->
            <div id="tabRequests" class="tab-content">
                <div class="section-header">
                    <div class="section-title">Friend Requests</div>
                </div>
                <div class="cards-grid">
                    <% 
                        if (friendRequests != null && !friendRequests.isEmpty()) {
                            for (Map<String, Object> req : friendRequests) {
                                int senderId = (Integer) req.get("user_id");
                                String sName = (String) req.get("name");
                                if (sName == null) sName = "User " + senderId;
                                String sBgColor = (String) req.get("bg_color");
                                if (sBgColor == null || sBgColor.trim().isEmpty()) { sBgColor = "#ffffff"; }
                    %>
                    <div class="friend-card" id="req-<%= senderId %>" style="background-color: <%= sBgColor %>;">
                        <img src="ImageServlet?user_id=<%= senderId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="card-avatar" alt="Request Avatar"onclick="window.location.href='ProfileServlet?user_id=<%= senderId %>'">
                        <div class="card-info">
                            <div>
                                <div class="card-name"><%= sName %></div>
                                <div class="card-subtitle">Wants to be your friend</div>
                            </div>
                            <div class="card-actions" onclick="event.stopPropagation()">
                                <button class="btn-green" onclick="acceptRequest(<%= senderId %>, this)">Confirm</button>
                            </div>
                        </div>
                    </div>
                    <% 
                            }
                        } else {
                    %>
                        <div style="grid-column: span 2; text-align: center; color: #65676b; padding: 30px;">No Friend Requests</div>
                    <% } %>
                </div>
            </div>
        </div>
    </div>

    <div id="toast"></div>

    <script>
        function switchTab(tabName) {
            const btnSuggestions = document.getElementById('btnSuggestions');
            const btnYourFriends = document.getElementById('btnYourFriends');
            const btnRequests = document.getElementById('btnRequests');
            
            const tabSuggestions = document.getElementById('tabSuggestions');
            const tabYourFriends = document.getElementById('tabYourFriends');
            const tabRequests = document.getElementById('tabRequests');

            btnSuggestions.classList.remove('active');
            btnYourFriends.classList.remove('active');
            btnRequests.classList.remove('active');
            
            tabSuggestions.classList.remove('active');
            tabYourFriends.classList.remove('active');
            tabRequests.classList.remove('active');

            if (tabName === 'suggestions') {
                btnSuggestions.classList.add('active');
                tabSuggestions.classList.add('active');
            } else if (tabName === 'yourFriends') {
                btnYourFriends.classList.add('active');
                tabYourFriends.classList.add('active');
            } else if (tabName === 'requests') {
                btnRequests.classList.add('active');
                tabRequests.classList.add('active');
            }
        }

        window.addEventListener('DOMContentLoaded', () => {
            if (window.location.hash && window.location.hash.startsWith('#req-')) {
                switchTab('requests');
                setTimeout(() => {
                    const targetElement = document.querySelector(window.location.hash);
                    if (targetElement) {
                        targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        targetElement.style.border = '2px solid #2e7d32';
                    }
                }, 200);
            }
        });

        function sendFriendRequest(userId, btn) {
            fetch('FriendServlet?action=send&receiverId=' + userId, { method: 'POST' })
            .then(response => response.text())
            .then(data => {
                showToast('Send Friend Request');
                btn.innerText = 'Request Sent';
                btn.style.backgroundColor = '#81c784';
                btn.disabled = true;
            });
        }

        function acceptRequest(senderId, btn) {
            fetch('FriendServlet?action=accept&senderId=' + senderId, { method: 'POST' })
            .then(response => response.text())
            .then(data => {
                showToast('Confirm Friend Request');
                setTimeout(() => { location.reload(); }, 500);
            });
        }

        function removeSuggestion(btn) {
            const item = btn.closest('.friend-card');
            item.style.transition = 'opacity 0.3s';
            item.style.opacity = '0';
            setTimeout(() => item.remove(), 300);
            showToast('Friend Suggestions');
        }

        function removeFriend(friendId, btn) {
            if (confirm('Are You Sure?')) {
                fetch('FriendServlet?action=remove&friendId=' + friendId, { method: 'POST' })
                .then(response => response.text())
                .then(data => {
                    const item = btn.closest('.friend-card');
                    item.style.transition = 'opacity 0.3s';
                    item.style.opacity = '0';
                    setTimeout(() => item.remove(), 300);
                    showToast('Remove Friend lists.');
                });
            }
        }

        function showToast(message) {
            const toast = document.getElementById('toast');
            toast.innerText = message;
            toast.classList.add('show');
            setTimeout(() => { toast.classList.remove('show'); }, 2000);
        }
    </script>
</body>
</html>