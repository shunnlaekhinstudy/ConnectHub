<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String userName = (String) session.getAttribute("userName");
    Integer userId = (Integer) session.getAttribute("user_id");
    if(userName == null || userId == null) {
        response.sendRedirect("index.jsp");
        return;
    }
    String savedBg = (String) session.getAttribute("appBgColor");
    if(savedBg == null) savedBg = "#ffffff";
    // Database မှ ရလာသော တန်ဖိုးများ null ဖြစ်နေလျှင် Error မတက်စေဘဲ ကွက်လပ်ဖြစ်စေရန် စစ်ဆေးခြင်း
    String bio = request.getAttribute("bio") != null ? (String) request.getAttribute("bio") : "";
    String gender = request.getAttribute("gender") != null ? (String) request.getAttribute("gender") : "";
    String birthdate = request.getAttribute("birthdate") != null ? request.getAttribute("birthdate").toString() : "";
    String occupation = request.getAttribute("occupation") != null ? (String) request.getAttribute("occupation") : "";
    String address = request.getAttribute("address") != null ? (String) request.getAttribute("address") : "";
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Connect Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css">
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        body { background-color: #f0f2f5; color: #050505; display: flex; justify-content: center; min-height: 100vh; }
        :root { --app-bg: <%= savedBg %>; }
        .phone-container { width: 100%; max-width: 480px; background: var(--app-bg) !important; background-attachment: fixed; min-height: 100vh; box-shadow: 0 0 15px rgba(0,0,0,0.1); position: relative; display: flex; flex-direction: column; padding-bottom: 30px; }
        
        .profile-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 15px; var(--app-bg) !important; color: #2e7d32; border-bottom: 1px solid #e4e6eb; position: sticky; top: 0; z-index: 100; }
        .back-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: #2e7d32; }
        .header-title { font-size: 20px; font-weight: 800;color: #2e7d32; }
        .save-btn { background-color: #2e7d32; color: #fff; border: none; padding: 6px 16px; border-radius: 6px; font-weight: 600; font-size: 14px; cursor: pointer; }

        .form-container { padding: 20px 24px; display: flex; flex-direction: column; gap: 18px; }
        
        /* Cover Photo Section */
        .cover-upload-section { display: flex; flex-direction: column; align-items: center; text-align: center; margin-bottom: 10px; }
        .cover-img-wrapper { width: 100%; height: 150px; border-radius: 8px; overflow: hidden; border: 1px solid #ccd0d5; position: relative; background: #e4e6eb; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .cover-img { width: 100%; height: 100%; object-fit: cover; }
        
        /* Profile Photo Section */
        .image-upload-section { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; margin-top: -80px; z-index: 10; }
        .profile-img-wrapper { width: 100px; height: 100px; border-radius: 30%; overflow: hidden; border: 3px solid #ffffff; box-shadow: 0 2px 8px rgba(0,0,0,0.15); position: relative; background: #e4e6eb; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .profile-img { width: 100%; height: 100%; object-fit: cover; }
        .upload-text { font-size: 13px; color: #2e7d32; font-weight: 600; cursor: pointer; margin-top: 5px; }

        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group label { font-size: 14px; font-weight: 600; color: #4b4f56; padding-left: 2px; }
        .form-control { width: 100%; padding: 12px 14px; border: 1px solid #ccd0d5; border-radius: 8px; font-size: 14px; outline: none; background-color: #fff; color: #050505; }
        .form-control:focus { border-color: #2e7d32; box-shadow: 0 0 0 2px rgba(46, 125, 50, 0.15); }
        textarea.form-control { resize: vertical; min-height: 80px; }

        /* Cropper Modal */
        #cropModal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.85); z-index: 1000; justify-content: center; align-items: center; flex-direction: column; }
        .modal-content { background: #fff; width: 90%; max-width: 400px; border-radius: 12px; padding: 20px; text-align: center; display: flex; flex-direction: column; align-items: center; }
        .modal-title { font-size: 16px; font-weight: 700; margin-bottom: 15px; color: #333; }
        .img-container { width: 100%; max-height: 300px; margin-bottom: 15px; background: #f8f9fa; }
        .img-container img { max-width: 100%; display: block; }
        .modal-actions { display: flex; gap: 10px; width: 100%; justify-content: space-between; }
        .modal-btn { flex: 1; padding: 10px; border-radius: 6px; font-weight: 600; font-size: 14px; cursor: pointer; border: none; }
        .btn-cancel { background-color: #e4e6eb; color: #333; }
        .btn-rotate { background-color: #4a4f54; color: #fff; }
        .btn-done { background-color: #2e7d32; color: #fff; }
    </style>
</head>
<body>
    <div class="phone-container">
        <form action="ProfileServlet" method="POST" enctype="multipart/form-data">
            <div class="profile-header">
                <button type="button" class="back-btn" onclick="window.location.href='ViewProfileServlet'" ><i class="fa-solid fa-arrow-left"></i></button>
                <div class="header-title">Edit Profile</div>
                <button type="submit" class="save-btn">Save</button>
            </div>

            <div class="form-container">
                <!-- Cover Photo Upload (ImageServlet ဖြင့် type=cover ခေါ်ယူခြင်း) -->
                <div class="cover-upload-section">
                    <div class="cover-img-wrapper" onclick="document.getElementById('coverInput').click();">
                        <img id="coverPreview" src="ImageServlet?user_id=<%= userId %>&type=cover" onerror="this.src='images/default-cover.png'" class="cover-img" alt="Cover Preview">
                    </div>
                      <input type="file" name="cover_image" id="coverInput" accept="image/*" style="display: none;" onchange="initCropper(event, 'cover')">
                </div>

                <!-- Profile Photo Upload (ImageServlet ဖြင့် type=profile ခေါ်ယူခြင်း) -->
                <div class="image-upload-section">
                    <div class="profile-img-wrapper" onclick="document.getElementById('profileInput').click();">
                        <img id="profilePreview" src="ImageServlet?user_id=<%= userId %>&type=profile" onerror="this.src='images/default-avatar.png'" class="profile-img" alt="Profile Preview">
                    </div>
                    <span class="upload-text" onclick="document.getElementById('profileInput').click();">Change Profile Picture</span>
                    <input type="file" name="profile_image" id="profileInput" accept="image/*" style="display: none;" onchange="initCropper(event, 'profile')">
                </div>

                <div class="form-group">
                    <label>Bio</label>
                    <textarea name="bio" class="form-control" placeholder="Write something about yourself..."><%= bio %></textarea>
                </div>

                <div class="form-group">
                    <label>Gender</label>
                    <select name="gender" class="form-control">
                        <option value="">Select Gender</option>
                        <option value="Male" <%= "Male".equals(gender) ? "selected" : "" %>>Male</option>
                        <option value="Female" <%= "Female".equals(gender) ? "selected" : "" %>>Female</option>
                        <option value="Other" <%= "Other".equals(gender) ? "selected" : "" %>>Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Birthdate</label>
                    <input type="date" name="birthdate" class="form-control" value="<%= birthdate %>">
                </div>

                <div class="form-group">
                    <label>Occupation</label>
                    <input type="text" name="occupation" class="form-control" placeholder="e.g. Software Engineer" value="<%= occupation %>">
                </div>

                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="address" class="form-control" placeholder="e.g. Yangon, Myanmar" value="<%= address %>">
                </div>
            </div>
        </form>
    </div>

    <!-- Cropper Modal -->
    <div id="cropModal">
        <div class="modal-content">
            <div class="modal-title" id="modalTitle">Crop Image</div>
            <div class="img-container">
                <img id="imageToCrop" src="" alt="Source">
            </div>
            <div class="modal-actions" style="margin-bottom: 15px;">
                <button type="button" class="modal-btn btn-rotate" onclick="cropper.rotate(90)"><i class="fa-solid fa-rotate-right"></i> Rotate</button>
            </div>
            <div class="modal-actions">
                <button type="button" class="modal-btn btn-cancel" onclick="closeCropModal()">Cancel</button>
                <button type="button" class="modal-btn btn-done" onclick="getCroppedImage()">Done</button>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>
    <script>
        let cropper;
        let currentType = '';
        const imageToCrop = document.getElementById('imageToCrop');

        function initCropper(event, type) {
            currentType = type;
            const files = event.target.files;
            if (files && files.length > 0) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imageToCrop.src = e.target.result;
                    document.getElementById('modalTitle').innerText = type === 'profile' ? 'Crop Profile Picture' : 'Crop Cover Photo';
                    document.getElementById('cropModal').style.display = 'flex';
                    if (cropper) { cropper.destroy(); }
                    
                    cropper = new Cropper(imageToCrop, {
                        aspectRatio: type === 'profile' ? 1 : 16 / 9,
                        viewMode: 1,
                        dragMode: 'move',
                        autoCropArea: 1,
                        restore: false,
                        guides: false,
                        center: true,
                        highlight: false,
                        cropBoxMovable: true,
                        cropBoxResizable: true,
                    });
                }
                reader.readAsDataURL(files[0]);
            }
        }

        function closeCropModal() {
            document.getElementById('cropModal').style.display = 'none';
            if(currentType === 'profile') document.getElementById('profileInput').value = '';
            else document.getElementById('coverInput').value = '';
            if (cropper) { cropper.destroy(); }
        }

        function getCroppedImage() {
            const options = currentType === 'profile' ? { width: 300, height: 300 } : { width: 800, height: 450 };
            const canvas = cropper.getCroppedCanvas(options);
            
            if (canvas) {
                const croppedImageUrl = canvas.toDataURL('image/jpeg');
                if(currentType === 'profile') {
                    document.getElementById('profilePreview').src = croppedImageUrl;
                } else {
                    document.getElementById('coverPreview').src = croppedImageUrl;
                }

                canvas.toBlob(function(blob) {
                    const file = new File([blob], currentType + ".jpg", { type: "image/jpeg" });
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    if(currentType === 'profile') {
                        document.getElementById('profileInput').files = dataTransfer.files;
                    } else {
                        document.getElementById('coverInput').files = dataTransfer.files;
                    }
                }, 'image/jpeg');
            }
            document.getElementById('cropModal').style.display = 'none';
            if (cropper) { cropper.destroy(); }
        }
    </script>
</body>
</html>