<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ConnectHub</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: Arial, sans-serif; }
        body { background-color: #f0f2f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .login-container { background: white;color: #2e7d32; padding: 35px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        .login-container h2 { text-align: center; margin-bottom: 24px; color: #1877f2; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; color: #555; font-size: 14px; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ccd0d5; border-radius: 6px; font-size: 14px; }
        .form-group input:focus { border-color: #2e7d32; outline: none; box-shadow: 0 0 4px rgb(0, 128, 0); }
        .btn { width: 100%; padding: 12px; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer; background:#2e7d32;color: white; margin-top: 10px; }
        .btn:hover { background:#2e7d32; }
        .error-msg { color: red; text-align: center; font-size: 14px; margin-bottom: 15px; }
        .success-msg { color: #2e7d32; text-align: center; font-size: 14px; margin-bottom: 15px; }
        
        .links-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            font-size: 14px;
        }
        .links-container a { color: #2e7d32; text-decoration: none; }
        .links-container a:hover { text-decoration: underline; }
        
        .signup-section {
            text-align: center;
            margin-top: 25px;
            padding-top: 15px;
            border-top: 1px solid #e4e6eb;
            font-size: 14px;
            color: #666;
        }
         
        .signup-section a { color: #2e7d32; text-decoration: none; font-weight: bold; }
        .signup-section a:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <div class="login-container">
        <h2 style="color: #2e7d32;">Login to ConnectHub</h2>
        
        <!-- Signup အောင်မြင်ပြီးပါက ပြရန် -->
        <% 
            String signup = request.getParameter("signup");
            if(signup != null && signup.equals("success")) {
        %>
            <div class="success-msg">registration Success! Please Log In</div>
        <% } %>

        <!-- Login Fail ဖြစ်ပါက Error ပြရန် -->
        <% 
            String error = request.getParameter("error");
            if(error != null) {
        %>
            <div class="error-msg">Wrong Email or Password</div>
        <% } %>
        
        <form action="LoginServlet" method="POST">
            <div class="form-group">
                <label>Gmail</label>
                <input type="email" name="email" placeholder="example@gmail.com" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter Password" required>
            </div>

            <!-- Forgot Password လင့်ခ်ကို ညာဘက်တွင် ထည့်သွင်းခြင်း -->
            <div class="links-container">
                <span></span> <!-- ဘယ်ဘက်ကို ကွက်လပ်ထားရန် -->
                <a href="forgot-password.jsp">Forgot Password</a>
            </div>

            <button type="submit" class="btn">Log In</button>
        </form>

        <!-- အောက်ခြေတွင် Sign Up လင့်ခ်ထည့်သွင်းခြင်း -->
        <div class="signup-section">
            Have no account?<a href="signup.jsp">create new account</a>
        </div>
    </div>
    

</body>
</html>