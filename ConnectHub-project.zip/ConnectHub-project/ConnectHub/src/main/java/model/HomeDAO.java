package model;

import java.sql.*;
import java.util.*;
import model.DBConnection;

public class HomeDAO {

    public List<Map<String, Object>> getAllFeedPosts(int currentUserId) {
        List<Map<String, Object>> feedPostsList = new ArrayList<>();
        
        String sql = "SELECT p.post_id, p.user_id, p.post_title, p.text, p.bg_style, p.created_at, u.name AS author_name " +
                     "FROM posts p JOIN users u ON p.user_id = u.user_id " +
                     "ORDER BY p.created_at DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> post = new HashMap<>();
                int postId = rs.getInt("post_id");
                
                post.put("postId", postId);
                post.put("userId", rs.getInt("user_id"));
                post.put("username", rs.getString("author_name"));
                post.put("postTitle", rs.getString("post_title"));
                post.put("text", rs.getString("text"));
                post.put("bgStyle", rs.getString("bg_style"));
                post.put("createdAt", rs.getString("created_at"));

                // ပို့စ်ပုံများ (Images) ကို ဆွဲထုတ်ရန်
                List<String> images = new ArrayList<>();
                try (PreparedStatement imgStmt = conn.prepareStatement("SELECT image_name FROM post_images WHERE post_id = ?")) {
                    imgStmt.setInt(1, postId);
                    try (ResultSet imgRs = imgStmt.executeQuery()) {
                        while (imgRs.next()) {
                            images.add(imgRs.getString("image_name"));
                        }
                    }
                }
                post.put("images", images);

                // Like အရေအတွက်နှင့် လက်ရှိ User Like ထားခြင်း ရှိမရှိ စစ်ဆေးရန်
                int likeCount = 0;
                boolean isLikedByMe = false;
                try (PreparedStatement likeStmt = conn.prepareStatement("SELECT user_id FROM likes WHERE post_id = ?")) {
                    likeStmt.setInt(1, postId);
                    try (ResultSet likeRs = likeStmt.executeQuery()) {
                        while (likeRs.next()) {
                            likeCount++;
                            if (likeRs.getInt("user_id") == currentUserId) {
                                isLikedByMe = true;
                            }
                        }
                    }
                }
                post.put("likeCount", likeCount);
                post.put("isLikedByMe", isLikedByMe);

                // ကောမန့်များ (Comments နှင့် Replies) ကို ဆွဲထုတ်ရန်
                List<Map<String, Object>> commentsList = new ArrayList<>();
                String commSql = "SELECT c.comment_id, c.user_id, c.comment_text, c.parent_id, c.created_at, u.name AS comment_author " +
                        "FROM comments c JOIN users u ON c.user_id = u.user_id " +
                        "WHERE c.post_id = ? ORDER BY c.comment_id DESC";
                try (PreparedStatement commStmt = conn.prepareStatement(commSql)) {
                    commStmt.setInt(1, postId);
                    try (ResultSet commRs = commStmt.executeQuery()) {
                        while (commRs.next()) {
                            Map<String, Object> comment = new HashMap<>();
                            comment.put("commentId", commRs.getInt("comment_id"));
                            comment.put("userId", commRs.getInt("user_id")); // <-- အစက်သုံးစက်ပေါ်ရန် ဤနေရာတွင် userId ထည့်ပေးထားပါသည်[cite: 3]
                            comment.put("username", commRs.getString("comment_author"));
                            comment.put("commentText", commRs.getString("comment_text"));
                            comment.put("createdAt", commRs.getString("created_at"));
                            comment.put("parentId", commRs.getObject("parent_id") != null ? commRs.getInt("parent_id") : null);
                            commentsList.add(comment);
                        }
                    }
                }
                post.put("commentCount", commentsList.size());
                post.put("commentsList", commentsList);

                feedPostsList.add(post);
            }

        } catch (Exception e) {
            System.out.println("--- HOME DAO ERROR ---");
            e.printStackTrace();
        }
        
        return feedPostsList;
    }

    public int addComment(int postId, int userId, String commentText) {
        return addComment(postId, userId, commentText, null);
    }

    public int addComment(int postId, int userId, String commentText, Integer parentId) {
        int generatedCommentId = -1;
        String sql = "INSERT INTO comments (post_id, user_id, comment_text, parent_id) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, userId);
            pstmt.setString(3, commentText);
            
            if (parentId != null) {
                pstmt.setInt(4, parentId);
            } else {
                pstmt.setNull(4, java.sql.Types.INTEGER);
            }
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedCommentId = rs.getInt(1);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return generatedCommentId;
    }

    public boolean updateComment(int commentId, int userId, String newText) {
        String sql = "UPDATE comments SET comment_text = ? WHERE comment_id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newText);
            pstmt.setInt(2, commentId);
            pstmt.setInt(3, userId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public int getPostOwnerId(int postId) {
        int ownerId = 0;
        String sql = "SELECT user_id FROM posts WHERE post_id = ?"; // သို့မဟုတ် post_id
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, postId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ownerId = rs.getInt("user_id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ownerId;
    }
    public boolean deleteComment(int commentId, int userId) {
        String sql = "DELETE FROM comments WHERE comment_id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, commentId);
            pstmt.setInt(2, userId);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}