package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.DBConnection;

public class ImageDAO {

    public byte[] getImageData(int userId, String type) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        byte[] imgData = null;

        try {
            conn = DBConnection.getConnection();
            
            // type ပေါ်မူတည်၍ Database မှ Column အမည်ကို ရွေးချယ်ခြင်း
            String columnName = "profile_image"; // default
            if ("cover".equalsIgnoreCase(type)) {
                columnName = "cover_image";
            }

            String sql = "SELECT " + columnName + " FROM profiles WHERE user_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                imgData = rs.getBytes(columnName);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) {}
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) {}
            try { if (conn != null) conn.close(); } catch (SQLException e) {}
        }

        return imgData;
    }
}