package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotificationDAO {

    // Notification အသစ်ထည့်ရန် (Like / Comment အတွက်)[cite: 4]
    public boolean addNotification(int userId, int actorId, int referenceId, String type) {
        String sql = "INSERT INTO notifications (user_id, actor_id, reference_id, type, is_read) VALUES (?, ?, ?, ?, 0)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, userId);        
            ps.setInt(2, actorId);      
            ps.setInt(3, referenceId);  
            ps.setString(4, type);      
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // မဖတ်ရသေးသော နိုတစ်အရေအတွက်ကို ရယူရန်[cite: 4]
    public int getUnreadNotificationCount(int userId) {
        int count = 0;
        String query = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0 AND type IN ('friend_request', 'friend_accept', 'like', 'comment')";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    // အသုံးပြုသူအတွက် နိုတစ်စာရင်းများကို Map စာရင်းအနေဖြင့် ရယူရန်[cite: 4]
    public List<Map<String, Object>> getNotificationsByUserId(int userId) {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT n.id, n.user_id, n.actor_id, n.type, n.reference_id, n.is_read, n.created_at, u.name AS actor_name " +
                     "FROM notifications n " +
                     "LEFT JOIN users u ON n.actor_id = u.user_id " +
                     "WHERE n.user_id = ? AND n.type IN ('friend_request', 'friend_accept', 'like', 'comment') " +
                     "ORDER BY n.created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> map = new HashMap<>();
                    int notifId = rs.getInt("id");
                    int actorId = rs.getInt("actor_id");
                    String type = rs.getString("type");
                    int referenceId = rs.getInt("reference_id");
                    Timestamp createdAt = rs.getTimestamp("created_at");
                    
                    map.put("id", notifId);
                    map.put("userId", rs.getInt("user_id"));
                    map.put("actorId", actorId);
                    map.put("type", type);
                    map.put("referenceId", referenceId);
                    map.put("isRead", rs.getInt("is_read"));
                    map.put("createdAt", createdAt);
                    
                    String actorName = rs.getString("actor_name");
                    if (actorName == null || actorName.trim().isEmpty()) {
                        actorName = "User " + actorId;
                    }
                    map.put("actorName", actorName);
                    
                    // noti.jsp အတွက် လိုအပ်သော တန်ဖိုးများကို တွက်ချက်ထည့်သွင်းခြင်း[cite: 3, 4]
                    map.put("actorAvatar", "ImageServlet?user_id=" + actorId + "&type=profile");
                    
                    String notifText = "";
                    String iconClass = "";
                    String targetUrl = "#";
                    
                    if ("like".equals(type)) {
                        notifText = "<b>" + actorName + "</b> has liked your post.";
                        iconClass = "fa-solid fa-heart";
                        targetUrl = "HomeServlet#post-" + referenceId;
                    } else if ("comment".equals(type)) {
                        notifText = "<b>" + actorName + "</b> has commented on your post.";
                        iconClass = "fa-solid fa-comment";
                        targetUrl = "HomeServlet#post-" + referenceId;
                    } else if ("friend_request".equals(type)) {
                        notifText = "<b>" + actorName + "</b> sent you a friend request.";
                        iconClass = "fa-solid fa-user-plus";
                        targetUrl = "FriendServlet?action=requests#req-" + actorId;
                    } else if ("friend_accept".equals(type)) {
                        notifText = "<b>" + actorName + "</b> accepted your friend request.";
                        iconClass = "fa-solid fa-user-check";
                        targetUrl = "FriendServlet?action=list";
                    }
                    
                    map.put("notifText", notifText);
                    map.put("iconClass", iconClass);
                    map.put("targetUrl", targetUrl);
                    
                    String formattedTime = (createdAt != null) ? createdAt.toString() : "Just now";
                    map.put("formattedTime", formattedTime);
                    
                    list.add(map);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // နိုတစ်ကို ဖျက်ရန်[cite: 4]
    public boolean deleteNotification(int notifId, int userId) {
        String sql = "DELETE FROM notifications WHERE id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, notifId);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // နိုတစ်ကို ဖတ်ပြီးသားဖြစ်အောင် (is_read = 1) ပြောင်းရန်[cite: 4]
    public void markAsRead(int notifId, int userId) {
        String sql = "UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, notifId);
            ps.setInt(2, userId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // actor_id ဖြင့် အသုံးပြုသူအမည်ကို ရယူရန်[cite: 4]
    public String getUserNameById(int userId) {
        String name = "User " + userId;
        String sql = "SELECT name FROM users WHERE user_id = ?"; 
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String dbName = rs.getString("name");
                    if (dbName != null && !dbName.trim().isEmpty()) {
                        name = dbName;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return name;
    }
}
