package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InteractDAO {

    // ၁။ Comment အသစ် (သို့မဟုတ်) Reply ထည့်ခြင်း (Generated Comment ID ကို ပြန်ပေးသည်)
    public int addComment(int postId, int userId, String commentText, Integer parentId) {
        String sql;
        boolean hasParent = (parentId != null && parentId > 0);
        
        if (hasParent) {
            sql = "INSERT INTO comments (post_id, user_id, comment_text, parent_id) VALUES (?, ?, ?, ?)";
        } else {
            sql = "INSERT INTO comments (post_id, user_id, comment_text) VALUES (?, ?, ?)";
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, userId);
            pstmt.setString(3, commentText);
            
            if (hasParent) {
                pstmt.setInt(4, parentId);
            }
            
            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // ၂။ Comment ပြင်ဆင်ခြင်း
    public boolean updateComment(int commentId, int userId, String newText) {
        String sql = "UPDATE comments SET comment_text = ? WHERE comment_id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, newText);
            pstmt.setInt(2, commentId);
            pstmt.setInt(3, userId);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ၃။ Comment ဖျက်ခြင်း
    public boolean deleteComment(int commentId, int userId) {
        String sql = "DELETE FROM comments WHERE comment_id = ? AND user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, commentId);
            pstmt.setInt(2, userId);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ၄။ Like ပြုလုပ်ခြင်း သို့မဟုတ် Like ဖြုတ်ခြင်း
    public void toggleLike(int postId, int userId) {
        String checkSql = "SELECT * FROM likes WHERE post_id = ? AND user_id = ?";
        String deleteSql = "DELETE FROM likes WHERE post_id = ? AND user_id = ?";
        String insertSql = "INSERT INTO likes (post_id, user_id) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            
            checkStmt.setInt(1, postId);
            checkStmt.setInt(2, userId);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    try (PreparedStatement delStmt = conn.prepareStatement(deleteSql)) {
                        delStmt.setInt(1, postId);
                        delStmt.setInt(2, userId);
                        delStmt.executeUpdate();
                    }
                } else {
                    try (PreparedStatement insStmt = conn.prepareStatement(insertSql)) {
                        insStmt.setInt(1, postId);
                        insStmt.setInt(2, userId);
                        insStmt.executeUpdate();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ၅။ Post တစ်ခုကို Like လုပ်ထားသော User များ၏ ID နှင့် Username ကို Map ဖြင့် ယူခြင်း
    public List<Map<String, Object>> getLikedUsers(int postId) {
        List<Map<String, Object>> likedUsers = new ArrayList<>();
        // အကယ်၍ column နာမည် အတိအကျမသိရရင် user_id နဲ့ name သို့မဟုတ် username ကို AS သုံးပြီး ေခါ်ပါ
        String sql = "SELECT u.user_id, u.name FROM likes l " +
                     "JOIN users u ON l.user_id = u.user_id " +
                     "WHERE l.post_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setInt(1, postId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> user = new HashMap<>();
                    // Column များကို နာမည်အပြင် Index (၁ နဲ့ ၂) ဖြင့်ပါ တွဲဖက်ဖမ်းယူခြင်း
                    int id = 0;
                    String name = "";
                    
                    try {
                        id = rs.getInt("user_id");
                    } catch (Exception e) {
                        id = rs.getInt(1);
                    }
                    
                    try {
                        name = rs.getString("name");
                    } catch (Exception e) {
                        try {
                            name = rs.getString("username");
                        } catch (Exception ex) {
                            name = rs.getString(2);
                        }
                    }
                    
                    user.put("user_id", id);
                    user.put("name", name);
                    likedUsers.add(user);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return likedUsers;
    
    }
}