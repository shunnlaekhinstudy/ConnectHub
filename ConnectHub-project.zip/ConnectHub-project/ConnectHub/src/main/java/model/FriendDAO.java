package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FriendDAO {

	public boolean sendRequest(int senderId, int receiverId) {
	    // ပထမဦးစွာ ဤသူငယ်ချင်းတောင်းဆိုမှု (Friend Request) သို့မဟုတ် ဆက်ဆံရေး ရှိပြီးသားလား စစ်ဆေးခြင်း
	    String checkQuery = "SELECT status FROM friendships WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";
	    String insertQuery = "INSERT INTO friendships (sender_id, receiver_id, status) VALUES (?, ?, 'pending')";
	    String updateQuery = "UPDATE friendships SET status = 'pending', sender_id = ?, receiver_id = ? WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";
	    String notifQuery = "INSERT INTO notifications (user_id, actor_id, type, reference_id, is_read) VALUES (?, ?, 'friend_request', 0, 0)";
	    
	    try (Connection conn = DBConnection.getConnection()) {
	        conn.setAutoCommit(false);
	        
	        boolean exists = false;
	        try (PreparedStatement psCheck = conn.prepareStatement(checkQuery)) {
	            psCheck.setInt(1, senderId);
	            psCheck.setInt(2, receiverId);
	            psCheck.setInt(3, receiverId);
	            psCheck.setInt(4, senderId);
	            try (ResultSet rs = psCheck.executeQuery()) {
	                if (rs.next()) {
	                    exists = true;
	                }
	            }
	        }

	        int affectedRows = 0;
	        if (exists) {
	            // ရှိပြီးသားဆိုလျှင် Status ကို pending သို့ Update လုပ်မည်
	            try (PreparedStatement psUpdate = conn.prepareStatement(updateQuery)) {
	                psUpdate.setInt(1, senderId);
	                psUpdate.setInt(2, receiverId);
	                psUpdate.setInt(3, senderId);
	                psUpdate.setInt(4, receiverId);
	                psUpdate.setInt(5, receiverId);
	                psUpdate.setInt(6, senderId);
	                affectedRows = psUpdate.executeUpdate();
	            }
	        } else {
	            // မရှိသေးလျှင် အသစ် Insert လုပ်မည်
	            try (PreparedStatement psInsert = conn.prepareStatement(insertQuery)) {
	                psInsert.setInt(1, senderId);
	                psInsert.setInt(2, receiverId);
	                affectedRows = psInsert.executeUpdate();
	            }
	        }
	        
	        if (affectedRows > 0) {
	            try (PreparedStatement psNotif = conn.prepareStatement(notifQuery)) {
	                psNotif.setInt(1, receiverId);
	                psNotif.setInt(2, senderId);
	                psNotif.executeUpdate();
	            }
	            
	            conn.commit();
	            return true;
	        }
	        
	        conn.rollback();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	    

    public boolean acceptRequest(int senderId, int receiverId) {
        String query = "UPDATE friendships SET status = 'accepted' WHERE sender_id = ? AND receiver_id = ?";
        // ပြင်ဆင်ချက်: refrence_id ကို reference_id သို့ ပြင်ထားပါသည်
        String notifQuery = "INSERT INTO notifications (user_id, actor_id, type, reference_id, is_read) VALUES (?, ?, 'friend_accept', 0, 0)";
        
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false); // Transaction စတင်ရန်
            
            try (PreparedStatement ps = conn.prepareStatement(query);
                 PreparedStatement psNotif = conn.prepareStatement(notifQuery)) {
                
                ps.setInt(1, senderId);
                ps.setInt(2, receiverId);
                int affectedRows = ps.executeUpdate();
                
                if (affectedRows > 0) {
                    psNotif.setInt(1, senderId);
                    psNotif.setInt(2, receiverId);
                    psNotif.executeUpdate();
                    
                    conn.commit();
                    return true;
                }
                conn.rollback();
            } catch (Exception e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean removeFriendship(int userId1, int userId2) {
        String query = "DELETE FROM friendships WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId1);
            ps.setInt(2, userId2);
            ps.setInt(3, userId2);
            ps.setInt(4, userId1);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // 🔴 အသစ်ထည့်သွင်းပေးလိုက်သော မက်သစ် (Profile တွင် ခလုတ်ပြောင်းရန် သုံးသည်)
    public String getFriendshipStatus(int userId1, int userId2) {
        String query = "SELECT sender_id, receiver_id, status FROM friendships WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId1);
            ps.setInt(2, userId2);
            ps.setInt(3, userId2);
            ps.setInt(4, userId1);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String status = rs.getString("status");
                    int senderId = rs.getInt("sender_id");
                    
                    if ("accepted".equals(status)) {
                        return "friends";
                    } else if ("pending".equals(status)) {
                        if (senderId == userId1) {
                            return "pending_sent"; // ကိုယ့်ဘက်က တောင်းဆိုထားတာ
                        } else {
                            return "pending_received"; // သူ့ဘက်က တောင်းဆိုထားတာ (Accept လုပ်ရန်)
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "none"; // ဘယ်လို ဆက်ဆံရေးမှ မရှိသေး
    }

    public List<Map<String, Object>> getFriendsList(int userId) {
        List<Map<String, Object>> friends = new ArrayList<>();
        String query = "SELECT u.* FROM users u JOIN friendships f ON (u.user_id = f.sender_id OR u.user_id = f.receiver_id) " +
                       "WHERE (f.sender_id = ? OR f.receiver_id = ?) AND f.status = 'accepted' AND u.user_id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            ps.setInt(2, userId);
            ps.setInt(3, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int friendId = rs.getInt("user_id");
                    Map<String, Object> user = new HashMap<>();
                    user.put("user_id", friendId);
                    user.put("name", rs.getString("name"));
                    user.put("email", rs.getString("email"));
                    user.put("bg_color", rs.getString("bg_color"));
                    user.put("friendAvatar", "ImageServlet?user_id=" + friendId + "&type=profile");
                    friends.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return friends;
    }

    public List<Map<String, Object>> getSuggestionsList(int userId) {
        List<Map<String, Object>> suggestions = new ArrayList<>();
        String query = "SELECT * FROM users WHERE user_id != ? AND user_id NOT IN (" +
                       "SELECT sender_id FROM friendships WHERE receiver_id = ? UNION " +
                       "SELECT receiver_id FROM friendships WHERE sender_id = ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            ps.setInt(2, userId);
            ps.setInt(3, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int uId = rs.getInt("user_id");
                    Map<String, Object> user = new HashMap<>();
                    user.put("user_id", uId);
                    user.put("name", rs.getString("name"));
                    user.put("bg_color", rs.getString("bg_color"));
                    user.put("avatar", "ImageServlet?user_id=" + uId + "&type=profile");
                    suggestions.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return suggestions;
    }

    public List<Map<String, Object>> getRequestsList(int userId) {
        List<Map<String, Object>> requests = new ArrayList<>();
        String query = "SELECT u.user_id, u.name, u.bg_color FROM users u JOIN friendships f ON u.user_id = f.sender_id WHERE f.receiver_id = ? AND f.status = 'pending'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int senderId = rs.getInt("user_id");
                    Map<String, Object> user = new HashMap<>();
                    user.put("user_id", senderId);
                    user.put("name", rs.getString("name"));
                    user.put("bg_color", rs.getString("bg_color"));
                    user.put("avatar", "ImageServlet?user_id=" + senderId + "&type=profile");
                    requests.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return requests;
    }

    public boolean hasPendingRequests(int userId) {
        boolean status = false;
        String query = "SELECT * FROM friendships WHERE receiver_id = ? AND status = 'pending'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    status = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public boolean hasUnreadMessages(int userId) {
        String query = "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean hasUnreadNotifications(int userId) {
        String query = "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
} 