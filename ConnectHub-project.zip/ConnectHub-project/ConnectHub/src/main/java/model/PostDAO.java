package model;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.DBConnection;

public class PostDAO {

    // ၁။ ပို့စ်အချက်အလက်နှင့် ပုံများကို Database သို့ သိမ်းဆည်းသည့် Method
    public boolean createPost(int userId, String postTitle, String postText, String bgStyle, List<String> imageNames) {
        Connection conn = null;
        PreparedStatement pstPost = null;
        PreparedStatement pstImg = null;
        ResultSet rs = null;
        boolean isSuccess = false;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            String queryPost = "INSERT INTO posts (user_id, post_title, text, bg_style) VALUES (?, ?, ?, ?)";
            pstPost = conn.prepareStatement(queryPost, Statement.RETURN_GENERATED_KEYS);
            pstPost.setInt(1, userId);
            pstPost.setString(2, postTitle);
            pstPost.setString(3, postText);
            pstPost.setString(4, bgStyle);
            pstPost.executeUpdate();

            rs = pstPost.getGeneratedKeys();
            int postId = 0;
            if (rs.next()) {
                postId = rs.getInt(1);
            }

            if (imageNames != null && !imageNames.isEmpty() && postId > 0) {
                String queryImg = "INSERT INTO post_images (post_id, image_name) VALUES (?, ?)";
                pstImg = conn.prepareStatement(queryImg);

                for (String imageName : imageNames) {
                    pstImg.setInt(1, postId);
                    pstImg.setString(2, imageName);
                    pstImg.addBatch();
                }
                pstImg.executeBatch();
            }

            conn.commit();
            isSuccess = true;

        } catch (Exception e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) {}
            try { if (pstPost != null) pstPost.close(); } catch (SQLException e) {}
            try { if (pstImg != null) pstImg.close(); } catch (SQLException e) {}
            try { if (conn != null) conn.close(); } catch (SQLException e) {}
        }

        return isSuccess;
    }

    // ၂။ ပို့စ်တစ်ခုကို ဖျက်ဆီးရန်အတွက် လိုအပ်သော အချက်အလက်များကို စစ်ဆေးပြီး ဖျက်ပေးသည့် Method
    public boolean deletePost(int postId, int userId, String uploadPath) {
        Connection conn = null;
        PreparedStatement pstCheck = null;
        PreparedStatement pstImg = null;
        PreparedStatement pstDelImg = null;
        PreparedStatement pstDelPost = null;
        ResultSet rs = null;
        boolean isDeleted = false;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            String checkSql = "SELECT user_id FROM posts WHERE post_id = ?";
            pstCheck = conn.prepareStatement(checkSql);
            pstCheck.setInt(1, postId);
            rs = pstCheck.executeQuery();

            if (rs.next()) {
                int postOwnerId = rs.getInt("user_id");
                if (postOwnerId != userId) {
                    return false;
                }
            } else {
                return false;
            }

            String imgQuery = "SELECT image_name FROM post_images WHERE post_id = ?";
            pstImg = conn.prepareStatement(imgQuery);
            pstImg.setInt(1, postId);
            ResultSet imgRs = pstImg.executeQuery();

            List<String> imageNames = new ArrayList<>();
            while (imgRs.next()) {
                imageNames.add(imgRs.getString("image_name"));
            }
            imgRs.close();

            String delImgSql = "DELETE FROM post_images WHERE post_id = ?";
            pstDelImg = conn.prepareStatement(delImgSql);
            pstDelImg.setInt(1, postId);
            pstDelImg.executeUpdate();

            String delPostSql = "DELETE FROM posts WHERE post_id = ?";
            pstDelPost = conn.prepareStatement(delPostSql);
            pstDelPost.setInt(1, postId);
            pstDelPost.executeUpdate();

            conn.commit();
            isDeleted = true;

            if (isDeleted && uploadPath != null) {
                for (String imageName : imageNames) {
                    File imgFile = new File(uploadPath + File.separator + imageName);
                    if (imgFile.exists()) {
                        imgFile.delete();
                    }
                }
            }

        } catch (Exception e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstCheck != null) pstCheck.close(); } catch (Exception e) {}
            try { if (pstImg != null) pstImg.close(); } catch (Exception e) {}
            try { if (pstDelImg != null) pstDelImg.close(); } catch (Exception e) {}
            try { if (pstDelPost != null) pstDelPost.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }

        return isDeleted;
    }

    // ၃။ Edit လုပ်ရန် ပို့စ်အချက်အလက်များကို ရှာဖွေပေးသည့် Method
    public Map<String, Object> getPostById(int postId, int userId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Map<String, Object> postMap = null;

        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM posts WHERE post_id = ? AND user_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, postId);
            pstmt.setInt(2, userId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                postMap = new HashMap<>();
                postMap.put("postId", rs.getInt("post_id"));
                postMap.put("postTitle", rs.getString("post_title"));
                postMap.put("postContent", rs.getString("text"));
                postMap.put("bgStyle", rs.getString("bg_style"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }

        return postMap;
    }

    // ၄။ ပို့စ်အချက်အလက်များကို အပ်ဒိတ်လုပ်သည့် Method
    public boolean updatePost(int postId, int userId, String postTitle, String postContent, String bgStyle) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean isUpdated = false;

        try {
            conn = DBConnection.getConnection();
            String sql = "UPDATE posts SET post_title = ?, text = ?, bg_style = ? WHERE post_id = ? AND user_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, postTitle);
            pstmt.setString(2, postContent);
            pstmt.setString(3, bgStyle);
            pstmt.setInt(4, postId);
            pstmt.setInt(5, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                isUpdated = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }

        return isUpdated;
    }

    // ၅။ ပို့စ် ID ဖြင့် ပို့စ်ပိုင်ရှင်၏ User ID ကို ရှာဖွေပေးသည့် Method (Like/Comment နိုတစ်များအတွက် သုံးရန်)
    public int getPostOwnerId(int postId) {
        int ownerId = 0;
        String sql = "SELECT user_id FROM posts WHERE post_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, postId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    ownerId = rs.getInt("user_id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ownerId;
    }
}