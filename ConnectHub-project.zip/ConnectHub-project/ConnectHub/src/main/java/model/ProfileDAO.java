package model;

import java.io.InputStream;
import java.sql.*;
import java.sql.Date;
import java.util.*;

public class ProfileDAO {

    // ၁။ User ID တစ်ခုတည်းဖြင့် Profile အချက်အလက်များ ဆွဲထုတ်ရန် (ကိုယ့်ဟာဖြစ်ဖြစ်၊ သူများဟာဖြစ်ဖြစ် အတူတူသုံးနိုင်သည်)[cite: 5]
    public Map<String, Object> getProfileByUserId(int userId) {
        Map<String, Object> profile = new HashMap<>();
        String sql = "SELECT * FROM profiles WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    profile.put("bio", rs.getString("bio"));
                    profile.put("gender", rs.getString("gender"));
                    profile.put("birthdate", rs.getDate("birthdate"));
                    profile.put("occupation", rs.getString("occupation"));
                    profile.put("address", rs.getString("address"));
                    profile.put("profileImage", rs.getBytes("profile_image")); 
                    
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return profile;
    }

    // ၂။ User ၏ အမည် (Username) ကို ID ဖြင့် ရှာထုတ်ရန်[cite: 5]
    public String getUserNameById(int userId) {
        String name = "";
        String sql = "SELECT name FROM users WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    name = rs.getString("name");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return name;
    }

    // ၃။ Edit Profile အတွက် users ဇယားနှင့် profiles ဇယား Join ပြီးဆွဲထုတ်ရန်[cite: 5]
    public Map<String, Object> getProfileForEdit(int userId) {
        Map<String, Object> profile = new HashMap<>();
        String sql = "SELECT p.bio, p.gender, p.birthdate, p.occupation, p.address " +
                     "FROM users u LEFT JOIN profiles p ON u.user_id = p.user_id WHERE u.user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    profile.put("bio", rs.getString("bio") != null ? rs.getString("bio") : "");
                    profile.put("gender", rs.getString("gender") != null ? rs.getString("gender") : "");
                    profile.put("birthdate", rs.getDate("birthdate") != null ? rs.getDate("birthdate") : "");
                    profile.put("occupation", rs.getString("occupation") != null ? rs.getString("occupation") : "");
                    profile.put("address", rs.getString("address") != null ? rs.getString("address") : "");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return profile;
    }

    // ၄။ Profile အချက်အလက်များကို Update သို့မဟုတ် Insert လုပ်ရန်[cite: 5]
    public void saveOrUpdateProfile(int userId, String bio, String gender, Date birthdate, 
            String occupation, String address, 
            InputStream profileInputStream, long profileSize,
            InputStream coverInputStream, long coverSize) throws Exception {
try (Connection conn = DBConnection.getConnection()) {
String checkSql = "SELECT * FROM profiles WHERE user_id = ?";
try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
checkStmt.setInt(1, userId);
try (ResultSet rs = checkStmt.executeQuery()) {

if (rs.next()) {
StringBuilder updateSql = new StringBuilder("UPDATE profiles SET bio=?, gender=?, birthdate=?, occupation=?, address=?");
if (profileInputStream != null && profileSize > 0) updateSql.append(", profile_image=?");
if (coverInputStream != null && coverSize > 0) updateSql.append(", cover_image=?");
updateSql.append(" WHERE user_id=?");

try (PreparedStatement pstmt = conn.prepareStatement(updateSql.toString())) {
    pstmt.setString(1, bio);
    pstmt.setString(2, gender);
    pstmt.setDate(3, birthdate);
    pstmt.setString(4, occupation);
    pstmt.setString(5, address);

    int paramIndex = 6;
    if (profileInputStream != null && profileSize > 0) {
        pstmt.setBinaryStream(paramIndex++, profileInputStream, (int) profileSize);
    }
    if (coverInputStream != null && coverSize > 0) {
        pstmt.setBinaryStream(paramIndex++, coverInputStream, (int) coverSize);
    }
    pstmt.setInt(paramIndex, userId);

    pstmt.executeUpdate();
}

} else {
String insertSql = "INSERT INTO profiles (user_id, bio, gender, birthdate, occupation, address, profile_image, cover_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
    pstmt.setInt(1, userId);
    pstmt.setString(2, bio);
    pstmt.setString(3, gender);
    pstmt.setDate(4, birthdate);
    pstmt.setString(5, occupation);
    pstmt.setString(6, address);
    
    if (profileInputStream != null && profileSize > 0) {
        pstmt.setBinaryStream(7, profileInputStream, (int) profileSize);
    } else {
        pstmt.setNull(7, java.sql.Types.BLOB);
    }

    if (coverInputStream != null && coverSize > 0) {
        pstmt.setBinaryStream(8, coverInputStream, (int) coverSize);
    } else {
        pstmt.setNull(8, java.sql.Types.BLOB);
    }

    pstmt.executeUpdate();
}
}
}
}
} 
// Note: Exception ကို ဖုံးမထားဘဲ အပြင်သို့ ပစ်ပေးလိုက်ပါ (Servlet က ဖမ်းနိုင်ရန်)
}

    // ၅။ သတ်မှတ်ထားသော User တင်ထားသော ပို့စ်များနှင့် Like/Comment များကို ဆွဲထုတ်ရန်[cite: 5]
 // ၅။ သတ်မှတ်ထားသော User တင်ထားသော ပို့စ်များနှင့် Like/Comment များကို ဆွဲထုတ်ရန်
    public List<Map<String, Object>> getUserPosts(int userId) {
        List<Map<String, Object>> postsList = new ArrayList<>();
        String postSql = "SELECT p.post_id, p.user_id, p.post_title, p.text, p.bg_style, p.created_at, u.name AS username " +
                         "FROM posts p JOIN users u ON p.user_id = u.user_id " +
                         "WHERE p.user_id = ? ORDER BY p.created_at DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement postStmt = conn.prepareStatement(postSql)) {
            postStmt.setInt(1, userId);
            try (ResultSet postRs = postStmt.executeQuery()) {
                while (postRs.next()) {
                    Map<String, Object> postMap = new HashMap<>();
                    int postId = postRs.getInt("post_id");
                    
                    postMap.put("postId", postId);
                    
                    // 👇 ဤနေရာတွင် User ID ကို Key နှစ်မျိုးစလုံးဖြင့် ထည့်ပေးပါ (JSP ဘက်တွင် အဆင်ပြေစေရန်)
                    postMap.put("userId", postRs.getInt("user_id"));
                    postMap.put("user_id", postRs.getInt("user_id"));
                    
                    postMap.put("postTitle", postRs.getString("post_title"));
                    postMap.put("text", postRs.getString("text"));
                    postMap.put("bgStyle", postRs.getString("bg_style"));
                    postMap.put("createdAt", postRs.getString("created_at"));
                    postMap.put("username", postRs.getString("username"));

                    // ကျန်ရှိသော ပုံများ၊ Likes နှင့် Comments ဆွဲထုတ်သည့် ကုဒ်များ ဆက်လက်တည်ရှိမည်
                    // ...

                    // ပုံများကို ဆွဲထုတ်ခြင်း[cite: 5]
                    List<String> imagesList = new ArrayList<>();
                    try (PreparedStatement imgStmt = conn.prepareStatement("SELECT image_name FROM post_images WHERE post_id = ?")) {
                        imgStmt.setInt(1, postId);
                        try (ResultSet imgRs = imgStmt.executeQuery()) {
                            while (imgRs.next()) {
                                imagesList.add(imgRs.getString("image_name"));
                            }
                        }
                    }
                    postMap.put("images", imagesList);

                    // Like အရေအတွက် ရယူရန်[cite: 5]
                    int likeCount = 0;
                    try (PreparedStatement likeStmt = conn.prepareStatement("SELECT COUNT(*) FROM likes WHERE post_id = ?")) {
                        likeStmt.setInt(1, postId);
                        try (ResultSet likeRs = likeStmt.executeQuery()) {
                            if (likeRs.next()) likeCount = likeRs.getInt(1);
                        }
                    }
                    postMap.put("likeCount", likeCount);

                    // Comments များကို ဆွဲထုတ်ခြင်း[cite: 5]
                    List<Map<String, Object>> commentsList = new ArrayList<>();
                    String commQuery = "SELECT c.*, u.name AS username FROM comments c JOIN users u ON c.user_id = u.user_id WHERE c.post_id = ? ORDER BY c.created_at ASC";
                    try (PreparedStatement commStmt = conn.prepareStatement(commQuery)) {
                        commStmt.setInt(1, postId);
                        try (ResultSet commRs = commStmt.executeQuery()) {
                            while (commRs.next()) {
                                Map<String, Object> commentMap = new HashMap<>();
                                commentMap.put("commentId", commRs.getInt("comment_id")); 
                                commentMap.put("userId", commRs.getInt("user_id"));
                                commentMap.put("username", commRs.getString("username"));
                                commentMap.put("commentText", commRs.getString("comment_text"));
                                commentMap.put("createdAt",commRs.getString("created_at")); // or timestamp formatted to a string
                                commentsList.add(commentMap);
                            }
                        }
                    }
                    postMap.put("commentsList", commentsList);
                    postMap.put("commentCount", commentsList.size());

                    postsList.add(postMap);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return postsList;
    }
} 