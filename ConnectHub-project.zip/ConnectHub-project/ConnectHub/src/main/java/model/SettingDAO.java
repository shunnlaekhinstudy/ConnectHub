package model;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class SettingDAO {

    // ၁။ Background Theme အရောင်ကို အပ်ဒိတ်လုပ်ခြင်း
    public boolean updateTheme(int userId, String bg) {
        String sql = "UPDATE users SET bg_color = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, bg);
            pstmt.setInt(2, userId);
            pstmt.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ၂။ User အချက်အလက် (Name, Email, Password) များကို အပ်ဒိတ်လုပ်ခြင်း
    public boolean updateUserInfo(int userId, String name, String email, String password) {
        String sql;
        try (Connection conn = DBConnection.getConnection()) {
            
            if (password != null && !password.trim().isEmpty()) {
                sql = "UPDATE users SET name = ?, email = ?, password = ? WHERE user_id = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, name);
                    pstmt.setString(2, email);
                    pstmt.setString(3, password);
                    pstmt.setInt(4, userId);
                    pstmt.executeUpdate();
                }
            } else {
                sql = "UPDATE users SET name = ?, email = ? WHERE user_id = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, name);
                    pstmt.setString(2, email);
                    pstmt.setInt(3, userId);
                    pstmt.executeUpdate();
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ၃။ Feedback တင်သွင်းခြင်း
   
    public boolean submitFeedback(int userId, String feedback) {
        boolean success = false;
        String sql = "INSERT INTO project_feedbacks (user_id, feedback) VALUES (?, ?)";
        
        try (Connection conn = DBConnection.getConnection(); // သင့် Database Connection နာမည်အတိုင်း
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setInt(1, userId);
            pstmt.setString(2, feedback);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    // ၄။ အကောင့်ဖျက်ခြင်း
    public boolean deleteAccount(int userId) {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}