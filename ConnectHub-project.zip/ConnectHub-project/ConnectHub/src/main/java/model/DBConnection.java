package model;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/connecthub", "root", "Your_password");
            //Replace your password in Your_password
        } catch (Exception e) {
            // Console ထဲမှာ တကယ့်အမှား ဘာလဲဆိုတာ အသေအချာ ပေါ်လာစေရန်
            System.out.println("--- DB CONNECTION ERROR ---");
            e.printStackTrace();
        }
        return conn;
    }
}