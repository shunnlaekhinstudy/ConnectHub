package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.*;

public class MessageDAO {

    // ၁။ Accepted ဖြစ်နေသော သူငယ်ချင်းများစာရင်းကို ID ဖြင့် ထုတ်ယူရန် Query
    public List<Integer> getAcceptedFriendIds(int userId) {
        List<Integer> friendIds = new ArrayList<>();
        String sql = "SELECT sender_id, receiver_id FROM friendships WHERE (sender_id = ? OR receiver_id = ?) AND status = 'accepted'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()) {
                    int sId = rs.getInt("sender_id");
                    int rId = rs.getInt("receiver_id");
                    int fId = (sId == userId) ? rId : sId;
                    if(!friendIds.contains(fId)) {
                        friendIds.add(fId);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return friendIds;
    }

    // ၂။ သူငယ်ချင်း၏ နာမည်ကို user_id ဖြင့် ရှာရန် Query
    public String getUserName(int userId) {
        String name = "User " + userId;
        String sql = "SELECT name FROM users WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()) {
                    String dbName = rs.getString("name");
                    if(dbName != null && !dbName.trim().isEmpty()) {
                        name = dbName;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return name;
    }

    // ၃။ နောက်ဆုံးပြောထားသော Message နှင့် Unread အခြေအနေကို စစ်ဆေးရန် Query
    public Map<String, Object> getLastMessageAndStatus(int userId, int friendId) {
        Map<String, Object> result = new HashMap<>();
        String lastMsg = "send new message";
        boolean isUnread = false;

        String sql = "SELECT sender_id, message, is_read FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at DESC LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, friendId);
            ps.setInt(3, friendId);
            ps.setInt(4, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()) {
                    int senderId = rs.getInt("sender_id");
                    lastMsg = rs.getString("message");
                    int isRead = rs.getInt("is_read");
                    
                    if(senderId != userId && isRead == 0) {
                        isUnread = true;
                    }

                    if(lastMsg != null && lastMsg.startsWith("[Repled]")) {
                        lastMsg = "↩️ Reply sent a message";
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        result.put("lastMessage", lastMsg);
        result.put("isUnread", isUnread);
        return result;
    }

    // ၄။ မဖတ်ရသေးသော မက်ဆေ့ချ်များကို ချက်ချင်း Read (is_read = 1) လုပ်ခြင်း
    public void markMessagesAsRead(int receiverId, int senderId) {
        String sql = "UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ? AND is_read = 0";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, receiverId);
            ps.setInt(2, senderId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ၅။ မက်ဆေ့ချ်အသစ် ပို့ခြင်း နှင့် နိုတစ် ထည့်သွင်းခြင်း
    public void sendMessage(int senderId, int receiverId, String finalMsg, Timestamp timestamp) {
        String insertMsgSQL = "INSERT INTO messages (sender_id, receiver_id, message, is_read, created_at) VALUES (?, ?, ?, 0, ?)";
        String insertNotifSQL = "INSERT INTO notifications (user_id, actor_id, type, reference_id, is_read, created_at) VALUES (?, ?, 'message', ?, 0, ?)";

        try (Connection conn = DBConnection.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(insertMsgSQL)) {
                ps.setInt(1, senderId);
                ps.setInt(2, receiverId);
                ps.setString(3, finalMsg);
                ps.setTimestamp(4, timestamp);
                ps.executeUpdate();
            }

            try (PreparedStatement psNotif = conn.prepareStatement(insertNotifSQL)) {
                psNotif.setInt(1, receiverId);
                psNotif.setInt(2, senderId);
                psNotif.setInt(3, senderId);
                psNotif.setTimestamp(4, timestamp);
                psNotif.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ၆။ မိမိပို့ထားသော မက်ဆေ့ချ်ကို ဖျက်ခြင်း
    public void deleteMessage(int messageId, int senderId) {
        String sql = "DELETE FROM messages WHERE id = ? AND sender_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, messageId);
            ps.setInt(2, senderId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ၇။ မဖတ်ရသေးသော မက်ဆေ့ချ်စုစုပေါင်း အရေအတွက်ကို ရယူရန်
    public int getUnreadMessageCount(int userId) {
        String sql = "SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // ၈။ သူနှစ်ဦးကြား Chat Messages များအားလုံး ထုတ်ယူရန် (Chat အတွက်)
    public List<Map<String, Object>> getChatMessages(int userId1, int userId2) {
        List<Map<String, Object>> messages = new ArrayList<>();
        String sql = "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId1);
            ps.setInt(2, userId2);
            ps.setInt(3, userId2);
            ps.setInt(4, userId1);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> msg = new HashMap<>();
                    msg.put("id", rs.getInt("id"));
                    msg.put("sender_id", rs.getInt("sender_id"));
                    msg.put("receiver_id", rs.getInt("receiver_id"));
                    msg.put("message", rs.getString("message"));
                    msg.put("created_at", rs.getTimestamp("created_at"));
                    msg.put("reaction", rs.getString("reaction"));
                    messages.add(msg);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return messages;
    }

    // ၉။ Reaction အဟောင်းကို စစ်ဆေးရန်
    public String getMessageReaction(int messageId) {
        String reaction = "";
        String sql = "SELECT reaction FROM messages WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, messageId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    reaction = rs.getString("reaction");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reaction;
    }

    // ၁၀။ Reaction Update လုပ်ရန်
    public void updateReaction(int messageId, String newReaction) {
        String sql = "UPDATE messages SET reaction = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newReaction);
            ps.setInt(2, messageId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}