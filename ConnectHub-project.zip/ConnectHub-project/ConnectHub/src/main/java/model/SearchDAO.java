package model;

import java.sql.*;
import java.util.*;
import model.DBConnection;

public class SearchDAO {

    // User များကို ရှာဖွေရန် (Friend status ပါ စစ်ဆေးသည်)
    public List<Map<String, Object>> searchUsers(String keyword, int currentUserId) {
        List<Map<String, Object>> usersList = new ArrayList<>();
        String sql = "SELECT user_id, name, email FROM users WHERE (name LIKE ? OR email LIKE ?) AND user_id != ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setString(2, "%" + keyword + "%");
            pstmt.setInt(3, currentUserId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> user = new HashMap<>();
                    int targetUserId = rs.getInt("user_id");
                    user.put("userId", targetUserId);
                    user.put("name", rs.getString("name"));
                    user.put("email", rs.getString("email"));
                    
                    // သူငယ်ချင်း ဆက်ဆံရေး အခြေအနေကို စစ်ဆေးခြင်း
                    String friendStatus = getFriendshipStatus(conn, currentUserId, targetUserId);
                    user.put("friendStatus", friendStatus); // 'friends', 'requested', 'pending', 'none'
                    
                    usersList.add(user);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return usersList;
    }

    // Post များကို keyword ဖြင့် ရှာဖွေရန် (home.jsp ကဲ့သို့ like, comment, images အစုံပါဝင်မည်)
    public List<Map<String, Object>> searchPosts(String keyword, int currentUserId) {
        List<Map<String, Object>> searchPostsList = new ArrayList<>();
        
        String sql = "SELECT p.post_id, p.user_id, p.post_title, p.text, p.bg_style, p.created_at, u.name AS author_name " +
                     "FROM posts p JOIN users u ON p.user_id = u.user_id " +
                     "WHERE p.text LIKE ? OR p.post_title LIKE ? " +
                     "ORDER BY p.created_at DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setString(2, "%" + keyword + "%");
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> post = new HashMap<>();
                    int postId = rs.getInt("post_id");
                    
                    post.put("postId", postId);
                    post.put("userId", rs.getInt("user_id"));
                    post.put("username", rs.getString("author_name"));
                    post.put("postTitle", rs.getString("post_title"));
                    post.put("text", rs.getString("text"));
                    post.put("bgStyle", rs.getString("bg_style"));
                    post.put("createdAt", rs.getString("created_at"));

                    // ပို့စ်ပုံများ (Images) ကို ဆွဲထုတ်ရန်
                 // ပို့စ်ပုံများ (Images) ကို ဆွဲထုတ်ရန်
                    List<String> images = new ArrayList<>();
                    try (PreparedStatement imgStmt = conn.prepareStatement("SELECT image_name FROM post_images WHERE post_id = ?")) {
                        imgStmt.setInt(1, postId);
                        try (ResultSet imgRs = imgStmt.executeQuery()) {
                            while (imgRs.next()) {
                                images.add(imgRs.getString("image_name"));
                            }
                        }
                    }
                    post.put("images", images);

                    // Like အရေအတွက်နှင့် လက်ရှိ User Like ထားခြင်း ရှိမရှိ စစ်ဆေးရန်
                    int likeCount = 0;
                    boolean isLikedByMe = false;
                    try (PreparedStatement likeStmt = conn.prepareStatement("SELECT user_id FROM likes WHERE post_id = ?")) {
                        likeStmt.setInt(1, postId);
                        try (ResultSet likeRs = likeStmt.executeQuery()) {
                            while (likeRs.next()) {
                                likeCount++;
                                if (likeRs.getInt("user_id") == currentUserId) {
                                    isLikedByMe = true;
                                }
                            }
                        }
                    }
                    post.put("likeCount", likeCount);
                    post.put("isLikedByMe", isLikedByMe);

                    // ကောမန့်များ (Comments နှင့် Replies) ကို ဆွဲထုတ်ရန်
                    List<Map<String, Object>> commentsList = new ArrayList<>();
                    String commSql = "SELECT c.comment_id, c.user_id, c.comment_text, c.parent_id, c.created_at, u.name AS comment_author " +
                            "FROM comments c JOIN users u ON c.user_id = u.user_id " +
                            "WHERE c.post_id = ? ORDER BY c.comment_id DESC";
                    try (PreparedStatement commStmt = conn.prepareStatement(commSql)) {
                        commStmt.setInt(1, postId);
                        try (ResultSet commRs = commStmt.executeQuery()) {
                            while (commRs.next()) {
                                Map<String, Object> comment = new HashMap<>();
                                comment.put("commentId", commRs.getInt("comment_id"));
                                comment.put("userId", commRs.getInt("user_id"));
                                comment.put("username", commRs.getString("comment_author"));
                                comment.put("commentText", commRs.getString("comment_text"));
                                comment.put("createdAt", commRs.getString("created_at"));
                                comment.put("parentId", commRs.getObject("parent_id") != null ? commRs.getInt("parent_id") : null);
                                commentsList.add(comment);
                            }
                        }
                    }
                    post.put("commentCount", commentsList.size());
                    post.put("commentsList", commentsList);

                    searchPostsList.add(post);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return searchPostsList;
    }

    // သူငယ်ချင်း ဟုတ်/မဟုတ် စစ်ဆေးသည့် Method (သင်၏ friendships table ပုံစံအပေါ်မူတည်ပြီး ချိန်ညှိနိုင်ပါသည်)
    private String getFriendshipStatus(Connection conn, int currentUserId, int targetUserId) {
        String sql = "SELECT status, user1_id, user2_id, sender_id FROM friendships WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, currentUserId);
            pstmt.setInt(2, targetUserId);
            pstmt.setInt(3, targetUserId);
            pstmt.setInt(4, currentUserId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String status = rs.getString("status");
                    int senderId = rs.getInt("sender_id");
                    if ("accepted".equalsIgnoreCase(status) || "friend".equalsIgnoreCase(status)) {
                        return "friends";
                    } else if ("pending".equalsIgnoreCase(status)) {
                        if (senderId == currentUserId) {
                            return "requested"; // ကိုယ်က request ပို့ထားတာ
                        } else {
                            return "pending";   // သူက request ပို့ထားလို့ accept ရမည့်သူ
                        }
                    }
                }
            }
        } catch (Exception e) {
            // friendships table မရှိသေးပါက သို့မဟုတ် error တက်ပါက default 'none' ပြန်မည်
        }
        return "none";
    }
}