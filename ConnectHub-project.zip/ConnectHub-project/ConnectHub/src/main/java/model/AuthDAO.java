package model;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class AuthDAO {

    // Password ကို Hashing ပြန်လုပ်မည့် Method
    public String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Login ဝင်ရန် အချက်အလက်များ တိုက်စစ်ခြင်း
    public Map<String, Object> loginUser(String email, String hashedPassword) {
        Map<String, Object> userMap = null;
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, email);
            pst.setString(2, hashedPassword);
            
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    userMap = new HashMap<>();
                    userMap.put("userId", rs.getInt("user_id"));
                    userMap.put("name", rs.getString("name"));
                    userMap.put("email", rs.getString("email"));
                    String userBg = rs.getString("bg_color");
                    if (userBg == null) userBg = "#ffffff";
                    userMap.put("bgColor", userBg);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userMap;
    }

    // Forgot Password အတွက် Email ရှိမရှိ စစ်ဆေးခြင်း
    public boolean checkEmailExists(String email) {
        boolean exists = false;
        String sql = "SELECT * FROM users WHERE email = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, email);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    exists = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exists;
    }
    public static void createDefaultProfile(int userId) {
        String query = "INSERT INTO profiles (user_id, cover_image, profile_image) VALUES (?, NULL, NULL)";
        
        try (Connection conn = DBConnection.getConnection(); // သင့် database connection ပုံစံအတိုင်း ပြင်ပါ
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public int getUserIdByEmail(String email) {
        int userId = -1;
        String query = "SELECT id FROM users WHERE email = ?";
        // Database connection နှင့် PreparedStatement ဖြင့် query ထုတ်ပြီး userId ကို return ပြန်ရန်
        // ...
        return userId;
    }
    // Signup (အကောင့်အသစ်ဖွင့်ခြင်း)
    public boolean registerUser(String name, String email, String hashedPassword) {
        boolean isSuccess = false;
        String sql = "INSERT INTO users (name, email, password, created_at) VALUES (?, ?, ?, NOW())";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            
            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, hashedPassword);

            int row = pst.executeUpdate();
            if (row > 0) {
                isSuccess = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }
}