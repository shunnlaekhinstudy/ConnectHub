package controller;

import java.io.IOException;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.HomeDAO;
import model.NotificationDAO;
import model.FriendDAO;

@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private HomeDAO homeDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        homeDAO = new HomeDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        
        // Session မှ user_id ကို စစ်ဆေးခြင်း
        Integer userId = (Integer) session.getAttribute("user_id");
        if (userId == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        // HomeDAO မှတစ်ဆင့် Feed Posts များကို ဆွဲထုတ်ခြင်း
        List<Map<String, Object>> feedPostsList = homeDAO.getAllFeedPosts(userId);
        
        // DAO များကို ခေါ်ယူခြင်း
        NotificationDAO notiDAO = new NotificationDAO();
        FriendDAO friendDAO = new FriendDAO(); 

        // 🌟 home.jsp တွင် အသုံးပြုမည့် Variable နာမည်များနှင့် ကိုက်ညီစေရန် ပြင်ဆင်ထားခြင်း
        int unreadCount = notiDAO.getUnreadNotificationCount(userId);
        boolean hasPendingRequests = friendDAO.hasPendingRequests(userId);
        boolean hasUnreadMessages = friendDAO.hasUnreadMessages(userId);

        // Request Attributes များ သတ်မှတ်ပေးပို့ခြင်း
        request.setAttribute("feedPostsList", feedPostsList);
        request.setAttribute("unreadCount", unreadCount);             // home.jsp ရှိ Notification အတွက်
        request.setAttribute("hasPendingRequests", hasPendingRequests); // home.jsp ရှိ Friend Request အတွက်
        request.setAttribute("hasUnreadMessages", hasUnreadMessages);   // home.jsp ရှိ Message အတွက်

        // home.jsp သို့ Forward လုပ်ခြင်း
        request.getRequestDispatcher("home.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}