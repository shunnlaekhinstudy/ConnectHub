package controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import model.PostDAO;

@WebServlet({"/PostServlet", "/DeletePostServlet", "/EditPostServlet", "/PostController"})
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB per file
    maxRequestSize = 1024 * 1024 * 50     // 50MB total request size
)
public class PostController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String UPLOAD_DIR = "uploads";
    private PostDAO postDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        postDAO = new PostDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("user_id");
        String action = request.getRequestURI();

        // 1. Delete Post လုပ်ငန်းစဉ်
        if (action.contains("DeletePostServlet")) {
            String postIdStr = request.getParameter("post_id");
            if (postIdStr == null || postIdStr.trim().isEmpty()) {
                response.sendRedirect("home.jsp");
                return;
            }

            int postId = Integer.parseInt(postIdStr);
            String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;

            boolean isDeleted = postDAO.deletePost(postId, userId, uploadPath);

            if (isDeleted) {
            	response.sendRedirect("ViewProfileServlet?user_id=" + userId);
            } else {
                response.getWriter().println("<h3 style='color:red; text-align:center;'>ပို့စ်ဖျက်ရာတွင် အမှားအယွင်း ရှိပါသည် (သို့မဟုတ်) ခွင့်ပြုချက်မရှိပါ။</h3>");
            }
        } 
        // 2. Edit Post (Form ပြသရန်) လုပ်ငန်းစဉ်
        else if (action.contains("EditPostServlet")) {
            String postIdStr = request.getParameter("post_id");
            if (postIdStr == null || postIdStr.trim().isEmpty()) {
            	response.sendRedirect("ViewProfileServlet?user_id=" + userId);
                return;
            }

            // ဘယ်ကလာတယ်ဆိုတာကို ဖမ်းယူခြင်း (home လား၊ profile လား)
            String from = request.getParameter("from");
            if (from == null || from.trim().isEmpty()) {
                from = "home"; // Default
            }

            int postId = Integer.parseInt(postIdStr);
            Map<String, Object> post = postDAO.getPostById(postId, userId);

            if (post != null) {
                request.setAttribute("postId", post.get("postId"));
                request.setAttribute("postTitle", post.get("postTitle"));
                request.setAttribute("postContent", post.get("postContent"));
                request.setAttribute("bgStyle", post.get("bgStyle"));
                request.setAttribute("from", from); // JSP ဘက်သို့ ပို့ပေးရန်
                
                request.getRequestDispatcher("editPost.jsp").forward(request, response);
            } else {
                response.sendRedirect("myprofile.jsp");
            }
        } 
        // 3. Create Post စာမျက်နှာ (post.jsp) သို့ သွားရန်
        else if (action.contains("PostServlet") || action.contains("PostController")) {
            request.getRequestDispatcher("post.jsp").forward(request, response);
        } 
        else {
            response.sendRedirect("HomeServlet");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("user_id");
        String action = request.getRequestURI();

        // 4. Edit Post (Update လုပ်ရန်) လုပ်ငန်းစဉ်
        if (action.contains("EditPostServlet")) {
            String postIdStr = request.getParameter("postId");
            String postTitle = request.getParameter("postTitle");
            String postContent = request.getParameter("postContent");
            String bgStyle = request.getParameter("bgStyle");
            String from = request.getParameter("from"); // Form မှ ပါလာသော from တန်ဖိုးကို ဖမ်းခြင်း

            if (postIdStr == null || postIdStr.trim().isEmpty()) {
                response.sendRedirect("ProfileServlet");
                return;
            }

            int postId = Integer.parseInt(postIdStr);
            if (bgStyle == null || bgStyle.trim().isEmpty()) {
                bgStyle = "#ffffff";
            }

            boolean isUpdated = postDAO.updatePost(postId, userId, postTitle, postContent, bgStyle);

            if (isUpdated) {
                // 'from' တန်ဖိုးအပေါ်မူတည်၍ မူလနေရာသို့ ပြန်ပို့ခြင်း
                if ("profile".equals(from)) {
                	response.sendRedirect("ViewProfileServlet?user_id=" + userId);
                } else {
                    response.sendRedirect("home.jsp");
                }
            } else {
                response.getWriter().println("<h3 style='color:red; text-align:center;'>Error in editing</h3>");
            }
        } 
        // 5. Create Post (ပို့စ်အသစ်တင်ရန်) လုပ်ငန်းစဉ်
        else {
            String postTitle = request.getParameter("postTitle");
            String postText = request.getParameter("postContent");
            String bgStyle = request.getParameter("bgStyle");

            if (bgStyle == null || bgStyle.trim().isEmpty()) {
                bgStyle = "#ffffff";
            }

            String applicationPath = request.getServletContext().getRealPath("");
            String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;
            
            File fileSaveDir = new File(uploadFilePath);
            if (!fileSaveDir.exists()) {
                fileSaveDir.mkdirs();
            }

            Collection<Part> parts = request.getParts();
            int imageCount = 0;
            List<String> imageNames = new ArrayList<>();

            for (Part part : parts) {
                if (part.getName().equals("images") && part.getSize() > 0) {
                    imageCount++;
                    if (imageCount > 10) {
                        break;
                    }

                    String fileName = extractFileName(part);
                    if (fileName != null && !fileName.isEmpty()) {
                        String uniqueFileName = System.currentTimeMillis() + "_" + fileName;
                        String filePath = uploadFilePath + File.separator + uniqueFileName;
                        
                        part.write(filePath);
                        imageNames.add(uniqueFileName);
                    }
                }
            }

            boolean isCreated = postDAO.createPost(userId, postTitle, postText, bgStyle, imageNames);

            if (isCreated) {
                request.getSession().setAttribute("successMessage", "Posting Success");
                response.sendRedirect("HomeServlet");
            } else {
                response.getWriter().println("<h3 style='color:red; text-align:center;'>Someting went wrong</h3>");
            }
        }
    }

    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}