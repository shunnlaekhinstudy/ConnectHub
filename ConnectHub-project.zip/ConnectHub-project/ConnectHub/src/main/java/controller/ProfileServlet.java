package controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import model.ProfileDAO;
import model.FriendDAO;

@WebServlet({"/ProfileServlet", "/ViewProfileServlet", "/EditProfileServlet"})
@MultipartConfig(maxFileSize = 16177215)
public class ProfileServlet extends HttpServlet {
    private ProfileDAO profileDAO;
    private FriendDAO friendDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        profileDAO = new ProfileDAO();
        friendDAO = new FriendDAO();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        Integer currentUserId = (Integer) session.getAttribute("user_id");
        
        // action parameter ဖြင့် Edit Profile ဟုတ်မဟုတ် စစ်ဆေးရန်[cite: 5]
        String action = request.getParameter("action");
        if ("edit".equals(action)) {
            try {
                Map<String, Object> profile = profileDAO.getProfileForEdit(currentUserId);
                request.setAttribute("bio", profile.get("bio"));
                request.setAttribute("gender", profile.get("gender"));
                request.setAttribute("birthdate", profile.get("birthdate"));
                request.setAttribute("occupation", profile.get("occupation"));
                request.setAttribute("address", profile.get("address"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            request.getRequestDispatcher("editprofile.jsp").forward(request, response);
            return;
        }

        // Profile ကြည့်မည့် လုပ်ငန်းစဉ် (ကိုယ့် Profile သို့မဟုတ် သူများ Profile)[cite: 5]
        String userIdParam = request.getParameter("user_id");
        int targetUserId;

        if (userIdParam == null || userIdParam.isEmpty()) {
            targetUserId = currentUserId; 
        } else {
            targetUserId = Integer.parseInt(userIdParam);
        }

        boolean isOwnProfile = (currentUserId.equals(targetUserId));

        Map<String, Object> profile = profileDAO.getProfileByUserId(targetUserId);
        List<Map<String, Object>> postsList = profileDAO.getUserPosts(targetUserId);
        String targetUserName = profileDAO.getUserNameById(targetUserId);
        

        request.setAttribute("targetUserId", targetUserId);
        request.setAttribute("targetUserName", targetUserName);
        request.setAttribute("isOwnProfile", isOwnProfile);
        request.setAttribute("bio", profile.get("bio"));
        request.setAttribute("gender", profile.get("gender"));
        request.setAttribute("birthdate", profile.get("birthdate"));
        request.setAttribute("occupation", profile.get("occupation"));
        request.setAttribute("address", profile.get("address"));
        request.setAttribute("postsList", postsList);
        if (!isOwnProfile) {
            String friendshipStatus = friendDAO.getFriendshipStatus(currentUserId, targetUserId);
            request.setAttribute("friendshipStatus", friendshipStatus);

            // 🌟 ဤနေရာတွင် friendDAO က ပို့ပေးသော "friends" သို့မဟုတ် status အားလုံးကို ခြုံငုံစစ်ဆေးပေးပါ
            boolean isFriend = "friends".equalsIgnoreCase(friendshipStatus) || 
                               "accepted".equalsIgnoreCase(friendshipStatus);
                               
            request.setAttribute("isFriend", isFriend);
        } else {
            request.setAttribute("isFriend", false);
        }
        request.getRequestDispatcher("myprofile.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("index.jsp");
            return;
        }
        Integer userId = (Integer) session.getAttribute("user_id");

        String bio = request.getParameter("bio");
        String gender = request.getParameter("gender");
        String birthdateStr = request.getParameter("birthdate");
        String occupation = request.getParameter("occupation");
        String address = request.getParameter("address");

        Date birthdate = null;
        if (birthdateStr != null && !birthdateStr.trim().isEmpty()) {
            try {
                birthdate = Date.valueOf(birthdateStr);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }

        InputStream profileInputStream = null;
        long profileSize = 0;
        Part profilePart = request.getPart("profile_image");
        if (profilePart != null && profilePart.getSize() > 0) {
            profileInputStream = profilePart.getInputStream();
            profileSize = profilePart.getSize();
        }

        InputStream coverInputStream = null;
        long coverSize = 0;
        Part coverPart = request.getPart("cover_image");
        if (coverPart != null && coverPart.getSize() > 0) {
            coverInputStream = coverPart.getInputStream();
            coverSize = coverPart.getSize();
        }

        try {
            // ပြင်ဆင်ထားသော saveOrUpdateProfile သို့ size များပါ ထည့်ပေးခြင်း
            profileDAO.saveOrUpdateProfile(userId, bio, gender, birthdate, occupation, address, 
                                            profileInputStream, profileSize, 
                                            coverInputStream, coverSize);
            response.sendRedirect("ProfileServlet");
        } catch (Exception e) {
            e.printStackTrace();
            // ဤနေရာတွင် Error ကို Screen ပေါ်သို့ တိုက်ရိုက် ထုတ်ပြခိုင်းခြင်း
            response.setContentType("text/html;charset=UTF-8");
            java.io.PrintWriter out = response.getWriter();
            out.println("<h3 style='color:red;'>FATAL ERROR: " + e.getMessage() + "</h3>");
            for(StackTraceElement ste : e.getStackTrace()) {
                out.println("<p>" + ste.toString() + "</p>");
            }
        }
    }}