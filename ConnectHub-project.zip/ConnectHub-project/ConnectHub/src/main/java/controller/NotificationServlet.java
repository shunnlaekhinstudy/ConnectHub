package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import model.NotificationDAO;
import model.FriendDAO;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet("/NotificationServlet")
public class NotificationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
        
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        
        Object userIdObj = (session != null) ? session.getAttribute("user_id") : null;
        
        if (userIdObj == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        int currentUserId = 0;
        try {
            currentUserId = Integer.parseInt(String.valueOf(userIdObj));
        } catch (NumberFormatException e) {
            response.sendRedirect("index.jsp");
            return;
        }

        String action = request.getParameter("action");
        String notifIdStr = request.getParameter("notif_id");
        NotificationDAO notifDao = new NotificationDAO();
        FriendDAO friendDAO = new FriendDAO();

        // AJAX Request များ (delete သို့မဟုတ် markRead) အတွက် စစ်ဆေးခြင်း
        if (notifIdStr != null && !notifIdStr.trim().isEmpty()) {
            try {
                int notifId = Integer.parseInt(notifIdStr);
                if ("delete".equals(action)) {
                    boolean success = notifDao.deleteNotification(notifId, currentUserId);
                    if (success) {
                        response.setStatus(HttpServletResponse.SC_OK);
                        response.getWriter().write("SUCCESS");
                    } else {
                        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                        response.getWriter().write("NOT_FOUND");
                    }
                    return;
                } else if ("markRead".equals(action)) {
                    notifDao.markAsRead(notifId, currentUserId);
                    response.setStatus(HttpServletResponse.SC_OK);
                    response.getWriter().write("SUCCESS");
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        List<Map<String, Object>> notifList = new ArrayList<>();

        try {
            List<Map<String, Object>> rawNotifs = notifDao.getNotificationsByUserId(currentUserId);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy, hh:mm:ss a", Locale.ENGLISH);

            for (Map<String, Object> map : rawNotifs) {
                int actorId = (int) map.get("actorId");
                String type = (String) map.get("type");
                Timestamp createdAt = (Timestamp) map.get("createdAt");

                String actorName = notifDao.getUserNameById(actorId);
                String actorAvatar = "ImageServlet?user_id=" + actorId + "&type=profile";

                String notifText = "";
                String targetUrl = "HomeServlet";
                String iconClass = "fa-solid fa-bell";

                if ("friend_request".equals(type)) {
                    notifText = "<b>" + actorName + "</b> sent you a friend request.";
                    targetUrl = "ProfileServlet?user_id=" + actorId; 
                    iconClass = "fa-solid fa-user-plus";
                } else if ("friend_accept".equals(type)) {
                    notifText = "<b>" + actorName + "</b> accepted your friend request.";
                    targetUrl = "ProfileServlet?user_id=" + actorId; 
                    iconClass = "fa-solid fa-user-check";
                } else if ("like".equals(type) || "comment".equals(type)) {
                    // 💡 ပြင်ဆင်ချက်: reference_id အစား referenceId ဟု ပြောင်းသုံးပါ
                    Object referenceIdObj = map.get("referenceId");
                    
                    if ("like".equals(type)) {
                        notifText = "<b>" + actorName + "</b> liked your post.";
                        iconClass = "fa-solid fa-thumbs-up";
                    } else {
                        notifText = "<b>" + actorName + "</b> commented on your post.";
                        iconClass = "fa-solid fa-comment";
                    }
                    
                    if (referenceIdObj != null && !String.valueOf(referenceIdObj).equals("0")) {
                        targetUrl = "HomeServlet#post-" + referenceIdObj;
                    } else {
                        targetUrl = "HomeServlet";
                    }
                    
                    System.out.println("Type: " + type + " | Reference ID: " + referenceIdObj + " | Target URL: " + targetUrl);
                }

                String formattedTime = "";
                if (createdAt != null) {
                    ZonedDateTime notifTime = createdAt.toInstant().atZone(ZoneId.of("Asia/Yangon"));
                    formattedTime = notifTime.format(formatter);
                }

                map.put("actorName", actorName);
                map.put("actorAvatar", actorAvatar);
                map.put("notifText", notifText);
                map.put("targetUrl", targetUrl);
                map.put("iconClass", iconClass);
                map.put("formattedTime", formattedTime);

                notifList.add(map);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        boolean hasUnreadNotifications = notifDao.getUnreadNotificationCount(currentUserId) > 0;
        boolean hasPendingRequests = friendDAO.hasPendingRequests(currentUserId);
        boolean hasUnreadMessages = friendDAO.hasUnreadMessages(currentUserId);

        request.setAttribute("notifications", notifList);
        request.setAttribute("hasUnreadNotifications", hasUnreadNotifications);
        request.setAttribute("hasPendingRequests", hasPendingRequests);
        request.setAttribute("hasUnreadMessages", hasUnreadMessages);

        request.getRequestDispatcher("noti.jsp").forward(request, response);
    }}