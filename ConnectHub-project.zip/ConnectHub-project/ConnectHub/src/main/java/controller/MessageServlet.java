package controller;

import model.MessageDAO;
import model.NotificationDAO; // 🌟 ထည့်သွင်းရန်
import model.FriendDAO;     // 🌟 ထည့်သွင်းရန်
import java.io.IOException;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "MessageServlet", urlPatterns = {"/MessageServlet", "/messenger", "/ChatServlet"})
public class MessageServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");

        if (userId == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        MessageDAO messageDAO = new MessageDAO();
        NotificationDAO notificationDAO = new NotificationDAO(); // 🌟 Initialize လုပ်ရန်
        FriendDAO friendDAO = new FriendDAO();                 // 🌟 Initialize လုပ်ရန်

        // 🌟 အနီစက်များအတွက် တန်ဖိုးများကို တွက်ချက်ခြင်း
        boolean hasUnreadNotifications = notificationDAO.getUnreadNotificationCount(userId) > 0;
        boolean hasPendingRequests = friendDAO.hasPendingRequests(userId);
        boolean hasUnreadMessages = friendDAO.hasUnreadMessages(userId);

        String receiverIdStr = request.getParameter("receiver_id");

        // အကယ်၍ receiver_id ပါလာလျှင် သီးသန့် Chat မျက်နှာပြင်သို့ ပို့မည်
        if (receiverIdStr != null && !receiverIdStr.trim().isEmpty()) {
            int receiverId = Integer.parseInt(receiverIdStr);

            // မဖတ်ရသေးသော မက်ဆေ့ချ်များကို Read လုပ်ခြင်း
            messageDAO.markMessagesAsRead(userId, receiverId);

            // Receiver ၏ နာမည်ကို DAO မှ တိုက်ရယူခြင်း
            String receiverName = messageDAO.getUserName(receiverId);
            String receiverAvatar = "ImageServlet?user_id=" + receiverId + "&type=profile";
            String profileLink = "ViewProfileServlet?user_id=" + receiverId;

            // ချတ်မက်ဆေ့ချ်များ ရယူရန်
            List<Map<String, Object>> chatMessages = messageDAO.getChatMessages(userId, receiverId);

            request.setAttribute("receiverId", receiverId);
            request.setAttribute("receiverName", receiverName);
            request.setAttribute("receiverAvatar", receiverAvatar);
            request.setAttribute("profileLink", profileLink);
            request.setAttribute("messageList", chatMessages);

            // 🌟 Chat မျက်နှာပြင်အတွက် attribute များ ပို့ပေးခြင်း
            request.setAttribute("hasUnreadNotifications", hasUnreadNotifications);
            request.setAttribute("hasPendingRequests", hasPendingRequests);
            request.setAttribute("hasUnreadMessages", hasUnreadMessages);

            request.getRequestDispatcher("chat.jsp").forward(request, response);
            return;
        }

        // receiver_id မပါလာလျှင် Messenger (Chat List) စာရင်းကို ပြမည်
        List<Map<String, Object>> chatList = new ArrayList<>();
        List<Integer> friendIds = messageDAO.getAcceptedFriendIds(userId); 

        for (int fId : friendIds) {
            Map<String, Object> chatData = new HashMap<>();
            chatData.put("friendId", fId);
            chatData.put("friendName", messageDAO.getUserName(fId)); 
            chatData.put("friendAvatar", "ImageServlet?user_id=" + fId + "&type=profile");

            Map<String, Object> msgInfo = messageDAO.getLastMessageAndStatus(userId, fId); 
            chatData.put("lastMessage", msgInfo.get("lastMessage"));
            chatData.put("isUnread", msgInfo.get("isUnread"));

            chatList.add(chatData);
        }

        request.setAttribute("chatList", chatList);
        
        // 🌟 Messenger စာရင်း မျက်နှာပြင်အတွက် attribute များ ပို့ပေးခြင်း
        request.setAttribute("hasUnreadNotifications", hasUnreadNotifications);
        request.setAttribute("hasPendingRequests", hasPendingRequests);
        request.setAttribute("hasUnreadMessages", hasUnreadMessages);

        request.getRequestDispatcher("messenger.jsp").forward(request, response); 
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        MessageDAO messageDAO = new MessageDAO();
        String receiverIdStr = request.getParameter("receiver_id");
        if (receiverIdStr == null) {
            response.sendRedirect("MessageServlet");
            return;
        }
        int receiverId = Integer.parseInt(receiverIdStr);
        String actionType = request.getParameter("action_type");

        if ("delete".equals(actionType)) {
            String msgIdStr = request.getParameter("message_id");
            if (msgIdStr != null) {
                messageDAO.deleteMessage(Integer.parseInt(msgIdStr), userId); 
            }
        } else if ("reaction".equals(actionType)) {
            String msgIdStr = request.getParameter("message_id");
            String emoji = request.getParameter("emoji");
            if (msgIdStr != null && emoji != null) {
                int msgId = Integer.parseInt(msgIdStr);
                String existingReaction = messageDAO.getMessageReaction(msgId);
                String newReaction = (emoji.equals(existingReaction)) ? null : emoji;
                messageDAO.updateReaction(msgId, newReaction);
            }
        } else {
            String messageText = request.getParameter("message");
            if (messageText != null && !messageText.trim().isEmpty()) {
                String replyTo = request.getParameter("reply_to");
                String finalMsg = messageText;
                if (replyTo != null && !replyTo.trim().isEmpty()) {
                    finalMsg = "[Repled] " + replyTo + "\n--- \n" + messageText;
                }

                ZonedDateTime mmtNow = ZonedDateTime.now(ZoneId.of("Asia/Rangoon"));
                Timestamp mmtTimestamp = Timestamp.valueOf(mmtNow.toLocalDateTime());

                messageDAO.sendMessage(userId, receiverId, finalMsg, mmtTimestamp); 
            }
        }

        response.sendRedirect("MessageServlet?receiver_id=" + receiverId);
    }
} 