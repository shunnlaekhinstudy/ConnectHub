package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.SettingDAO;

@WebServlet("/SettingServlet")
public class SettingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private SettingDAO settingDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        settingDAO = new SettingDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");

        if (userId == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String action = request.getParameter("action");
        if (action == null) {
            response.sendRedirect("setting.jsp");
            return;
        }

        try {
            if (action.equals("updateTheme")) {
                String bg = request.getParameter("bg");
                if (bg != null) {
                    boolean updated = settingDAO.updateTheme(userId, bg);
                    if (updated) {
                        session.setAttribute("appBgColor", bg);
                    }
                }
                response.sendRedirect("setting.jsp");

            } else if (action.equals("updateInfo")) {
                String name = request.getParameter("name");
                String email = request.getParameter("email");
                String password = request.getParameter("password");

                boolean updated = settingDAO.updateUserInfo(userId, name, email, password);
                if (updated) {
                    // Session ထဲတွင် အမည်နှင့် အီးမေးလ်ပါ ထည့်သွင်းပေးခြင်း
                    session.setAttribute("userName", name);
                    session.setAttribute("userEmail", email);
                }
                response.sendRedirect("setting.jsp");

            }else if (action.equals("submitFeedback")) {
                String feedback = request.getParameter("feedback");
                boolean submitted = settingDAO.submitFeedback(userId, feedback);
                if (submitted) {
                    response.sendRedirect("setting.jsp?success=feedback"); // Success parameter ထည့်ရန်
                } else {
                    response.sendRedirect("setting.jsp?error=fail");
                }
                return;
            

            } else if (action.equals("logout")) {
                session.invalidate();
                response.sendRedirect("index.jsp");

            } else if (action.equals("deleteAccount")) {
                settingDAO.deleteAccount(userId);
                session.invalidate();
                response.sendRedirect("index.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("setting.jsp?error=server_error");
        }
    }
}