package controller;

import model.FriendDAO;
import model.NotificationDAO; // 🌟 NotificationDAO ကို import လုပ်ရန်
import java.io.IOException;
import java.util.List;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "FriendServlet", urlPatterns = {"/FriendServlet", "/friendServlet"})
public class FriendServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        FriendDAO friendDAO = new FriendDAO();
        NotificationDAO notificationDAO = new NotificationDAO(); // 🌟 NotificationDAO ကို Initialize လုပ်ရန်
        String action = request.getParameter("action");

        // Action တစ်ခုခု ပါလာပါက သက်ဆိုင်ရာ DAO Method များကို လုပ်ဆောင်ရန်
        if (action != null) {
            response.setContentType("text/plain");
            if ("send".equals(action)) {
                // Parameter 'user_id' သို့မဟုတ် 'receiverId' နှစ်မျိုးစလုံးကို လက်ခံနိုင်ရန်
                String receiverIdStr = request.getParameter("user_id");
                if (receiverIdStr == null) {
                    receiverIdStr = request.getParameter("receiverId");
                }
                
                if (receiverIdStr != null) {
                    int receiverId = Integer.parseInt(receiverIdStr);
                    boolean success = friendDAO.sendRequest(userId, receiverId);
                    if (success) {
                        // 🌟 သူငယ်ချင်းတောင်းဆိုမှု ပို့လိုက်သောအခါ Receiver ထံသို့ 'friend_request' နိုတစ်ပို့ရန်
                        notificationDAO.addNotification(receiverId, userId, 0, "friend_request");

                        response.getWriter().write("SUCCESS");
                    } else {
                        response.getWriter().write("FAILED");
                    }
                }
                return;
            } else if ("accept".equals(action)) {
                // Parameter 'user_id' သို့မဟုတ် 'senderId' နှစ်မျိုးစလုံးကို လက်ခံနိုင်ရန်
                String senderIdStr = request.getParameter("user_id");
                if (senderIdStr == null) {
                    senderIdStr = request.getParameter("senderId");
                }
                
                if (senderIdStr != null) {
                    int senderId = Integer.parseInt(senderIdStr);
                    boolean success = friendDAO.acceptRequest(senderId, userId);
                    if (success) {
                        // 🌟 သူငယ်ချင်းတောင်းဆိုမှုကို လက်ခံလိုက်သောအခါ မူလတောင်းဆိုသူ (senderId) ထံသို့ 'friend_accept' နိုတစ်ပို့ရန်
                        notificationDAO.addNotification(senderId, userId, 0, "friend_accept");

                        response.getWriter().write("SUCCESS");
                    } else {
                        response.getWriter().write("FAILED");
                    }
                }
                return;
            } else if ("remove".equals(action)) {
                String friendIdStr = request.getParameter("friendId");
                if (friendIdStr == null) {
                    friendIdStr = request.getParameter("user_id");
                }
                
                if (friendIdStr != null) {
                    int friendId = Integer.parseInt(friendIdStr);
                    boolean success = friendDAO.removeFriendship(userId, friendId);
                    if (success) {
                        response.getWriter().write("SUCCESS");
                    } else {
                        response.getWriter().write("FAILED");
                    }
                }
                return;
            }
        }

        // Action မပါလျှင် friend.jsp သို့ ဒေတာများ ပို့ဆောင်ပေးမည်
        List<Map<String, Object>> friendList = friendDAO.getFriendsList(userId);
        List<Map<String, Object>> suggestions = friendDAO.getSuggestionsList(userId);
        List<Map<String, Object>> friendRequests = friendDAO.getRequestsList(userId);

        // JSP တွင် အသုံးပြုရန် unread နှင့် pending အချက်အလက်များကို ထည့်သွင်းပေးခြင်း
        boolean hasUnreadMessages = friendDAO.hasUnreadMessages(userId);
        boolean hasUnreadNotifications = friendDAO.hasUnreadNotifications(userId);
        boolean hasPendingRequests = friendDAO.hasPendingRequests(userId);

        request.setAttribute("friendList", friendList);
        request.setAttribute("suggestions", suggestions);
        request.setAttribute("friendRequests", friendRequests);
        request.setAttribute("hasUnreadMessages", hasUnreadMessages);
        request.setAttribute("hasUnreadNotifications", hasUnreadNotifications);
        request.setAttribute("hasPendingRequests", hasPendingRequests);

        request.getRequestDispatcher("friend.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}