package controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.ImageDAO;

@WebServlet("/ImageServlet")
public class ImageServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String userIdStr = request.getParameter("user_id");
        String type = request.getParameter("type"); // profile လား (သို့) cover လား ခွဲရန်

        if (userIdStr == null || userIdStr.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing user_id");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdStr);

            // DAO ကို အသုံးပြု၍ ပုံဒေတာကို ဆွဲထုတ်ခြင်း
            ImageDAO imageDAO = new ImageDAO();
            byte[] imgData = imageDAO.getImageData(userId, type);

            if (imgData != null && imgData.length > 0) {
                response.setContentType("image/jpeg");
                response.getOutputStream().write(imgData);
            } else {
                // ပုံမရှိပါက Type ပေါ်မူတည်၍ သက်ဆိုင်ရာ Default ပုံကို ထုတ်ပေးမည်
                String defaultImgPath;
                if ("cover".equals(type)) {
                    defaultImgPath = getServletContext().getRealPath("/images/default-cover.jpg");
                } else {
                    defaultImgPath = getServletContext().getRealPath("/images/default-avatar.png");
                }
                
                File defaultFile = new File(defaultImgPath);
                if (defaultFile.exists()) {
                    response.setContentType("image/jpeg");
                    Files.copy(defaultFile.toPath(), response.getOutputStream());
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Default image not found");
                }
            }
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user_id format");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Server error");
        }
    }
}