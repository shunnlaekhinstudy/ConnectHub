package controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.HomeDAO;
import model.InteractDAO;
import model.NotificationDAO;

@WebServlet("/InteractServlet")
public class InteractServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private HomeDAO homeDAO;
    private InteractDAO interactDAO;
    private NotificationDAO notificationDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        homeDAO = new HomeDAO();
        interactDAO = new InteractDAO();
        notificationDAO = new NotificationDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        Integer userId = (Integer) session.getAttribute("user_id");
        String userName = (String) session.getAttribute("userName");
        if (userName == null) {
            userName = (String) session.getAttribute("user");
        }
        if (userName == null) {
            userName = "User";
        }

        String action = request.getParameter("action");

        // ၁။ Like လုပ်ဆောင်ချက်အတွက်[cite: 6]
        if ("like".equals(action)) {
            String postIdStr = request.getParameter("postId");
            if (postIdStr != null) {
                int postId = Integer.parseInt(postIdStr);
                
                interactDAO.toggleLike(postId, userId);

                int postOwnerId = homeDAO.getPostOwnerId(postId);
                if (postOwnerId > 0 && postOwnerId != userId) {
                    notificationDAO.addNotification(postOwnerId, userId, postId, "like");
                }

                response.setStatus(HttpServletResponse.SC_OK);
            }
        }
        // ၂။ Comment လုပ်ဆောင်ချက်အတွက်[cite: 6]
        else if ("comment".equals(action)) {
            String postIdStr = request.getParameter("postId");
            String commentText = request.getParameter("commentText");
            String parentIdStr = request.getParameter("parentId");

            if (postIdStr != null && commentText != null && !commentText.trim().isEmpty()) {
                int postId = Integer.parseInt(postIdStr);
                Integer parentId = (parentIdStr != null && !parentIdStr.trim().isEmpty() && !"null".equals(parentIdStr)) 
                                        ? Integer.parseInt(parentIdStr) : null;
                
                int generatedCommentId = homeDAO.addComment(postId, userId, commentText, parentId); 

                if (generatedCommentId > 0) {
                    int postOwnerId = homeDAO.getPostOwnerId(postId);
                    if (postOwnerId > 0 && postOwnerId != userId) {
                        notificationDAO.addNotification(postOwnerId, userId, postId, "comment");
                    }

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    
                    String safeCommentText = commentText.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
                    String safeUserName = userName.replace("\\", "\\\\").replace("\"", "\\\"");

                    String jsonResponse = "{\"status\":\"success\", \"commentId\":" + generatedCommentId + 
                                            ", \"username\":\"" + safeUserName + 
                                            "\", \"commentText\":\"" + safeCommentText + 
                                            "\", \"parentId\":" + (parentId != null ? parentId : "null") + "}";
                    response.getWriter().write(jsonResponse);
                } else {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    response.getWriter().write("{\"status\":\"error\", \"message\":\"Database error\"}");
                }
            }
        } 
        // ၃။ Friend Request အတွက်[cite: 6]
        else if ("friend_request".equals(action)) {
            String receiverIdStr = request.getParameter("receiverId");
            if (receiverIdStr != null) {
                int receiverId = Integer.parseInt(receiverIdStr);
                
                boolean reqSent = true; 
                
                if (reqSent) {
                    notificationDAO.addNotification(receiverId, userId, 0, "friend_request");
                    response.setStatus(HttpServletResponse.SC_OK);
                } else {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                }
            }
        }
        // ၄။ Comment ပြင်ဆင်ခြင်းအတွက်[cite: 6]
        else if ("editComment".equals(action)) {
            String commentIdStr = request.getParameter("commentId");
            String newText = request.getParameter("newText");
            
            if (commentIdStr != null && newText != null) {
                int commentId = Integer.parseInt(commentIdStr);
                boolean success = interactDAO.updateComment(commentId, userId, newText);
                if (success) {
                    response.setStatus(HttpServletResponse.SC_OK);
                } else {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                }
            }
        } 
        // ၅။ Comment ဖျက်ခြင်းအတွက်[cite: 6]
        else if ("deleteComment".equals(action)) {
            String commentIdStr = request.getParameter("commentId");
            
            if (commentIdStr != null) {
                int commentId = Integer.parseInt(commentIdStr);
                boolean success = interactDAO.deleteComment(commentId, userId);
                if (success) {
                    response.setStatus(HttpServletResponse.SC_OK);
                } else {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                }
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) return;

        String action = request.getParameter("action");
        String postIdStr = request.getParameter("postId");

        if ("like".equals(action) && postIdStr != null) {
            int userId = (Integer) session.getAttribute("user_id");
            int postId = Integer.parseInt(postIdStr);
            
            interactDAO.toggleLike(postId, userId);
            
            int postOwnerId = homeDAO.getPostOwnerId(postId);
            if (postOwnerId > 0 && postOwnerId != userId) {
                notificationDAO.addNotification(postOwnerId, userId, postId, "like");
            }
            response.setStatus(HttpServletResponse.SC_OK);
        }
        // ၆။ Likes စာရင်းနှင့် Profile သွားရန် ID, Username များကို Map ဖြင့် ထုတ်ပေးခြင်း[cite: 6]
        else if ("getLikes".equals(action) && postIdStr != null) {
            int postId = Integer.parseInt(postIdStr);
            
            List<Map<String, Object>> likedUsers = interactDAO.getLikedUsers(postId); 
            
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            
            // Map မှ id နှင့် username များကို ဖတ်၍ JSON Array တည်ဆောက်ခြင်း
            StringBuilder jsonBuilder = new StringBuilder("[");
            if (likedUsers != null) {
                for (int i = 0; i < likedUsers.size(); i++) {
                    Map<String, Object> userMap = likedUsers.get(i);
                    jsonBuilder.append("{")
                               .append("\"id\":").append(userMap.get("id")).append(",")
                               .append("\"username\":\"").append(String.valueOf(userMap.get("username")).replace("\"", "\\\"")).append("\"")
                               .append("}");
                    if (i < likedUsers.size() - 1) {
                        jsonBuilder.append(",");
                    }
                }
            }
            jsonBuilder.append("]");
            
            response.getWriter().write(jsonBuilder.toString());
        }
    }
}