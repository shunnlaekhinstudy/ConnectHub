package controller;

import com.mysql.cj.jdbc.AbandonedConnectionCleanupThread;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;

@WebListener
public class AppContextListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // အပလီကေးရှင်း စတင်ချိန်တွင် လုပ်ဆောင်ရန်
        System.out.println("ConnectHub Application Initialized.");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // ၁။ မှတ်ဉာဏ်ယိုစိမ့်မှု မဖြစ်စေရန် ဂျေဒီဘီစီ ဒရိုင်ဘာများကို ရှင်းလင်းခြင်း (Unregister)
        Enumeration<Driver> drivers = DriverManager.getDrivers();
        while (drivers.hasMoreElements()) {
            Driver driver = drivers.nextElement();
            try {
                DriverManager.deregisterDriver(driver);
                System.out.println("Deregistered JDBC driver: " + driver);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // ၂။ MySQL ၏ Background Cleanup Thread ကို ရပ်တန့်ပေးခြင်း
        try {
            AbandonedConnectionCleanupThread.checkedShutdown();
            System.out.println("MySQL AbandonedConnectionCleanupThread successfully shutdown.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}