package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.AuthDAO;
import model.ProfileDAO;

import java.io.IOException;
import java.util.Map;

@WebServlet({"/LoginServlet", "/ForgotPasswordServlet", "/SignupServlet"})
public class AuthController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AuthDAO authDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        authDAO = new AuthDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // GET Request ဝင်လာပါက Signup အတွက် သို့မဟုတ် Default အနေဖြင့် အလုပ်လုပ်ရန်
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getRequestURI();

        // 1. Login လုပ်ငန်းစဉ်
        if (action.contains("LoginServlet")) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String hashedPassword = authDAO.hashPassword(password);

            Map<String, Object> user = authDAO.loginUser(email, hashedPassword);

            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("userName", user.get("name"));
                session.setAttribute("user_id", user.get("userId"));
                session.setAttribute("userEmail", user.get("email"));
                session.setAttribute("appBgColor", user.get("bgColor"));
                
                response.sendRedirect("HomeServlet");
            } else {
                response.sendRedirect("index.jsp?error=1");
            }
        } 
        // 2. Forgot Password လုပ်ငန်းစဉ်
        else if (action.contains("ForgotPasswordServlet")) {
            String email = request.getParameter("email");

            boolean exists = authDAO.checkEmailExists(email);

            if (exists) {
                HttpSession session = request.getSession();
                session.setAttribute("resetEmail", email);
                response.sendRedirect("reset-password.jsp");
            } else {
                response.sendRedirect("forgot-password.jsp?error=1");
            }
        } 
     // 3. Signup လုပ်ငန်းစဉ်
        else if (action.contains("SignupServlet")) {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String hashedPassword = authDAO.hashPassword(password);

            // User အသစ်ကို register လုပ်ခြင်း
            boolean isRegistered = authDAO.registerUser(name, email, hashedPassword);

            if (isRegistered) {
                try {
                    // 🔴 authDAO (object) ကို အသုံးပြု၍ user_id ကို ရှာရန် (AuthDAO. သုံးမည့်အစား authDAO. ဟုသုံးပါ)
                    int newUserId = authDAO.getUserIdByEmail(email); 
                    
                    if (newUserId > 0) {
                         
                        AuthDAO.createDefaultProfile(newUserId); // Profile/Cover အတွက် default row စတင်ရန်
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                response.sendRedirect("index.jsp?signup=success");
            } else {
                response.sendRedirect("signup.jsp?error=duplicate");
            }
        }
    }
}