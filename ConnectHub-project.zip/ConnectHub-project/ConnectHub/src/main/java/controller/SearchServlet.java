package controller;

import model.SearchDAO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");
        
        if (userId == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String keyword = request.getParameter("query");
        List<Map<String, Object>> usersList = new ArrayList<>();
        List<Map<String, Object>> postsList = new ArrayList<>();

        // Keyword ထည့်သွင်းရှာဖွေမှသာ ဒေတာဆွဲထုတ်မည်
        if (keyword != null && !keyword.trim().isEmpty()) {
            SearchDAO searchDAO = new SearchDAO();
            usersList = searchDAO.searchUsers(keyword.trim(), userId);
            postsList = searchDAO.searchPosts(keyword.trim(), userId);
        }

        request.setAttribute("usersList", usersList);
        request.setAttribute("postsList", postsList);
        request.setAttribute("searchQuery", keyword != null ? keyword : "");

        request.getRequestDispatcher("search.jsp").forward(request, response);
    }
}